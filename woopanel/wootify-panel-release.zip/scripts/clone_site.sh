#!/bin/bash
set -Eeuo pipefail

SOURCE_DOMAIN=""
MODE="new_domain"
TARGET_DOMAIN=""
PHP_VERSION=""
RUN_SEARCH_REPLACE="1"
TARGET_SCHEME="http"
PRESERVE_WP_CRON="0"
KEEP_TARGET_SSL="0"

while [ "$#" -gt 0 ]; do
    case "$1" in
        --source-domain)
            SOURCE_DOMAIN="${2:-}"
            shift 2
            ;;
        --mode)
            MODE="${2:-}"
            shift 2
            ;;
        --target-domain)
            TARGET_DOMAIN="${2:-}"
            shift 2
            ;;
        --php-version)
            PHP_VERSION="${2:-}"
            shift 2
            ;;
        --run-search-replace)
            RUN_SEARCH_REPLACE="${2:-1}"
            shift 2
            ;;
        --target-scheme)
            TARGET_SCHEME="${2:-http}"
            shift 2
            ;;
        --preserve-wp-cron)
            PRESERVE_WP_CRON="${2:-0}"
            shift 2
            ;;
        --keep-target-ssl)
            KEEP_TARGET_SSL="${2:-0}"
            shift 2
            ;;
        *)
            echo "Unknown argument: $1"
            exit 1
            ;;
    esac
done

if [ -z "$SOURCE_DOMAIN" ] || [ -z "$TARGET_DOMAIN" ]; then
    echo "Usage: $0 --source-domain <domain> --mode <new_domain|overwrite> --target-domain <domain> [options]"
    exit 1
fi

if [ "$SOURCE_DOMAIN" = "$TARGET_DOMAIN" ]; then
    echo "Source and target domains must be different."
    exit 1
fi

if [ "$MODE" != "new_domain" ] && [ "$MODE" != "overwrite" ]; then
    echo "Unsupported clone mode: $MODE"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
SOURCE_ROOT="/var/www/$SOURCE_DOMAIN"
TARGET_ROOT="/var/www/$TARGET_DOMAIN"
WP_CLI_RUNTIME_BASE="/var/cache/wootify/wp-cli"
WP_CLI_HOME=""
WP_CLI_CACHE_DIR=""
# Derive per-site pool username for the TARGET domain (same formula as create_site.sh)
TARGET_POOL_USER=""

source "${SCRIPT_DIR}/logging.sh"
source "${SCRIPT_DIR}/os_detect.sh"
source "${SCRIPT_DIR}/nginx_site_template.sh"
source "${SCRIPT_DIR}/wp_migrate.sh"
source "${SCRIPT_DIR}/permissions.sh"
validate_site_domain "$SOURCE_DOMAIN" && validate_site_domain "$TARGET_DOMAIN" || { echo "Invalid site domain" >&2; exit 1; }
TARGET_POOL_USER="$(resolve_pool_user_from_config "$TARGET_DOMAIN" || true)"
[ -n "$TARGET_POOL_USER" ] || TARGET_POOL_USER="$(resolve_pool_username "$TARGET_DOMAIN")"
pool_user_is_unshared "$TARGET_DOMAIN" "$TARGET_POOL_USER" || { echo "Target pool user is shared" >&2; exit 1; }

LOG_FILE="$(resolve_log_file "wootify_clone.log")"
BACKUP_ROOT="${PROJECT_DIR}/storage/backups/site-clone"
TARGET_BACKUP_DIR=""
TARGET_MODIFIED=false
NEW_DB_CREATED=false
NEW_DB_USER_CREATED=false
NEW_POOL_CREATED=false
NEW_USER_CREATED=false
NEW_ROOT_CREATED=false
NEW_NGINX_CREATED=false
DUMP_FILE=""
TARGET_POOL_CONF=""
TARGET_NGINX_CONF=""
NEW_DB_NAME=""
NEW_DB_USER=""

log() {
    echo "[INFO] $1"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [CLONE] $1" >> "${LOG_FILE}"
}

fail() {
    log "$1"
    echo "$1"
    exit 1
}

cleanup_clone() {
    local status="$1" rollback_failed=false
    trap - EXIT ERR
    set +e
    if [ "$status" -ne 0 ]; then
        if [ "$MODE" = overwrite ] && [ "$TARGET_MODIFIED" = true ]; then
            if [ -f "$TARGET_BACKUP_DIR/files.tar.gz" ] && [ -s "$TARGET_BACKUP_DIR/database.sql" ]; then
                find "$TARGET_ROOT" -mindepth 1 -maxdepth 1 -exec rm -rf -- {} + || rollback_failed=true
                tar -xzf "$TARGET_BACKUP_DIR/files.tar.gz" -C "$TARGET_ROOT" || rollback_failed=true
                mariadb -e "DROP DATABASE IF EXISTS \`${TARGET_DB_NAME}\`; CREATE DATABASE \`${TARGET_DB_NAME}\`;" || rollback_failed=true
                mariadb "$TARGET_DB_NAME" < "$TARGET_BACKUP_DIR/database.sql" || rollback_failed=true
            else
                rollback_failed=true
            fi
        elif [ "$MODE" = new_domain ]; then
            [ "$NEW_NGINX_CREATED" != true ] || rm -f -- "$TARGET_NGINX_CONF" || rollback_failed=true
            [ "$NEW_ROOT_CREATED" != true ] || rm -rf -- "$TARGET_ROOT" || rollback_failed=true
            [ "$NEW_POOL_CREATED" != true ] || rm -f -- "$TARGET_POOL_CONF" || rollback_failed=true
            [ "$NEW_DB_USER_CREATED" != true ] || mariadb -e "DROP USER IF EXISTS '${NEW_DB_USER}'@'localhost';" || rollback_failed=true
            [ "$NEW_DB_CREATED" != true ] || mariadb -e "DROP DATABASE IF EXISTS \`${NEW_DB_NAME}\`;" || rollback_failed=true
            if [ "$NEW_USER_CREATED" = true ]; then userdel "$TARGET_POOL_USER" || rollback_failed=true; remove_site_group "$TARGET_POOL_USER"; fi
            if [ "$NEW_POOL_CREATED" = true ]; then reload_php_fpm_for_pool || rollback_failed=true; fi
        fi
        if [ "$TARGET_MODIFIED" = true ] || [ "$NEW_NGINX_CREATED" = true ]; then
            if nginx -t; then systemctl reload nginx || rollback_failed=true; else rollback_failed=true; fi
        fi
        if [ "$rollback_failed" = true ]; then echo "[ERROR] Clone rollback incomplete; preserve backup at $TARGET_BACKUP_DIR" >&2; fi
    fi
    [ -z "$DUMP_FILE" ] || rm -f -- "$DUMP_FILE"
    return "$status"
}
CLONE_MAIN_PID=$BASHPID
trap 'status=$?; if [ "$BASHPID" = "$CLONE_MAIN_PID" ]; then cleanup_clone "$status"; fi' EXIT
trap 'echo "[ERROR] Clone failed on line $LINENO" >&2' ERR
trap 'exit 1' INT TERM

ensure_wp_cli() {
    # Check the canonical install path directly — avoids PATH stripping issues
    # and prevents accidentally downloading a corrupt/invalid phar from GitHub.
    if [ -x /usr/local/bin/wp ]; then
        return 0
    fi
    fail "WP-CLI not found at /usr/local/bin/wp. Please install WP-CLI before cloning a site."
}

# ----- per-site pool helpers (mirrors create_site.sh) -----
resolve_per_site_pool_dir() {
    if [ "$IS_DEBIAN" = true ]; then
        printf '/etc/php/%s/fpm/pool.d' "$PHP_VERSION"
    else
        printf '/etc/php-fpm.d'
    fi
}

resolve_per_site_socket_dir() {
    if [ "$IS_DEBIAN" = true ]; then
        printf '/run/php'
    else
        printf '/run/php-fpm'
    fi
}

reload_php_fpm_for_pool() {
    local svc
    svc="$(resolve_php_fpm_service_name "$PHP_VERSION" 2>/dev/null || true)"
    [ -z "$svc" ] && svc="php-fpm"
    if systemctl is-active --quiet "$svc" 2>/dev/null; then
        systemctl reload "$svc"
    else
        systemctl restart "$svc"
    fi
}

create_target_pool_user() {
    if id "$TARGET_POOL_USER" >/dev/null 2>&1; then
        [ "$(getent passwd "$TARGET_POOL_USER" | cut -d: -f5)" = "WooPanel PHP pool ${TARGET_DOMAIN}" ] || fail "Refusing to reuse an unrelated user"
        log "Pool user $TARGET_POOL_USER already exists — reusing."
        ensure_site_group "$TARGET_POOL_USER"
        return 0
    fi
    log "Creating system pool user: $TARGET_POOL_USER"
    # Private group, see ensure_site_group in os_detect.sh.
    getent group "$TARGET_POOL_USER" >/dev/null || groupadd --system "$TARGET_POOL_USER"
    useradd \
        --system \
        --no-create-home \
        --shell /sbin/nologin \
        --comment "WooPanel PHP pool ${TARGET_DOMAIN}" \
        --gid "$TARGET_POOL_USER" \
        "$TARGET_POOL_USER"
    NEW_USER_CREATED=true
    ensure_site_group "$TARGET_POOL_USER"
    log "Pool user created: $TARGET_POOL_USER"
}

create_target_fpm_pool() {
    local pool_dir socket_dir socket_path pool_conf_path
    pool_dir="$(resolve_per_site_pool_dir)"
    socket_dir="$(resolve_per_site_socket_dir)"
    socket_path="${socket_dir}/${TARGET_DOMAIN}.sock"
    pool_conf_path="${pool_dir}/${TARGET_DOMAIN}.conf"

    if [ -f "$pool_conf_path" ]; then
        if [ "$MODE" = "overwrite" ]; then
            log "Overwriting existing PHP-FPM pool conf: $pool_conf_path"
        else
            log "PHP-FPM pool conf already exists: $pool_conf_path — skipping"
            return 0
        fi
    fi

    log "Creating PHP-FPM pool conf: $pool_conf_path"
    TARGET_POOL_CONF="$pool_conf_path"
    NEW_POOL_CREATED=true
    local nginx_user
    nginx_user="$(detect_nginx_runtime_user)"
    cat > "$pool_conf_path" <<POOLEOF
; WooPanel per-site pool for ${TARGET_DOMAIN}
[${TARGET_DOMAIN}]
user = ${TARGET_POOL_USER}
group = $(site_group_of "$TARGET_POOL_USER")
listen = ${socket_path}
listen.owner = ${nginx_user}
listen.group = ${nginx_user}
listen.mode = 0660
pm = ondemand
pm.max_children = 10
pm.process_idle_timeout = 10s
pm.max_requests = 500
POOLEOF
    apply_php_protect_block "$pool_conf_path"

    log "Reloading PHP-FPM to activate pool for $TARGET_DOMAIN..."
    reload_php_fpm_for_pool

    local i=0
    while [ $i -lt 15 ]; do
        [ -S "$socket_path" ] && break
        sleep 1
        i=$((i + 1))
    done
    if [ ! -S "$socket_path" ]; then
        fail "Per-site socket $socket_path not ready after 15s"
    fi
}
# -----------------------------------------------------------

prepare_wp_cli_runtime() {
    WP_CLI_HOME="${WP_CLI_RUNTIME_BASE}/${TARGET_POOL_USER}"
    WP_CLI_CACHE_DIR="${WP_CLI_HOME}/cache"

    install -d -m 755 -o "$TARGET_POOL_USER" -g "$WEB_GROUP" "$WP_CLI_HOME"
    install -d -m 755 -o "$TARGET_POOL_USER" -g "$WEB_GROUP" "$WP_CLI_CACHE_DIR"
}

run_wp_cli() {
    sudo -H -u "$TARGET_POOL_USER" env \
        HOME="$WP_CLI_HOME" \
        WP_CLI_CACHE_DIR="$WP_CLI_CACHE_DIR" \
        /usr/local/bin/wp --no-color "$@"
}

normalize_web_root_permissions() {
    local root="$1"

    local group
    group="$(site_group_of "${TARGET_POOL_USER:-$WEB_USER}")"
    chown -R "${TARGET_POOL_USER:-$WEB_USER}:$group" "$root"
    find "$root" -type d ! -perm 755 -exec chmod 755 {} +
    find "$root" -type f ! -perm 644 -exec chmod 644 {} +

    # 600 like create_site.sh: only the site's PHP user may read credentials.
    if [ -f "$root/wp-config.php" ]; then
        chmod 600 "$root/wp-config.php"
    fi
    # Site root is the isolation boundary (site group = pool user + nginx).
    [ "$group" = "$WEB_GROUP" ] || chmod 0750 "$root"

    apply_wp_selinux_contexts "$root"
}

# Consistent InnoDB snapshot without locking the live site, including
# stored routines/triggers that plugins sometimes rely on.
dump_database() {
    local db_name="$1" out="$2" tool
    tool="$(dump_cmd)" || fail "mysqldump/mariadb-dump is required for site clone."
    "$tool" --single-transaction --quick --routines --triggers --hex-blob "$db_name" > "$out"
}

dump_cmd() {
    if command -v mariadb-dump >/dev/null 2>&1; then
        echo "mariadb-dump"
        return 0
    fi
    if command -v mysqldump >/dev/null 2>&1; then
        echo "mysqldump"
        return 0
    fi
    return 1
}


random_suffix() {
    openssl rand -hex 3
}

create_database_credentials() {
    local suffix
    suffix="$(random_suffix)"
    NEW_DB_NAME="wp_${suffix}"
    NEW_DB_USER="user_${suffix}"
    NEW_DB_PASS="$(openssl rand -base64 12)"
}

create_database() {
    local db_name="$1"
    local db_user="$2"
    local db_pass="$3"

    log "Creating database ${db_name}..."
    mariadb -e "CREATE DATABASE \`${db_name}\`;"
    NEW_DB_CREATED=true
    # SQL via stdin so the password never shows up in the process list.
    mariadb <<SQL
CREATE USER '${db_user}'@'localhost' IDENTIFIED BY '${db_pass}';
SQL
    NEW_DB_USER_CREATED=true
    mariadb <<SQL
GRANT ALL PRIVILEGES ON \`${db_name}\`.* TO '${db_user}'@'localhost';
FLUSH PRIVILEGES;
SQL
}

render_nginx_config() {
    local domain="$1"
    local web_root="$2"
    local php_version="$3"
    local nginx_conf="$4"
    local php_fpm_sock=""

    # Prefer the per-site socket if it already exists (created by create_target_fpm_pool)
    local socket_dir
    socket_dir="$(resolve_per_site_socket_dir)"
    if [ -S "${socket_dir}/${domain}.sock" ]; then
        php_fpm_sock="${socket_dir}/${domain}.sock"
    else
        php_fpm_sock="$(resolve_php_fpm_socket_for_version "$php_version" || true)"
    fi
    if [ -z "$php_fpm_sock" ]; then
        fail "Unable to resolve PHP-FPM socket for PHP ${php_version}"
    fi

    # Same template as create_site.sh so cloned sites get identical hardening/cache.
    render_wp_site_nginx_conf "$domain" "$web_root" "$php_fpm_sock" "$nginx_conf"
}

copy_site_files() {
    local source_root="$1"
    local target_root="$2"

    mkdir -p "$target_root"
    shopt -s dotglob nullglob
    rm -rf "${target_root:?}/"*
    shopt -u dotglob nullglob
    cp -a "${source_root}/." "${target_root}/"
}

configure_wp_config() {
    local root="$1"
    local db_name="$2"
    local db_user="$3"
    local db_pass="$4"

    run_wp_cli config set DB_NAME "$db_name" --type=constant --path="$root" >/dev/null
    run_wp_cli config set DB_USER "$db_user" --type=constant --path="$root" >/dev/null
    run_wp_cli config set DB_PASSWORD "$db_pass" --type=constant --path="$root" >/dev/null
}

configure_wp_cron() {
    local root="$1"
    local target_domain="$2"
    local preserve="$3"
    # Same slug rule as cronSlug() in handlers/crons.go and delete_site.sh.
    local cron_slug
    cron_slug="$(printf '%s' "$target_domain" | tr -c 'a-zA-Z0-9' '_')"
    cron_slug="${cron_slug%_}"
    [ -n "$cron_slug" ] || cron_slug="wp_site"

    if [ "$preserve" = "1" ]; then
        run_wp_cli config set DISABLE_WP_CRON true --raw --type=constant --path="$root" >/dev/null 2>&1 || true
        return 0
    fi

    run_wp_cli config delete DISABLE_WP_CRON --type=constant --path="$root" >/dev/null 2>&1 || true
    # Not preserving system cron: drop the managed job (and the legacy
    # wpcron_* name used by older clones) so WordPress' own cron takes over.
    rm -f "/etc/cron.d/wootify-wp-${cron_slug}" "/etc/cron.d/wpcron_${target_domain//./_}"
}


# Give the clone its own object-cache namespace and salts. Must run before
# any WP-CLI command that boots WordPress: with the source's Redis prefix,
# "option update home" would write the target URL into the SOURCE's cache.
isolate_wp_identity() {
    local root="$1" target_domain="$2"
    set_wp_cache_namespace "$root" "$target_domain"
    run_wp_cli config shuffle-salts --path="$root" >/dev/null || log "Warning: could not regenerate salts (keeps source salts)."
}



prune_clone_backups() {
    local domain="$1" keep=3
    ls -1dt "${BACKUP_ROOT}/${domain}-"[0-9]* 2>/dev/null | tail -n +$((keep + 1)) | while IFS= read -r old; do
        rm -rf -- "$old"
    done
}

backup_target_site() {
    local target_root="$1"
    local target_db_name="$2"
    local target_domain="$3"

    local ts
    ts="$(date '+%Y%m%d-%H%M%S')"
    local backup_dir="${BACKUP_ROOT}/${target_domain}-${ts}"
    install -d -m 750 -o root -g "$WEB_GROUP" "$backup_dir"

    log "Creating safety backup for ${target_domain} at ${backup_dir}..."
    tar -czf "${backup_dir}/files.tar.gz" -C "$target_root" .
    dump_database "$target_db_name" "${backup_dir}/database.sql"
    tar -tzf "${backup_dir}/files.tar.gz" >/dev/null
    [ -s "${backup_dir}/database.sql" ] || fail "Database backup is empty"
    chmod 640 "${backup_dir}/files.tar.gz"
    chmod 640 "${backup_dir}/database.sql"
    TARGET_BACKUP_DIR="$backup_dir"
}

require_root "clone_site.sh"
install -d -m 750 -o root -g "$WEB_GROUP" "$BACKUP_ROOT"
ensure_wp_cli

# For new_domain: create pool user first so prepare_wp_cli_runtime can use it
# For overwrite: pool user was created by create_site.sh; verify or fall back
if [ "$MODE" = "new_domain" ]; then
    create_target_pool_user
else
    if ! id "$TARGET_POOL_USER" >/dev/null 2>&1; then
        log "Warning: pool user $TARGET_POOL_USER not found; falling back to $WEB_USER"
        TARGET_POOL_USER="$WEB_USER"
    fi
fi

prepare_wp_cli_runtime

[ -d "$SOURCE_ROOT" ] || fail "Source web root not found: $SOURCE_ROOT"
[ -f "$SOURCE_ROOT/wp-config.php" ] || fail "Only WordPress source sites are supported right now."
if grep -Eq "define\(\s*['\"]MULTISITE['\"]\s*,\s*true" "$SOURCE_ROOT/wp-config.php"; then
    fail "WordPress Multisite networks cannot be cloned yet (URLs live in per-blog tables and need a network-aware migration)."
fi

SOURCE_DB_NAME="$(read_wp_define "$SOURCE_ROOT/wp-config.php" "DB_NAME")"
SOURCE_DB_USER="$(read_wp_define "$SOURCE_ROOT/wp-config.php" "DB_USER")"
SOURCE_DB_PASS="$(read_wp_define "$SOURCE_ROOT/wp-config.php" "DB_PASSWORD")"
[ -n "$SOURCE_DB_NAME" ] || fail "Could not read source database credentials."

dump_cmd >/dev/null || fail "mysqldump/mariadb-dump is required for site clone."
# Keep the dump on disk next to the backups (/tmp may be a small tmpfs).
DUMP_FILE="$(mktemp "${BACKUP_ROOT}/clone-db-XXXXXX.sql")"


if [ -z "$PHP_VERSION" ]; then
    PHP_VERSION="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || true)"
    [ -n "$PHP_VERSION" ] || PHP_VERSION="$(ls /etc/php 2>/dev/null | grep -E '^[0-9]+\.[0-9]+$' | sort -V | tail -n1 || true)"
    [ -n "$PHP_VERSION" ] || PHP_VERSION="8.3"
fi

log "Cloning ${SOURCE_DOMAIN} -> ${TARGET_DOMAIN} (${MODE})..."
log "Exporting source database ${SOURCE_DB_NAME}..."
dump_database "$SOURCE_DB_NAME" "$DUMP_FILE"

SOURCE_KB="$(du -sk "$SOURCE_ROOT" | awk '{print $1}')"
DUMP_KB="$(du -sk "$DUMP_FILE" | awk '{print $1}')"
MARIADB_DATADIR="$(mariadb -NBe 'SELECT @@datadir' 2>/dev/null || echo /var/lib/mysql)"
if [ "$MODE" = "new_domain" ]; then
    ensure_free_space /var/www $(( SOURCE_KB * 11 / 10 )) "$MARIADB_DATADIR" $(( DUMP_KB * 2 ))
else
    # Overwrite also needs room for the safety backup of the target.
    TARGET_KB="$(du -sk "$TARGET_ROOT" 2>/dev/null | awk '{print $1}')"
    ensure_free_space /var/www $(( SOURCE_KB * 11 / 10 )) "$MARIADB_DATADIR" $(( DUMP_KB * 2 )) \
        "$BACKUP_ROOT" $(( ${TARGET_KB:-0} + DUMP_KB ))
fi

if [ "$MODE" = "new_domain" ]; then
    if [ -e "$TARGET_ROOT" ]; then
        fail "Target web root already exists: $TARGET_ROOT"
    fi

    # Now using conf.d for all distributions for consistency
    TARGET_NGINX_CONF="${NGINX_CONF_DIR}/${TARGET_DOMAIN}.conf"
    [ ! -e "$TARGET_NGINX_CONF" ] || fail "Nginx configuration already exists for ${TARGET_DOMAIN}"

    create_database_credentials
    create_database "$NEW_DB_NAME" "$NEW_DB_USER" "$NEW_DB_PASS"

    log "Creating PHP-FPM pool for ${TARGET_DOMAIN}..."
    create_target_fpm_pool

    log "Copying website files to ${TARGET_ROOT}..."
    NEW_ROOT_CREATED=true
    install -d -m 755 -o "$TARGET_POOL_USER" -g "$(site_group_of "$TARGET_POOL_USER")" "$TARGET_ROOT"
    cp -a "${SOURCE_ROOT}/." "${TARGET_ROOT}/"
    rewrite_source_paths "$TARGET_ROOT" "$SOURCE_ROOT" "$TARGET_ROOT"
    normalize_web_root_permissions "$TARGET_ROOT"

    log "Importing database into ${NEW_DB_NAME}..."
    mariadb "$NEW_DB_NAME" < "$DUMP_FILE"
    configure_wp_config "$TARGET_ROOT" "$NEW_DB_NAME" "$NEW_DB_USER" "$NEW_DB_PASS"
    isolate_wp_identity "$TARGET_ROOT" "$TARGET_DOMAIN"
    configure_wp_cron "$TARGET_ROOT" "$TARGET_DOMAIN" "$PRESERVE_WP_CRON"

    if [ "$RUN_SEARCH_REPLACE" = "1" ]; then
        run_search_replace "$TARGET_ROOT" "$SOURCE_DOMAIN" "$TARGET_DOMAIN" "$TARGET_SCHEME"
    fi

    log "Generating Nginx config for ${TARGET_DOMAIN}..."
    NEW_NGINX_CREATED=true
    render_nginx_config "$TARGET_DOMAIN" "$TARGET_ROOT" "$PHP_VERSION" "$TARGET_NGINX_CONF"
else
    [ -d "$TARGET_ROOT" ] || fail "Target web root not found: $TARGET_ROOT"
    [ -f "$TARGET_ROOT/wp-config.php" ] || fail "Only WordPress target sites are supported for overwrite mode."

    TARGET_DB_NAME="$(read_wp_define "$TARGET_ROOT/wp-config.php" "DB_NAME")"
    TARGET_DB_USER="$(read_wp_define "$TARGET_ROOT/wp-config.php" "DB_USER")"
    TARGET_DB_PASS="$(read_wp_define "$TARGET_ROOT/wp-config.php" "DB_PASSWORD")"
    [ -n "$TARGET_DB_NAME" ] || fail "Could not read target database credentials."

    backup_target_site "$TARGET_ROOT" "$TARGET_DB_NAME" "$TARGET_DOMAIN"

    TARGET_MODIFIED=true
    log "Replacing target files in ${TARGET_ROOT}..."
    copy_site_files "$SOURCE_ROOT" "$TARGET_ROOT"
    rewrite_source_paths "$TARGET_ROOT" "$SOURCE_ROOT" "$TARGET_ROOT"
    normalize_web_root_permissions "$TARGET_ROOT"

    log "Refreshing target database ${TARGET_DB_NAME}..."
    mariadb -e "DROP DATABASE IF EXISTS \`${TARGET_DB_NAME}\`;"
    mariadb -e "CREATE DATABASE \`${TARGET_DB_NAME}\`;"
    mariadb "$TARGET_DB_NAME" < "$DUMP_FILE"

    configure_wp_config "$TARGET_ROOT" "$TARGET_DB_NAME" "$TARGET_DB_USER" "$TARGET_DB_PASS"
    isolate_wp_identity "$TARGET_ROOT" "$TARGET_DOMAIN"
    configure_wp_cron "$TARGET_ROOT" "$TARGET_DOMAIN" "$PRESERVE_WP_CRON"

    if [ "$RUN_SEARCH_REPLACE" = "1" ]; then
        run_search_replace "$TARGET_ROOT" "$SOURCE_DOMAIN" "$TARGET_DOMAIN" "$TARGET_SCHEME"
    fi

    if [ "$KEEP_TARGET_SSL" = "1" ]; then
        log "Keeping target SSL and existing Nginx domain configuration for ${TARGET_DOMAIN}."
    fi
fi

log "Flushing WordPress cache..."
run_wp_cli cache flush --path="$TARGET_ROOT" >/dev/null 2>&1 || true
run_wp_cli transient delete --all --path="$TARGET_ROOT" >/dev/null 2>&1 || true
run_wp_cli rewrite flush --hard --path="$TARGET_ROOT" >/dev/null 2>&1 || true

if nginx -t >/dev/null 2>&1; then
    systemctl reload nginx
else
    fail "Nginx config test failed after clone."
fi

[ "$MODE" != "overwrite" ] || prune_clone_backups "$TARGET_DOMAIN"

log "Clone completed successfully for ${TARGET_DOMAIN}."
echo "Clone completed successfully for ${TARGET_DOMAIN}."
