#!/bin/bash
set -euo pipefail

SOURCE_DOMAIN=""
MODE="new_domain"
TARGET_DOMAIN=""
PHP_VERSION=""
RUN_SEARCH_REPLACE="1"
TARGET_SCHEME="http"
PRESERVE_WP_CRON="0"
KEEP_TARGET_SSL="0"

while [ "$#" -gt 0 ]; do
    case "$1" in
        --source-domain)
            SOURCE_DOMAIN="${2:-}"
            shift 2
            ;;
        --mode)
            MODE="${2:-}"
            shift 2
            ;;
        --target-domain)
            TARGET_DOMAIN="${2:-}"
            shift 2
            ;;
        --php-version)
            PHP_VERSION="${2:-}"
            shift 2
            ;;
        --run-search-replace)
            RUN_SEARCH_REPLACE="${2:-1}"
            shift 2
            ;;
        --target-scheme)
            TARGET_SCHEME="${2:-http}"
            shift 2
            ;;
        --preserve-wp-cron)
            PRESERVE_WP_CRON="${2:-0}"
            shift 2
            ;;
        --keep-target-ssl)
            KEEP_TARGET_SSL="${2:-0}"
            shift 2
            ;;
        *)
            echo "Unknown argument: $1"
            exit 1
            ;;
    esac
done

if [ -z "$SOURCE_DOMAIN" ] || [ -z "$TARGET_DOMAIN" ]; then
    echo "Usage: $0 --source-domain <domain> --mode <new_domain|overwrite> --target-domain <domain> [options]"
    exit 1
fi

if [ "$SOURCE_DOMAIN" = "$TARGET_DOMAIN" ]; then
    echo "Source and target domains must be different."
    exit 1
fi

if [ "$MODE" != "new_domain" ] && [ "$MODE" != "overwrite" ]; then
    echo "Unsupported clone mode: $MODE"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
SOURCE_ROOT="/var/www/$SOURCE_DOMAIN"
TARGET_ROOT="/var/www/$TARGET_DOMAIN"
WP_CLI_RUNTIME_BASE="/var/cache/wootify/wp-cli"
WP_CLI_HOME=""
WP_CLI_CACHE_DIR=""
# Derive per-site pool username for the TARGET domain (same formula as create_site.sh)
TARGET_POOL_USER="$(printf '%s' "${TARGET_DOMAIN//./_}" | cut -c1-32)"

source "${SCRIPT_DIR}/logging.sh"
source "${SCRIPT_DIR}/os_detect.sh"
source "${SCRIPT_DIR}/permissions.sh"

LOG_FILE="$(resolve_log_file "wootify_clone.log")"
BACKUP_ROOT="${PROJECT_DIR}/storage/backups/site-clone"

log() {
    echo "[INFO] $1"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [CLONE] $1" >> "${LOG_FILE}"
}

fail() {
    log "$1"
    echo "$1"
    exit 1
}

trap 'fail "Clone failed on line ${LINENO}."' ERR

ensure_wp_cli() {
    # Check the canonical install path directly — avoids PATH stripping issues
    # and prevents accidentally downloading a corrupt/invalid phar from GitHub.
    if [ -x /usr/local/bin/wp ]; then
        return 0
    fi
    fail "WP-CLI not found at /usr/local/bin/wp. Please install WP-CLI before cloning a site."
}

# ----- per-site pool helpers (mirrors create_site.sh) -----
resolve_per_site_pool_dir() {
    if [ "$IS_DEBIAN" = true ]; then
        printf '/etc/php/%s/fpm/pool.d' "$PHP_VERSION"
    else
        printf '/etc/php-fpm.d'
    fi
}

resolve_per_site_socket_dir() {
    if [ "$IS_DEBIAN" = true ]; then
        printf '/run/php'
    else
        printf '/run/php-fpm'
    fi
}

reload_php_fpm_for_pool() {
    local svc
    svc="$(resolve_php_fpm_service_name "$PHP_VERSION" 2>/dev/null || true)"
    [ -z "$svc" ] && svc="php-fpm"
    if systemctl is-active --quiet "$svc" 2>/dev/null; then
        systemctl reload "$svc"
    else
        systemctl restart "$svc"
    fi
}

create_target_pool_user() {
    if id "$TARGET_POOL_USER" >/dev/null 2>&1; then
        log "Pool user $TARGET_POOL_USER already exists — reusing."
        return 0
    fi
    log "Creating system pool user: $TARGET_POOL_USER"
    useradd \
        --system \
        --no-create-home \
        --shell /sbin/nologin \
        --comment "WooPanel PHP pool ${TARGET_DOMAIN}" \
        --gid "$WEB_GROUP" \
        "$TARGET_POOL_USER" 2>/dev/null || \
    useradd \
        --system \
        --no-create-home \
        --shell /sbin/nologin \
        --comment "WooPanel PHP pool ${TARGET_DOMAIN}" \
        "$TARGET_POOL_USER"
    usermod -aG "$WEB_GROUP" "$TARGET_POOL_USER" 2>/dev/null || true
    log "Pool user created: $TARGET_POOL_USER"
}

create_target_fpm_pool() {
    local pool_dir socket_dir socket_path pool_conf_path
    pool_dir="$(resolve_per_site_pool_dir)"
    socket_dir="$(resolve_per_site_socket_dir)"
    socket_path="${socket_dir}/${TARGET_DOMAIN}.sock"
    pool_conf_path="${pool_dir}/${TARGET_DOMAIN}.conf"

    if [ -f "$pool_conf_path" ]; then
        if [ "$MODE" = "overwrite" ]; then
            log "Overwriting existing PHP-FPM pool conf: $pool_conf_path"
        else
            log "PHP-FPM pool conf already exists: $pool_conf_path — skipping"
            return 0
        fi
    fi

    log "Creating PHP-FPM pool conf: $pool_conf_path"
    cat > "$pool_conf_path" <<POOLEOF
; WooPanel per-site pool for ${TARGET_DOMAIN}
[${TARGET_DOMAIN}]
user = ${TARGET_POOL_USER}
group = ${WEB_GROUP}
listen = ${socket_path}
listen.owner = ${WEB_USER}
listen.group = ${WEB_GROUP}
listen.mode = 0660
pm = ondemand
pm.max_children = 10
pm.process_idle_timeout = 10s
pm.max_requests = 500
POOLEOF

    log "Reloading PHP-FPM to activate pool for $TARGET_DOMAIN..."
    reload_php_fpm_for_pool

    local i=0
    while [ $i -lt 15 ]; do
        [ -S "$socket_path" ] && break
        sleep 1
        i=$((i + 1))
    done
    if [ ! -S "$socket_path" ]; then
        log "Warning: per-site socket $socket_path not ready after 15s"
    fi
}
# -----------------------------------------------------------

prepare_wp_cli_runtime() {
    WP_CLI_HOME="${WP_CLI_RUNTIME_BASE}/${TARGET_POOL_USER}"
    WP_CLI_CACHE_DIR="${WP_CLI_HOME}/cache"

    install -d -m 755 -o "$TARGET_POOL_USER" -g "$WEB_GROUP" "$WP_CLI_HOME"
    install -d -m 755 -o "$TARGET_POOL_USER" -g "$WEB_GROUP" "$WP_CLI_CACHE_DIR"
}

run_wp_cli() {
    sudo -H -u "$TARGET_POOL_USER" env \
        HOME="$WP_CLI_HOME" \
        WP_CLI_CACHE_DIR="$WP_CLI_CACHE_DIR" \
        /usr/local/bin/wp --no-color "$@"
}

normalize_web_root_permissions() {
    local root="$1"

    chown -R "${TARGET_POOL_USER:-$WEB_USER}:$WEB_GROUP" "$root"
    find "$root" -type d ! -perm 755 -exec chmod 755 {} +
    find "$root" -type f ! -perm 644 -exec chmod 644 {} +

    if [ -f "$root/wp-config.php" ]; then
        chmod 640 "$root/wp-config.php"
    fi
}

dump_cmd() {
    if command -v mariadb-dump >/dev/null 2>&1; then
        echo "mariadb-dump"
        return 0
    fi
    if command -v mysqldump >/dev/null 2>&1; then
        echo "mysqldump"
        return 0
    fi
    return 1
}

read_wp_define() {
    local file="$1"
    local key="$2"
    sed -n "s/.*define([[:space:]]*'${key}'[[:space:]]*,[[:space:]]*'\\([^']*\\)'.*/\\1/p" "$file" | head -n1
}

random_suffix() {
    openssl rand -hex 3
}

create_database_credentials() {
    local suffix
    suffix="$(random_suffix)"
    NEW_DB_NAME="wp_${suffix}"
    NEW_DB_USER="user_${suffix}"
    NEW_DB_PASS="$(openssl rand -base64 12)"
}

create_database() {
    local db_name="$1"
    local db_user="$2"
    local db_pass="$3"

    log "Creating database ${db_name}..."
    mariadb -e "CREATE DATABASE IF NOT EXISTS \`${db_name}\`;"
    mariadb -e "CREATE USER IF NOT EXISTS '${db_user}'@'localhost' IDENTIFIED BY '${db_pass}';"
    mariadb -e "GRANT ALL PRIVILEGES ON \`${db_name}\`.* TO '${db_user}'@'localhost';"
    mariadb -e "FLUSH PRIVILEGES;"
}

render_nginx_config() {
    local domain="$1"
    local web_root="$2"
    local php_version="$3"
    local nginx_conf="$4"
    local php_fpm_sock=""

    # Prefer the per-site socket if it already exists (created by create_target_fpm_pool)
    local socket_dir
    socket_dir="$(resolve_per_site_socket_dir)"
    if [ -S "${socket_dir}/${domain}.sock" ]; then
        php_fpm_sock="${socket_dir}/${domain}.sock"
    else
        php_fpm_sock="$(resolve_php_fpm_socket_for_version "$php_version" || true)"
    fi
    if [ -z "$php_fpm_sock" ]; then
        fail "Unable to resolve PHP-FPM socket for PHP ${php_version}"
    fi

    cat > "$nginx_conf" <<EOF
server {
    listen 80;
    server_name $domain www.$domain;
    root $web_root;
    index index.php index.html index.htm;
    client_max_body_size 256M;
    set \$wootify_https off;

        # Logs
    access_log /var/log/nginx/${domain}_access.log;
    error_log /var/log/nginx/${domain}_error.log;

    if (\$scheme = https) {
        set \$wootify_https on;
    }

    if (\$http_x_forwarded_proto = "https") {
        set \$wootify_https on;
    }

    location = /favicon.ico {
        access_log off;
        log_not_found off;
        expires 7d;
        add_header Cache-Control "public, max-age=604800";
        try_files \$uri =204;
    }

    location = /robots.txt {
        access_log off;
        log_not_found off;
        try_files \$uri /index.php?\$args;
    }

    location = /xmlrpc.php {
        deny all;
        access_log off;
        log_not_found off;
    }

    location = /wp-config.php {
        deny all;
        access_log off;
        log_not_found off;
    }

    location ~* /(?:readme|license)\.(?:html|txt)$ {
        deny all;
        access_log off;
        log_not_found off;
    }

    location ~ /\.(?!well-known) {
        deny all;
        access_log off;
        log_not_found off;
    }

    location ~* /(composer\.(json|lock)|package(-lock)?\.json|yarn\.lock|\.env) {
        deny all;
        access_log off;
        log_not_found off;
    }

    location ~* \.(?:css|js|jpg|jpeg|gif|png|svg|ico|webp|avif|woff|woff2|ttf|eot)$ {
        expires 30d;
        access_log off;
        log_not_found off;
        add_header Cache-Control "public, max-age=2592000, immutable";
        try_files \$uri =404;
    }

    location / {
        try_files \$uri \$uri/ /index.php?\$args;
    }

    location ~ \.php$ {
        try_files \$uri =404;
        fastcgi_pass unix:${php_fpm_sock};
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_param HTTPS \$wootify_https;
        fastcgi_param HTTP_X_FORWARDED_PROTO \$http_x_forwarded_proto;
        fastcgi_param HTTP_CF_VISITOR \$http_cf_visitor;
        fastcgi_buffer_size 256k;
        fastcgi_buffers 16 256k;
        fastcgi_busy_buffers_size 512k;
        fastcgi_temp_file_write_size 512k;
        fastcgi_read_timeout 600;
        fastcgi_intercept_errors on;
        include fastcgi_params;
    }

    location ~ /\.ht {
        deny all;
    }
}
EOF

    # Now using conf.d for all distributions for consistency
}

copy_site_files() {
    local source_root="$1"
    local target_root="$2"

    mkdir -p "$target_root"
    shopt -s dotglob nullglob
    rm -rf "${target_root:?}/"*
    shopt -u dotglob nullglob
    cp -a "${source_root}/." "${target_root}/"
}

configure_wp_config() {
    local root="$1"
    local db_name="$2"
    local db_user="$3"
    local db_pass="$4"

    run_wp_cli config set DB_NAME "$db_name" --type=constant --path="$root" >/dev/null
    run_wp_cli config set DB_USER "$db_user" --type=constant --path="$root" >/dev/null
    run_wp_cli config set DB_PASSWORD "$db_pass" --type=constant --path="$root" >/dev/null
}

configure_wp_cron() {
    local root="$1"
    local target_domain="$2"
    local preserve="$3"
    local cron_file="/etc/cron.d/wpcron_${target_domain//./_}"

    if [ "$preserve" = "1" ]; then
        run_wp_cli config set DISABLE_WP_CRON true --raw --type=constant --path="$root" >/dev/null 2>&1 || true
        return 0
    fi

    run_wp_cli config delete DISABLE_WP_CRON --type=constant --path="$root" >/dev/null 2>&1 || true
    rm -f "$cron_file"
}

run_search_replace() {
    local root="$1"
    local source_domain="$2"
    local target_domain="$3"
    local target_scheme="$4"

    log "Updating WordPress URLs from ${source_domain} to ${target_domain}..."

    run_wp_cli option update home "${target_scheme}://${target_domain}" --path="$root" >/dev/null
    run_wp_cli option update siteurl "${target_scheme}://${target_domain}" --path="$root" >/dev/null

    for src in \
        "http://${source_domain}" \
        "https://${source_domain}" \
        "http://www.${source_domain}" \
        "https://www.${source_domain}"; do
        local dest
        if [[ "$src" == *"www.${source_domain}" ]]; then
            dest="${target_scheme}://www.${target_domain}"
        else
            dest="${target_scheme}://${target_domain}"
        fi
        run_wp_cli search-replace "$src" "$dest" --path="$root" --skip-columns=guid --quiet || true
    done
}

backup_target_site() {
    local target_root="$1"
    local target_db_name="$2"
    local target_domain="$3"

    local ts
    ts="$(date '+%Y%m%d-%H%M%S')"
    local backup_dir="${BACKUP_ROOT}/${target_domain}-${ts}"
    install -d -m 750 -o root -g "$WEB_GROUP" "$backup_dir"

    log "Creating safety backup for ${target_domain} at ${backup_dir}..."
    tar -czf "${backup_dir}/files.tar.gz" -C "$target_root" . >/dev/null 2>&1 || true
    "$(dump_cmd)" "$target_db_name" > "${backup_dir}/database.sql" 2>/dev/null || true
    chmod 640 "${backup_dir}/files.tar.gz" 2>/dev/null || true
    chmod 640 "${backup_dir}/database.sql" 2>/dev/null || true
}

require_root "clone_site.sh"
install -d -m 750 -o root -g "$WEB_GROUP" "$BACKUP_ROOT"
ensure_wp_cli

# For new_domain: create pool user first so prepare_wp_cli_runtime can use it
# For overwrite: pool user was created by create_site.sh; verify or fall back
if [ "$MODE" = "new_domain" ]; then
    create_target_pool_user
else
    if ! id "$TARGET_POOL_USER" >/dev/null 2>&1; then
        log "Warning: pool user $TARGET_POOL_USER not found; falling back to $WEB_USER"
        TARGET_POOL_USER="$WEB_USER"
    fi
fi

prepare_wp_cli_runtime

[ -d "$SOURCE_ROOT" ] || fail "Source web root not found: $SOURCE_ROOT"
[ -f "$SOURCE_ROOT/wp-config.php" ] || fail "Only WordPress source sites are supported right now."

SOURCE_DB_NAME="$(read_wp_define "$SOURCE_ROOT/wp-config.php" "DB_NAME")"
SOURCE_DB_USER="$(read_wp_define "$SOURCE_ROOT/wp-config.php" "DB_USER")"
SOURCE_DB_PASS="$(read_wp_define "$SOURCE_ROOT/wp-config.php" "DB_PASSWORD")"
[ -n "$SOURCE_DB_NAME" ] || fail "Could not read source database credentials."

DUMP_TOOL="$(dump_cmd)" || fail "mysqldump/mariadb-dump is required for site clone."
DUMP_FILE="$(mktemp /tmp/woopanel-clone-db-XXXXXX.sql)"
trap 'rm -f "$DUMP_FILE"' EXIT

if [ -z "$PHP_VERSION" ]; then
    PHP_VERSION="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || true)"
    [ -n "$PHP_VERSION" ] || PHP_VERSION="$(ls /etc/php 2>/dev/null | grep -E '^[0-9]+\.[0-9]+$' | sort -V | tail -n1 || true)"
    [ -n "$PHP_VERSION" ] || PHP_VERSION="8.3"
fi

log "Cloning ${SOURCE_DOMAIN} -> ${TARGET_DOMAIN} (${MODE})..."
log "Exporting source database ${SOURCE_DB_NAME}..."
"$DUMP_TOOL" "$SOURCE_DB_NAME" > "$DUMP_FILE"

if [ "$MODE" = "new_domain" ]; then
    if [ -e "$TARGET_ROOT" ]; then
        fail "Target web root already exists: $TARGET_ROOT"
    fi

    # Now using conf.d for all distributions for consistency
    TARGET_NGINX_CONF="${NGINX_CONF_DIR}/${TARGET_DOMAIN}.conf"
    [ ! -e "$TARGET_NGINX_CONF" ] || fail "Nginx configuration already exists for ${TARGET_DOMAIN}"

    create_database_credentials
    create_database "$NEW_DB_NAME" "$NEW_DB_USER" "$NEW_DB_PASS"

    log "Creating PHP-FPM pool for ${TARGET_DOMAIN}..."
    create_target_fpm_pool

    log "Copying website files to ${TARGET_ROOT}..."
    install -d -m 755 -o "$TARGET_POOL_USER" -g "$WEB_GROUP" "$TARGET_ROOT"
    cp -a "${SOURCE_ROOT}/." "${TARGET_ROOT}/"
    normalize_web_root_permissions "$TARGET_ROOT"

    log "Importing database into ${NEW_DB_NAME}..."
    mariadb "$NEW_DB_NAME" < "$DUMP_FILE"
    configure_wp_config "$TARGET_ROOT" "$NEW_DB_NAME" "$NEW_DB_USER" "$NEW_DB_PASS"
    configure_wp_cron "$TARGET_ROOT" "$TARGET_DOMAIN" "$PRESERVE_WP_CRON"

    if [ "$RUN_SEARCH_REPLACE" = "1" ]; then
        run_search_replace "$TARGET_ROOT" "$SOURCE_DOMAIN" "$TARGET_DOMAIN" "$TARGET_SCHEME"
    fi

    log "Generating Nginx config for ${TARGET_DOMAIN}..."
    render_nginx_config "$TARGET_DOMAIN" "$TARGET_ROOT" "$PHP_VERSION" "$TARGET_NGINX_CONF"
else
    [ -d "$TARGET_ROOT" ] || fail "Target web root not found: $TARGET_ROOT"
    [ -f "$TARGET_ROOT/wp-config.php" ] || fail "Only WordPress target sites are supported for overwrite mode."

    TARGET_DB_NAME="$(read_wp_define "$TARGET_ROOT/wp-config.php" "DB_NAME")"
    TARGET_DB_USER="$(read_wp_define "$TARGET_ROOT/wp-config.php" "DB_USER")"
    TARGET_DB_PASS="$(read_wp_define "$TARGET_ROOT/wp-config.php" "DB_PASSWORD")"
    [ -n "$TARGET_DB_NAME" ] || fail "Could not read target database credentials."

    backup_target_site "$TARGET_ROOT" "$TARGET_DB_NAME" "$TARGET_DOMAIN"

    log "Replacing target files in ${TARGET_ROOT}..."
    copy_site_files "$SOURCE_ROOT" "$TARGET_ROOT"
    normalize_web_root_permissions "$TARGET_ROOT"

    log "Refreshing target database ${TARGET_DB_NAME}..."
    mariadb -e "DROP DATABASE IF EXISTS \`${TARGET_DB_NAME}\`;"
    mariadb -e "CREATE DATABASE \`${TARGET_DB_NAME}\`;"
    mariadb "$TARGET_DB_NAME" < "$DUMP_FILE"

    configure_wp_config "$TARGET_ROOT" "$TARGET_DB_NAME" "$TARGET_DB_USER" "$TARGET_DB_PASS"
    configure_wp_cron "$TARGET_ROOT" "$TARGET_DOMAIN" "$PRESERVE_WP_CRON"

    if [ "$RUN_SEARCH_REPLACE" = "1" ]; then
        run_search_replace "$TARGET_ROOT" "$SOURCE_DOMAIN" "$TARGET_DOMAIN" "$TARGET_SCHEME"
    fi

    if [ "$KEEP_TARGET_SSL" = "1" ]; then
        log "Keeping target SSL and existing Nginx domain configuration for ${TARGET_DOMAIN}."
    fi
fi

log "Flushing WordPress cache..."
run_wp_cli cache flush --path="$TARGET_ROOT" >/dev/null 2>&1 || true
run_wp_cli transient delete --all --path="$TARGET_ROOT" >/dev/null 2>&1 || true
run_wp_cli rewrite flush --hard --path="$TARGET_ROOT" >/dev/null 2>&1 || true

if nginx -t >/dev/null 2>&1; then
    systemctl reload nginx
else
    fail "Nginx config test failed after clone."
fi

log "Clone completed successfully for ${TARGET_DOMAIN}."
echo "Clone completed successfully for ${TARGET_DOMAIN}."
