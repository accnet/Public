#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive

ACTION=$1
source "$(dirname "$0")/logging.sh"
source "$(dirname "$0")/permissions.sh"
LOG_FILE="$(resolve_log_file "wootify_install.log")"

log() {
    echo "[REDIS-SERVER] $1"
    echo "[REDIS-SERVER] $1" >> "$LOG_FILE"
}

source "$(dirname "$0")/os_detect.sh"

require_root "install_redis.sh"

resolve_redis_config_file() {
    local candidates=(
        "/etc/redis/redis.conf"
        "/etc/redis.conf"
    )
    local candidate

    for candidate in "${candidates[@]}"; do
        if [ -f "$candidate" ]; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done

    printf '%s\n' "/etc/redis/redis.conf"
    return 1
}

replace_or_append_redis_setting() {
    local file="$1"
    local key="$2"
    local value="$3"

    if grep -Eq "^[#[:space:]]*${key}[[:space:]]+" "$file" 2>/dev/null; then
        sed -i -E "s|^[#[:space:]]*${key}[[:space:]]+.*|${key} ${value}|" "$file"
    else
        echo "${key} ${value}" >> "$file"
    fi
}

calculate_redis_maxmemory() {
    local mem_mb

    mem_mb=$(( $(awk '/MemTotal/ {print $2}' /proc/meminfo) / 1024 ))

    if [ "$mem_mb" -ge 8192 ]; then
        echo "256mb"
    elif [ "$mem_mb" -ge 4096 ]; then
        echo "192mb"
    elif [ "$mem_mb" -ge 2048 ]; then
        echo "128mb"
    else
        echo "64mb"
    fi
}

configure_redis_object_cache_defaults() {
    local redis_conf
    local redis_maxmemory

    redis_conf="$(resolve_redis_config_file)"
    redis_maxmemory="$(calculate_redis_maxmemory)"

    mkdir -p "$(dirname "$redis_conf")"
    touch "$redis_conf"

    replace_or_append_redis_setting "$redis_conf" "maxmemory" "$redis_maxmemory"
    replace_or_append_redis_setting "$redis_conf" "maxmemory-policy" "allkeys-lru"
    replace_or_append_redis_setting "$redis_conf" "tcp-keepalive" "60"

    log "Configured Redis object cache defaults: maxmemory=${redis_maxmemory}, policy=allkeys-lru"
}

if [ "$ACTION" == "install" ]; then
    log "Installing Redis Server..."
    if [ "$IS_DEBIAN" = true ]; then
        apt-get update
        apt-get install -y redis-server
    elif [ "$IS_RHEL" = true ]; then
        $PKG_MANAGER install -y epel-release
        $PKG_MANAGER install -y redis
    fi
    configure_redis_object_cache_defaults
    if [ "$IS_DEBIAN" = true ]; then
        systemctl enable redis-server
        if ! systemctl start redis-server; then
            log "Warning: redis-server failed to start. Checking if port 6379 is already in use..."
            if ss -tln | grep -q ':6379 '; then
                log "Port 6379 is already in use by another Redis instance. Continuing with PHP extension install."
            else
                log "ERROR: Redis server failed to start and port 6379 is not reachable."
                exit 1
            fi
        fi
    elif [ "$IS_RHEL" = true ]; then
        systemctl enable redis
        if ! systemctl start redis; then
            log "Warning: redis failed to start. Checking if port 6379 is already in use..."
            if ss -tln | grep -q ':6379 '; then
                log "Port 6379 is already in use by another Redis instance. Continuing with PHP extension install."
            else
                log "ERROR: Redis server failed to start and port 6379 is not reachable."
                exit 1
            fi
        fi
    fi
    log "Redis Server installed successfully."

    log "Installing PHP Redis Extension..."
    bash "$(dirname "$0")/manage_extension.sh" install redis

elif [ "$ACTION" == "uninstall" ]; then
    log "Uninstalling Redis Server..."
    if [ "$IS_DEBIAN" = true ]; then
        systemctl stop redis-server || true
        systemctl disable redis-server || true
    elif [ "$IS_RHEL" = true ]; then
        systemctl stop redis || true
        systemctl disable redis || true
    fi
    if [ "$IS_DEBIAN" = true ]; then
        apt-get remove -y redis-server
        apt-get autoremove -y
    elif [ "$IS_RHEL" = true ]; then
        $PKG_MANAGER remove -y redis
    fi
    log "Redis Server uninstalled successfully."

    log "Uninstalling PHP Redis Extension..."
    bash "$(dirname "$0")/manage_extension.sh" uninstall redis

else
    echo "Usage: $0 [install|uninstall]"
    exit 1
fi
