#!/bin/bash
# Shared Nginx server block for WooPanel WordPress sites.
# Sourced by create_site.sh and clone_site.sh so both produce identical
# (security-hardened, FastCGI-cache-aware) configs.

nginx_has_wootify_cache_zone() {
    grep -Rqs 'keys_zone=WOOTIFY:' /etc/nginx/nginx.conf /etc/nginx/conf.d
}

# Usage: render_wp_site_nginx_conf <domain> <web_root> <php_fpm_sock> <out_file>
render_wp_site_nginx_conf() {
    local domain="$1" web_root="$2" php_fpm_sock="$3" out="$4"
    local cf_directive="" cache_directives=""

    [ ! -f /etc/nginx/woopanel-cloudflare-gate.conf ] || cf_directive="include /etc/nginx/woopanel-cloudflare-gate.conf;"
    if nginx_has_wootify_cache_zone; then
        cache_directives='        fastcgi_cache WOOTIFY;
        fastcgi_cache_valid 200 301 302 10m;
        fastcgi_cache_bypass $no_cache;
        fastcgi_no_cache $no_cache;
        add_header X-Cache-Status $upstream_cache_status;'
    fi

cat > "$out" <<EOF
server {
    listen 80;
    server_name $domain www.$domain;
    $cf_directive
    root $web_root;
    index index.php index.html index.htm;
    client_max_body_size 256M;

    # Security headers
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;

    set \$wootify_https off;

    # Skip FastCGI cache for: POST requests, admin, WooCommerce dynamic pages,
    # logged-in users, and users with items in cart.
    set \$no_cache 0;
    if (\$request_method = POST)                    { set \$no_cache 1; }
    if (\$request_uri ~* "/wp-(?:admin|login\.php)") { set \$no_cache 1; }
    if (\$request_uri ~* "/(?:cart|checkout|my-account|addons)(?:/|\$)") {
        set \$no_cache 1;
    }
    if (\$arg_add_to_cart != "") { set \$no_cache 1; }
    if (\$arg_wc_ajax != "")     { set \$no_cache 1; }
    if (\$cookie_woocommerce_items_in_cart = "1") { set \$no_cache 1; }
    if (\$http_cookie ~* "wordpress_logged_in_") { set \$no_cache 1; }

    # Logs (buffered for less I/O)
    access_log /var/log/nginx/${domain}_access.log main buffer=32k;
    error_log /var/log/nginx/${domain}_error.log;

    if (\$scheme = https) {
        set \$wootify_https on;
    }

    if (\$http_x_forwarded_proto = "https") {
        set \$wootify_https on;
    }

    location = /favicon.ico {
        access_log off;
        log_not_found off;
        expires 7d;
        add_header Cache-Control "public, max-age=604800";
        try_files \$uri =204;
    }

    location = /robots.txt {
        access_log off;
        log_not_found off;
        try_files \$uri /index.php?\$args;
    }

    location = /sitemap.xml {
        access_log off;
        log_not_found off;
        try_files \$uri /index.php?\$args;
    }

    location = /sitemap_index.xml {
        access_log off;
        log_not_found off;
        try_files \$uri /index.php?\$args;
    }

    location = /xmlrpc.php {
        deny all;
        access_log off;
        log_not_found off;
    }

    location = /wp-config.php {
        deny all;
        access_log off;
        log_not_found off;
    }

    # Block PHP execution inside uploads (most common WP RCE vector).
    # Catches .php, .php5, .phtml and dual-extension tricks like .php.jpg.
    location ~* /wp-content/uploads/.*\.php(\..*)? {
        deny all;
        access_log off;
        log_not_found off;
    }

    # Block direct HTTP access to wp-includes PHP files.
    # WordPress loads these via PHP include, never via direct HTTP request.
    location ~* /wp-includes/.*\.php {
        deny all;
        access_log off;
        log_not_found off;
    }

    location ~* /(?:readme|license)\.(?:html|txt)$ {
        deny all;
        access_log off;
        log_not_found off;
    }

    location ~ /\.(?!well-known) {
        deny all;
        access_log off;
        log_not_found off;
    }

    location ~* /(composer\.(json|lock)|package(-lock)?\.json|yarn\.lock|\.env) {
        deny all;
        access_log off;
        log_not_found off;
    }

    # Cache static assets (1 day expiry — CSS/JS changes picked up quickly)
    location ~* \.(?:css|js|jpg|jpeg|gif|png|svg|ico|webp|avif|woff|woff2|ttf|eot)$ {
        expires 1d;
        access_log off;
        log_not_found off;
        add_header Cache-Control "public, max-age=86400";
        try_files \$uri =404;
    }

    # WordPress REST API — cache GET requests, bypass on mutations
    location ~* /wp-json/ {
        try_files \$uri /index.php?\$args;
    }

    location / {
        try_files \$uri \$uri/ /index.php?\$args;
    }

    location ~ \.php$ {
        try_files \$uri =404;
        fastcgi_pass unix:$php_fpm_sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_param HTTPS \$wootify_https;
        fastcgi_param HTTP_X_FORWARDED_PROTO \$http_x_forwarded_proto;
        fastcgi_param HTTP_CF_VISITOR \$http_cf_visitor;
        fastcgi_connect_timeout 60s;
        fastcgi_send_timeout 60s;
        fastcgi_read_timeout 300s;
        fastcgi_buffer_size 32k;
        fastcgi_buffers 8 16k;
        fastcgi_busy_buffers_size 64k;
        fastcgi_temp_file_write_size 64k;
        fastcgi_max_temp_file_size 0;
        fastcgi_pass_request_headers on;
        fastcgi_cache_background_update on;
        fastcgi_cache_lock_timeout 5s;
$cache_directives
        include fastcgi_params;
    }

    location ~ /\.ht {
        deny all;
    }
}
EOF
}
