#!/bin/bash
# repair_permissions.sh — audit / repair / undo file permissions of a site
# after an attack.
#
# Usage: repair_permissions.sh <domain> audit|apply|undo
#
# audit  read-only; prints "CHECK|<key>|<count>|<examples>" lines + "SUMMARY|<total>"
# apply  saves a manifest (for undo), then: chattr -i, quarantines symlinks that
#        leave the web root, chown -h to the pool user, dirs 755 / files 644
#        (drops exec, setuid/setgid, world-write), wp-config.php 600, SELinux
#        contexts, removes the pool user's crontab (backed up) and kills stray
#        processes of the pool user, then restarts PHP-FPM.
# undo   restores ownership/modes, crontab and quarantined symlinks from the
#        latest repair.
set -euo pipefail

DOMAIN="${1:-}"
ACTION="${2:-audit}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
source "${SCRIPT_DIR}/logging.sh"
source "${SCRIPT_DIR}/permissions.sh"
source "${SCRIPT_DIR}/os_detect.sh"

validate_site_domain "$DOMAIN" || { echo "Invalid domain" >&2; exit 1; }
LOG_FILE="$(resolve_log_file "wootify_malware.log")"
log() { echo "$(date '+%Y-%m-%d %H:%M:%S') [PERM-REPAIR] ${DOMAIN} $1" >> "$LOG_FILE"; }

WEB_ROOT="/var/www/${DOMAIN}"
QUARANTINE_DIR="${WEB_ROOT}/.woopanel-quarantine"
STATE_ROOT="${PROJECT_DIR}/storage/permissions-repair/${DOMAIN}"
[ -d "$WEB_ROOT" ] || { echo "Web root not found: ${WEB_ROOT}" >&2; exit 1; }

POOL_USER="$(resolve_pool_user_from_config "$DOMAIN" || true)"
[ -n "$POOL_USER" ] && id "$POOL_USER" >/dev/null 2>&1 || { echo "Pool user for ${DOMAIN} not found" >&2; exit 1; }
SITE_GROUP="$WEB_GROUP"

# Every walk is physical (-P): never follow a symlink planted by an attacker,
# or chown/chmod would hand e.g. /etc/shadow to the pool user.
site_find() {
    find -P "$WEB_ROOT" -path "$QUARANTINE_DIR" -prune -o "$@" -print0
}

crontab_file() {
    local f
    for f in "/var/spool/cron/crontabs/${POOL_USER}" "/var/spool/cron/${POOL_USER}"; do
        [ -f "$f" ] && { printf '%s\n' "$f"; return 0; }
    done
    return 1
}

# Killing processes / dropping the crontab is only safe for a dedicated
# WooPanel pool account (nologin shell, our GECOS marker) — never for a real
# login user that a misconfigured pool could point at.
is_dedicated_pool_user() {
    local entry shell comment
    entry="$(getent passwd "$POOL_USER")" || return 1
    comment="$(printf '%s' "$entry" | cut -d: -f5)"
    shell="$(printf '%s' "$entry" | cut -d: -f7)"
    case "$shell" in */nologin|*/false) ;; *) return 1 ;; esac
    case "$comment" in "WooPanel PHP pool "*) return 0 ;; *) return 1 ;; esac
}

# PIDs of the pool user that are not PHP-FPM workers (a backdoor daemon,
# a miner, a reverse shell...).
stray_pids() {
    ps -u "$POOL_USER" -o pid=,comm= 2>/dev/null | awk '$2 !~ /^php-fpm/ {print $1}'
}

immutable_paths() {
    command -v lsattr >/dev/null 2>&1 || return 0
    # lsattr prints "<flags> <path>"; the immutable flag is "i".
    lsattr -R -a "$WEB_ROOT" 2>/dev/null | awk '$1 ~ /i/ && NF >= 2 { $1 = ""; sub(/^ /, ""); print }' \
        | grep -v -F "$QUARANTINE_DIR" | grep -v '/\.\.\?$' || true
}

outside_symlinks() {
    local link target
    while IFS= read -r -d '' link; do
        target="$(readlink -m -- "$link")"
        case "$target" in
            "$WEB_ROOT"|"$WEB_ROOT"/*) ;;
            *) printf '%s\n' "$link" ;;
        esac
    done < <(site_find -type l)
}

# "count|examples" from NUL-separated paths on stdin.
summarize() {
    tr '\0' '\n' | awk -v root="$WEB_ROOT/" 'NF { n++; if (n <= 5) { sub("^" root, ""); ex = ex (ex ? "; " : "") $0 } } END { printf "%d|%s", n + 0, ex }'
}

audit() {
    local total=0 line count
    emit() {
        count="${2%%|*}"
        total=$((total + count))
        echo "CHECK|$1|$2"
    }
    emit wrong_owner "$(site_find ! -type l \( ! -user "$POOL_USER" -o ! -group "$SITE_GROUP" \) | summarize)"
    emit world_writable "$(site_find ! -type l -perm -0002 | summarize)"
    # All pool users share the web group, so group-writable means "writable by
    # every other site on this server".
    emit group_writable "$(site_find ! -type l -perm -0020 | summarize)"
    emit setid "$(site_find ! -type l -perm /6000 | summarize)"
    emit executable_files "$(site_find -type f -perm /111 | summarize)"
    emit immutable "$(immutable_paths | tr '\n' '\0' | summarize)"
    emit outside_symlinks "$(outside_symlinks | tr '\n' '\0' | summarize)"
    if [ -f "$WEB_ROOT/wp-config.php" ]; then
        line="$(stat -c '%a %U' "$WEB_ROOT/wp-config.php")"
        if [ "$line" = "600 ${POOL_USER}" ]; then emit wp_config "0|"; else emit wp_config "1|wp-config.php is ${line} (expected 600 ${POOL_USER})"; fi
    fi
    if ! is_dedicated_pool_user; then
        # Not a WooPanel pool account: its crontab/processes are not the site's.
        emit crontab "0|"
        emit stray_processes "0|"
    elif crontab_file >/dev/null && [ -s "$(crontab_file)" ]; then
        emit crontab "1|$(grep -v '^#' "$(crontab_file)" | grep -v '^\s*$' | head -n 3 | tr '\n|' '; ' )"
        emit stray_processes "$(ps -u "$POOL_USER" -o comm=,args= 2>/dev/null | awk '$1 !~ /^php-fpm/' | head -n 5 | tr '|' '/' | tr '\n' '\0' | summarize)"
    else
        emit crontab "0|"
        emit stray_processes "$(ps -u "$POOL_USER" -o comm=,args= 2>/dev/null | awk '$1 !~ /^php-fpm/' | head -n 5 | tr '|' '/' | tr '\n' '\0' | summarize)"
    fi
    echo "SUMMARY|${total}"
}

apply_repair() {
    require_root "repair_permissions.sh apply"
    local stamp state path dest rel cron pid
    stamp="$(date '+%Y%m%d-%H%M%S')"
    state="${STATE_ROOT}/${stamp}"
    install -d -m 0700 "$state" "$state/symlinks"

    log "Saving permission manifest to ${state}"
    # NUL-delimited "mode uid gid path" records (same format as isolation).
    site_find \( -type d -o -type f \) | while IFS= read -r -d '' path; do
        stat --printf='%a %u %g %n\0' -- "$path"
    done > "$state/manifest"

    if command -v chattr >/dev/null 2>&1; then
        while IFS= read -r path; do
            [ -n "$path" ] && chattr -i -- "$path" 2>/dev/null && printf '%s\0' "$path" >> "$state/immutable"
        done < <(immutable_paths)
    fi

    while IFS= read -r path; do
        [ -n "$path" ] || continue
        rel="${path#"$WEB_ROOT"/}"
        dest="$state/symlinks/$rel"
        mkdir -p -- "$(dirname -- "$dest")"
        mv -- "$path" "$dest"
        log "Quarantined symlink ${rel} -> $(readlink -- "$dest")"
    done < <(outside_symlinks)

    site_find ! -type l -exec chown -h "${POOL_USER}:${SITE_GROUP}" {} + >/dev/null
    find -P "$WEB_ROOT" -path "$QUARANTINE_DIR" -prune -o -type d -exec chmod 0755 {} + >/dev/null
    find -P "$WEB_ROOT" -path "$QUARANTINE_DIR" -prune -o -type f -exec chmod 0644 {} + >/dev/null
    [ ! -f "$WEB_ROOT/wp-config.php" ] || chmod 0600 "$WEB_ROOT/wp-config.php"
    apply_wp_selinux_contexts "$WEB_ROOT"

    local killed=0
    if ! is_dedicated_pool_user; then
        log "Skipping crontab/process cleanup: ${POOL_USER} is not a dedicated WooPanel pool user"
        echo "Warning: ${POOL_USER} is not a dedicated WooPanel pool user; crontab and processes were left alone." >&2
    elif cron="$(crontab_file)"; then
        cp -p -- "$cron" "$state/crontab"
        printf '%s\n' "$cron" > "$state/crontab.path"
        rm -f -- "$cron"
        log "Removed crontab of ${POOL_USER} (backed up)"
    fi

    for pid in $( is_dedicated_pool_user && stray_pids ); do
        kill -TERM "$pid" 2>/dev/null && killed=$((killed + 1))
    done
    if [ "$killed" -gt 0 ]; then
        sleep 2
        for pid in $(stray_pids); do kill -KILL "$pid" 2>/dev/null || true; done
        log "Killed ${killed} stray process(es) of ${POOL_USER}"
    fi
    restart_php_fpm_for_version "$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || true)" || true

    # Keep the three most recent repairs.
    ls -1dt "${STATE_ROOT}"/[0-9]* 2>/dev/null | tail -n +4 | while IFS= read -r old; do rm -rf -- "$old"; done

    log "Permissions repaired (killed ${killed} process(es))"
    echo "Permissions repaired: owner ${POOL_USER}:${SITE_GROUP}, dirs 755, files 644, wp-config.php 600; ${killed} stray process(es) stopped."
}

undo_repair() {
    require_root "repair_permissions.sh undo"
    local state record mode uid gid path link dest
    state="$(ls -1dt "${STATE_ROOT}"/[0-9]* 2>/dev/null | head -n 1 || true)"
    [ -n "$state" ] && [ -f "$state/manifest" ] || { echo "No repair to undo" >&2; exit 1; }

    while IFS= read -r -d '' record; do
        mode="${record%% *}"; record="${record#* }"
        uid="${record%% *}"; record="${record#* }"
        gid="${record%% *}"; path="${record#* }"
        case "$path" in "$WEB_ROOT"|"$WEB_ROOT"/*) ;; *) echo "Invalid manifest entry" >&2; exit 1 ;; esac
        if [ -e "$path" ] && [ ! -L "$path" ]; then
            chown -h "${uid}:${gid}" -- "$path"
            chmod "$mode" -- "$path"
        fi
    done < "$state/manifest"

    if [ -d "$state/symlinks" ]; then
        while IFS= read -r -d '' link; do
            dest="$WEB_ROOT/${link#"$state/symlinks/"}"
            mkdir -p -- "$(dirname -- "$dest")"
            [ -e "$dest" ] || [ -L "$dest" ] || mv -- "$link" "$dest"
        done < <(find -P "$state/symlinks" -type l -print0)
    fi
    if [ -f "$state/immutable" ] && command -v chattr >/dev/null 2>&1; then
        while IFS= read -r -d '' path; do [ -e "$path" ] && chattr +i -- "$path" 2>/dev/null || true; done < "$state/immutable"
    fi
    if [ -f "$state/crontab" ] && [ -f "$state/crontab.path" ]; then
        cp -p -- "$state/crontab" "$(cat "$state/crontab.path")"
    fi
    rm -rf -- "$state"
    log "Permission repair undone"
    echo "Previous permissions restored."
}

case "$ACTION" in
    audit) audit ;;
    apply) apply_repair ;;
    undo) undo_repair ;;
    *) echo "Usage: $0 <domain> audit|apply|undo" >&2; exit 1 ;;
esac
