#!/bin/bash
set -e

DOMAIN=$1
EMAIL=$2
MODE=${3:-initial}
WP_CLI_RUNTIME_BASE="/var/cache/wootify/wp-cli"
WP_CLI_HOME=""
WP_CLI_CACHE_DIR=""

if [ -z "$DOMAIN" ] || [ -z "$EMAIL" ]; then
    echo "Usage: $0 domain email [initial|reissue]"
    exit 1
fi

source "$(dirname "$0")/logging.sh"
source "$(dirname "$0")/permissions.sh"
LOG_FILE="$(resolve_log_file "wootify_ssl.log")"
log() {
    echo "[INFO] $1"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [INFO] $1" >> "$LOG_FILE"
}

log "Starting SSL ${MODE} for $DOMAIN..."

require_root "install_ssl.sh"

source "$(dirname "$0")/os_detect.sh"

prepare_wp_cli_runtime() {
    WP_CLI_HOME="${WP_CLI_RUNTIME_BASE}/${WEB_USER}"
    WP_CLI_CACHE_DIR="${WP_CLI_HOME}/cache"

    install -d -m 755 -o "$WEB_USER" -g "$WEB_GROUP" "$WP_CLI_HOME"
    install -d -m 755 -o "$WEB_USER" -g "$WEB_GROUP" "$WP_CLI_CACHE_DIR"
}

run_wp_cli() {
    sudo -H -u "$WEB_USER" env \
        HOME="$WP_CLI_HOME" \
        WP_CLI_CACHE_DIR="$WP_CLI_CACHE_DIR" \
        /usr/local/bin/wp "$@"
}

has_nginx_plugin() {
    certbot plugins 2>/dev/null | grep -q "nginx"
}

install_first_available_package() {
    local package_name

    for package_name in "$@"; do
        [ -z "$package_name" ] && continue
        if $PKG_MANAGER install -y "$package_name"; then
            return 0
        fi
    done

    return 1
}

ensure_rhel_certbot_stack() {
    $PKG_MANAGER install -y epel-release || true

    if command -v dnf >/dev/null 2>&1; then
        dnf config-manager --set-enabled crb >/dev/null 2>&1 || true
        dnf config-manager --set-enabled powertools >/dev/null 2>&1 || true
    fi

    install_first_available_package certbot python3-certbot python3-certbot-nginx certbot-nginx || true
}

install_nginx_plugin() {
    if [ "$IS_DEBIAN" = true ]; then
        apt-get update
        apt-get install -y python3-certbot-nginx || apt-get install -y certbot python3-certbot-nginx
    elif [ "$IS_RHEL" = true ]; then
        ensure_rhel_certbot_stack
        install_first_available_package python3-certbot-nginx certbot-nginx || true
    fi
}

patch_nginx_cloudflare_php_config() {
    local nginx_conf=""

    nginx_conf="$(resolve_nginx_site_conf "$DOMAIN" || true)"

    if [ -z "$nginx_conf" ] || [ ! -f "$nginx_conf" ]; then
        log "Nginx site config not found for $DOMAIN. Skipping PHP/Cloudflare hardening."
        return 0
    fi

    if ! grep -q 'set \$wootify_https off;' "$nginx_conf"; then
        python3 - "$nginx_conf" <<'PY'
from pathlib import Path
import sys
path = Path(sys.argv[1])
text = path.read_text()
needle = "    error_log /var/log/nginx/"
block = """    set $wootify_https off;\n\n"""
idx = text.find(needle)
if idx != -1:
    line_end = text.find("\n", idx)
    text = text[:line_end + 1] + "\n" + block + "    if ($scheme = https) {\n        set $wootify_https on;\n    }\n\n    if ($http_x_forwarded_proto = \"https\") {\n        set $wootify_https on;\n    }\n\n" + text[line_end + 1:]
    path.write_text(text)
PY
    fi

    if ! grep -q 'fastcgi_buffer_size 256k;' "$nginx_conf"; then
        python3 - "$nginx_conf" <<'PY'
from pathlib import Path
import sys
path = Path(sys.argv[1])
text = path.read_text()
old = """        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;\n        include fastcgi_params;"""
new = """        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;\n        fastcgi_param HTTPS $wootify_https;\n        fastcgi_param HTTP_X_FORWARDED_PROTO $http_x_forwarded_proto;\n        fastcgi_param HTTP_CF_VISITOR $http_cf_visitor;\n        fastcgi_buffer_size 256k;\n        fastcgi_buffers 16 256k;\n        fastcgi_busy_buffers_size 512k;\n        fastcgi_temp_file_write_size 512k;\n        fastcgi_read_timeout 600;\n        include fastcgi_params;"""
if old in text:
    path.write_text(text.replace(old, new, 1))
PY
    fi

    log "Applied Cloudflare/PHP hardening to $nginx_conf"
}

find_cert_names_by_domain() {
    certbot certificates 2>/dev/null | awk -v d="$DOMAIN" '
        /Certificate Name:/ {name=$3}
        /Domains:/ {
            for (i=2; i<=NF; i++) {
                if ($i == d || $i == "www." d) {
                    print name
                    break
                }
            }
        }
    ' | sort -u
}

# 1. Install Certbot
if ! command -v certbot &> /dev/null; then
    log "Installing Certbot..."
    if [ "$IS_DEBIAN" = true ]; then
        apt-get update
        apt-get install -y certbot python3-certbot-nginx
    elif [ "$IS_RHEL" = true ]; then
        ensure_rhel_certbot_stack
    fi
fi

# Ensure nginx installer/authenticator plugin is available
if ! has_nginx_plugin; then
    log "Certbot nginx plugin missing. Installing plugin..."
    install_nginx_plugin
fi

if ! has_nginx_plugin; then
    log "Certbot nginx plugin still unavailable after installation attempt."
    echo "ERROR: NGINX_PLUGIN_MISSING"
    exit 1
fi

if [ "$MODE" = "initial" ]; then
    # Recreated sites can leave stale lineages behind; clean those up only on first activation.
    EXISTING_CERTS=$(find_cert_names_by_domain || true)
    if [ -n "$EXISTING_CERTS" ]; then
        log "Found existing certificate lineage(s) for $DOMAIN. Removing to avoid interactive renewal prompts..."
        while IFS= read -r CERT_NAME; do
            [ -z "$CERT_NAME" ] && continue
            certbot delete --cert-name "$CERT_NAME" --non-interactive || true
        done <<< "$EXISTING_CERTS"
    fi

    rm -f "/etc/letsencrypt/renewal/${DOMAIN}.conf" "/etc/letsencrypt/renewal/www.${DOMAIN}.conf"
    rm -rf "/etc/letsencrypt/live/${DOMAIN}" "/etc/letsencrypt/archive/${DOMAIN}"
else
    log "Preserving existing certificate lineage for reissue mode."
fi

# 2. Request Certificate
# --nginx: Use Nginx plugin
# --non-interactive: No prompts
# --agree-tos: Agree to terms
# --redirect: Redirect HTTP to HTTPS
# --expand: Update existing cert if exists
log "Requesting Let's Encrypt certificate..."

# Build domain list: never add a second www. prefix to an already-www domain
CERTBOT_DOMAINS="-d ${DOMAIN}"
if ! printf '%s' "$DOMAIN" | grep -qi '^www\.'; then
    CERTBOT_DOMAINS="${CERTBOT_DOMAINS} -d www.${DOMAIN}"
fi

# Capture output
set +e
# shellcheck disable=SC2086
OUTPUT=$(certbot --nginx $CERTBOT_DOMAINS \
    --non-interactive \
    --agree-tos \
    --email "$EMAIL" \
    --redirect \
    --expand \
    --cert-name "$DOMAIN" 2>&1)
RET=$?
set -e

if [ $RET -ne 0 ]; then
    log "Certbot failed with code $RET"
    echo "$OUTPUT" >> "$LOG_FILE"
    
    if echo "$OUTPUT" | grep -q "The domain name does not resolve to this machine"; then
        echo "ERROR: DNS_PROBLEM"
        exit 1
    elif echo "$OUTPUT" | grep -q "Challenge failed"; then 
        echo "ERROR: CHALLENGE_FAILED"
        exit 1
    elif echo "$OUTPUT" | grep -qi "requested nginx plugin does not appear to be installed\|could not select or initialize the requested installer nginx\|No candidate plugin"; then
        echo "ERROR: NGINX_PLUGIN_MISSING"
        exit 1
    else
        echo "ERROR: UNKNOWN"
        echo "$OUTPUT"
        exit 1
    fi
fi

# Ensure PHP location works better behind Cloudflare and on WooCommerce checkout/cart pages
patch_nginx_cloudflare_php_config

# Get Expiry Date
EXPIRY_RAW=$(openssl x509 -enddate -noout -in "/etc/letsencrypt/live/$DOMAIN/cert.pem" 2>/dev/null | cut -d= -f2)
# Format might be: Feb 18 10:00:00 2026 GMT
# Convert to ISO 8601 if possible? date -d "$EXPIRY_RAW" +%Y-%m-%dT%H:%M:%SZ
if [ -n "$EXPIRY_RAW" ]; then
    EXPIRY_ISO=$(date -d "$EXPIRY_RAW" -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || echo "")
    echo "EXPIRY: $EXPIRY_ISO"
fi

# 4. Reload Nginx
systemctl reload nginx

# 5. Chuyển WordPress sang HTTPS (nếu site WordPress và có WP-CLI)
WEB_ROOT="/var/www/$DOMAIN"
if [ -f "$WEB_ROOT/wp-config.php" ] && command -v /usr/local/bin/wp &> /dev/null; then
    log "WordPress detected. Checking site URL..."
    prepare_wp_cli_runtime

    CURRENT_URL=$(run_wp_cli option get siteurl --path="$WEB_ROOT" 2>/dev/null || echo "")

    if [ -n "$CURRENT_URL" ] && echo "$CURRENT_URL" | grep -q "^http://"; then
        HTTPS_URL=$(echo "$CURRENT_URL" | sed 's|^http://|https://|')

        log "Updating siteurl: $CURRENT_URL -> $HTTPS_URL"
        run_wp_cli option update siteurl "$HTTPS_URL" --path="$WEB_ROOT"
        run_wp_cli option update home "$HTTPS_URL" --path="$WEB_ROOT"

        log "Search-replace database: http://$DOMAIN -> https://$DOMAIN"
        run_wp_cli search-replace "http://$DOMAIN" "https://$DOMAIN" --path="$WEB_ROOT" --skip-columns=guid --quiet || true
        run_wp_cli search-replace "http://www.$DOMAIN" "https://www.$DOMAIN" --path="$WEB_ROOT" --skip-columns=guid --quiet || true

        log "WordPress switched to HTTPS successfully."
    else
        log "Site URL already HTTPS or undetectable. Skipping."
    fi
fi

log "SSL ${MODE} completed successfully for $DOMAIN"
