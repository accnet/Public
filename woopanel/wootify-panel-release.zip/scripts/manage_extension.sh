#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive

ACTION=$1
EXTENSION=$2

if [ -z "$ACTION" ] || [ -z "$EXTENSION" ]; then
    echo "Usage: $0 [install|uninstall] [extension_name]"
    exit 1
fi

source "$(dirname "$0")/logging.sh"
source "$(dirname "$0")/permissions.sh"
source "$(dirname "$0")/os_detect.sh"
LOG_FILE="$(resolve_log_file "wootify_install.log")"
log() {
    echo "[EXTENSIONS] $1"
    echo "[EXTENSIONS] $1" >> $LOG_FILE
}

detect_stack_php_version() {
    local current_ver=""

    if command -v php >/dev/null 2>&1; then
        current_ver="$(php -r "echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION;" 2>/dev/null || true)"
    fi

    if [ -z "$current_ver" ] && [ -d /etc/php ]; then
        current_ver="$(ls /etc/php 2>/dev/null | grep -E '^[0-9]+\.[0-9]+$' | sort -V | tail -n1 || true)"
    fi

    if [ -z "$current_ver" ] && [ -d /etc/opt/remi ]; then
        current_ver="$(ls /etc/opt/remi 2>/dev/null | grep -E '^php[0-9]{2}$' | sed 's/php//' | sed 's/\(.\)\(.\)/\1.\2/' | sort -V | tail -n1 || true)"
    fi

    if [ -z "$current_ver" ]; then
        current_ver="8.3"
    fi

    printf '%s\n' "$current_ver"
}

PHP_VERSION="$(detect_stack_php_version)"

# Map UI names to Package names
case "$EXTENSION" in
    redis)
        PKG_SUFFIX="redis"
        ;;
    opcache)
        PKG_SUFFIX="opcache"
        ;;
    imagick)
        PKG_SUFFIX="imagick"
        ;;
    *)
        log "Unknown extension: $EXTENSION"
        exit 1
        ;;
esac

log "Starting $ACTION for $EXTENSION..."
build_rhel_package_candidates() {
    local extension="$1"
    local php_ver_short="$2"

    case "$extension" in
        redis)
            printf '%s\n' \
                "php${php_ver_short}-php-pecl-redis6" \
                "php${php_ver_short}-php-pecl-redis5" \
                "php${php_ver_short}-php-pecl-redis" \
                "php-pecl-redis6" \
                "php-pecl-redis5" \
                "php-pecl-redis" \
                "php${php_ver_short}-php-redis" \
                "php-redis"
            ;;
        imagick)
            printf '%s\n' \
                "php${php_ver_short}-php-pecl-imagick-im7" \
                "php${php_ver_short}-php-pecl-imagick" \
                "php-pecl-imagick-im7" \
                "php-pecl-imagick" \
                "php${php_ver_short}-php-imagick" \
                "php-imagick"
            ;;
        *)
            printf '%s\n' \
                "php${php_ver_short}-php-${PKG_SUFFIX}" \
                "php-${PKG_SUFFIX}"
            ;;
    esac
}

install_rhel_extension_package() {
    local extension="$1"
    local php_version="$2"
    local php_ver_short="${php_version//./}"
    local package_name=""

    while IFS= read -r package_name; do
        [ -n "$package_name" ] || continue
        if $PKG_MANAGER install -y "$package_name"; then
            log "Installed ${package_name}"
            return 0
        fi
    done < <(build_rhel_package_candidates "$extension" "$php_ver_short")

    return 1
}

remove_rhel_extension_packages() {
    local extension="$1"
    local php_version="$2"
    local php_ver_short="${php_version//./}"
    local package_name=""

    while IFS= read -r package_name; do
        [ -n "$package_name" ] || continue
        if rpm -q "$package_name" >/dev/null 2>&1; then
            $PKG_MANAGER remove -y "$package_name" || true
        fi
    done < <(build_rhel_package_candidates "$extension" "$php_ver_short")
}

restart_detected_php_fpm() {
    local php_version="$1"
    local service_name=""

    service_name="$(resolve_php_fpm_service_name "$php_version" || true)"
    if [ -n "$service_name" ] && systemctl is-active --quiet "$service_name"; then
        systemctl restart "$service_name"
        log "Restarted ${service_name}"
        return 0
    fi

    return 1
}

if [ "$ACTION" == "install" ]; then
    require_root "manage_extension.sh install"
    # Kiểm tra tương thích: chỉ cho phép cài extension nếu LEMP đã được thiết lập
    if ! command -v php >/dev/null 2>&1; then
        log "Lỗi: LEMP stack (PHP) chưa được cài đặt. Không thể cài extension."
        echo "ERROR: LEMP stack required"
        exit 1
    fi

    if [ "$IS_DEBIAN" = true ]; then
        if ! dpkg-query -W -f='${Status}' "php${PHP_VERSION}-common" 2>/dev/null | grep -q "install ok installed"; then
            log "PHP ${PHP_VERSION} is not installed on this stack."
            exit 1
        fi

        INSTALL_PKG="php${PHP_VERSION}-${PKG_SUFFIX}"

        # Fallback for packages that may not be versioned for newer PHP releases
        if ! apt-cache show "$INSTALL_PKG" >/dev/null 2>&1; then
            case "$EXTENSION" in
                imagick)
                    # imagick is sometimes available only as the unversioned meta-package
                    if apt-cache show "php-imagick" >/dev/null 2>&1; then
                        INSTALL_PKG="php-imagick"
                        log "php${PHP_VERSION}-imagick not found, using fallback package: php-imagick"
                    else
                        log "ERROR: No imagick package available for PHP ${PHP_VERSION}. Install from PECL manually."
                        exit 1
                    fi
                    ;;
                *)
                    log "ERROR: Package ${INSTALL_PKG} not found in apt repos."
                    exit 1
                    ;;
            esac
        fi

        log "Installing ${INSTALL_PKG}..."
        apt-get install -y "$INSTALL_PKG"

        if systemctl is-active --quiet "php${PHP_VERSION}-fpm"; then
            systemctl restart "php${PHP_VERSION}-fpm"
            log "Restarted php${PHP_VERSION}-fpm"
        fi
    elif [ "$IS_RHEL" = true ]; then
        log "Attempting to install $EXTENSION for PHP ${PHP_VERSION} on RHEL..."
        if ! install_rhel_extension_package "$EXTENSION" "$PHP_VERSION"; then
            log "No compatible RHEL package found for $EXTENSION on PHP ${PHP_VERSION}"
            exit 1
        fi

        restart_detected_php_fpm "$PHP_VERSION" || true
    fi
    log "$EXTENSION installed successfully."

elif [ "$ACTION" == "uninstall" ]; then
    require_root "manage_extension.sh uninstall"
    if [ "$IS_DEBIAN" = true ]; then
        if dpkg-query -W -f='${Status}' "php${PHP_VERSION}-common" 2>/dev/null | grep -q "install ok installed"; then
            log "Removing php${PHP_VERSION}-$PKG_SUFFIX..."
            apt-get remove -y "php${PHP_VERSION}-$PKG_SUFFIX"

            if systemctl is-active --quiet "php${PHP_VERSION}-fpm"; then
                systemctl restart "php${PHP_VERSION}-fpm"
                log "Restarted php${PHP_VERSION}-fpm"
            fi
        fi
    elif [ "$IS_RHEL" = true ]; then
        log "Attempting to remove $EXTENSION for PHP ${PHP_VERSION} on RHEL..."
        remove_rhel_extension_packages "$EXTENSION" "$PHP_VERSION"

        restart_detected_php_fpm "$PHP_VERSION" || true
    fi
    log "$EXTENSION uninstalled successfully."

else
    log "Invalid action: $ACTION"
    exit 1
fi
