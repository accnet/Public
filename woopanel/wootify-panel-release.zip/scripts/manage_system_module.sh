#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive

ACTION=$1
MODULE=$2

if [ -z "$ACTION" ] || [ -z "$MODULE" ]; then
    echo "Usage: $0 [install|uninstall|status] [module_name]"
    exit 1
fi

source "$(dirname "$0")/logging.sh"
source "$(dirname "$0")/permissions.sh"
LOG_FILE="$(resolve_log_file "wootify_modules.log")"
log() {
    echo "[MODULE:$MODULE] $1"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [MODULE:$MODULE] $1" >> $LOG_FILE
}

source "$(dirname "$0")/os_detect.sh"
source "$(dirname "$0")/cloudflare_lockdown.sh"
SELF_PATH="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"
NGINX_ROOT="/etc/nginx"
RATE_LIMIT_CONF="$NGINX_ROOT/conf.d/rate_limit.conf"
LEGACY_EMERGENCY_CONF="$NGINX_ROOT/conf.d/emergency_mode.conf"

# Site vhosts that WooPanel manages.
site_vhosts() {
    local file
    for file in "$NGINX_ROOT"/conf.d/*.conf "$NGINX_ROOT"/sites-available/*; do
        [ -f "$file" ] && grep -Eq '^[[:space:]]*server_name[[:space:]]' "$file" && printf '%s\n' "$file"
    done
}

# Best effort: rate limits must see visitor IPs, not Cloudflare edges.
ensure_realip_best_effort() {
    if install_cloudflare_realip "$NGINX_ROOT" "$SELF_PATH"; then
        log "Cloudflare real-IP restore is active (refreshed weekly)."
    else
        log "Warning: could not install Cloudflare real-IP restore. Sites behind Cloudflare would be rate limited per Cloudflare edge instead of per visitor."
    fi
}

write_rate_limit_conf() {
    cat > "$RATE_LIMIT_CONF" << 'EOF'
# Managed by WooPanel. Per-site toggles add the matching limit_req lines.
limit_req_zone $binary_remote_addr zone=global:10m rate=20r/s;
limit_conn_zone $binary_remote_addr zone=addr:10m;
# Strict level, used by the per-site "Emergency Mode" toggle.
limit_req_zone $binary_remote_addr zone=emergency:10m rate=5r/s;
# Login brute force: only POSTs to wp-login.php / xmlrpc.php are counted
# (requests whose key is empty are not accounted by limit_req).
map "$request_method:$uri" $woopanel_login_key {
    default "";
    "POST:/wp-login.php" $binary_remote_addr;
    "POST:/xmlrpc.php" $binary_remote_addr;
}
limit_req_zone $woopanel_login_key zone=wplogin:10m rate=10r/m;
limit_req_status 429;
limit_conn_status 429;
EOF
}

# Safe Nginx reload: validates config before reloading.
reload_nginx_safe() {
    if command -v nginx >/dev/null 2>&1; then
        if nginx -t 2>/dev/null; then
            systemctl reload nginx 2>/dev/null || service nginx reload 2>/dev/null || true
            log "Nginx reloaded successfully."
        else
            log "ERROR: Nginx config test failed — reload skipped. Check config manually."
            return 1
        fi
    fi
    return 0
}

status_module() {
    case "$MODULE" in

        cloudflare)
            [ -f "/etc/nginx/conf.d/cloudflare.conf" ] && [ -f "/etc/nginx/woopanel-cloudflare-gate.conf" ] && return 0 || return 1
            ;;
        rate-limit)
            [ -f "$RATE_LIMIT_CONF" ] && return 0 || return 1
            ;;
        fail2ban)
            systemctl is-active --quiet fail2ban && return 0 || return 1
            ;;
        php-protect)
            [ -f "$PHP_PROTECT_SNIPPET" ] && return 0 || return 1
            ;;
        bot-block)
            [ -f "/etc/nginx/conf.d/bot_block.conf" ] && return 0 || return 1
            ;;

        emergency)
            # Part of "Nginx Rate Limit" now; legacy installs had their own file.
            [ -f "$LEGACY_EMERGENCY_CONF" ] && return 0
            grep -qs 'zone=emergency:' "$RATE_LIMIT_CONF" && return 0 || return 1
            ;;
        *)
            return 1
            ;;
    esac
}

install_module() {
    log "Enabling module..."
    case "$MODULE" in

        cloudflare)
            install_cloudflare_realip "$NGINX_ROOT" "$SELF_PATH"
            configure_cloudflare_lockdown install
            ;;
        rate-limit)
            local backup vhost
            backup="$(mktemp -d)"
            [ ! -f "$RATE_LIMIT_CONF" ] || cp -p "$RATE_LIMIT_CONF" "$backup/rate_limit.conf"
            [ ! -f "$LEGACY_EMERGENCY_CONF" ] || cp -p "$LEGACY_EMERGENCY_CONF" "$backup/emergency_mode.conf"
            write_rate_limit_conf
            # The emergency zone now lives in rate_limit.conf (a second definition is fatal).
            rm -f "$LEGACY_EMERGENCY_CONF"
            # Sites that already had rate limiting also get login brute-force protection.
            while IFS= read -r vhost; do
                if grep -q "limit_req zone=global burst=40" "$vhost" && ! grep -q "zone=wplogin" "$vhost"; then
                    cp -p "$vhost" "$backup/$(basename "$vhost").site"
                    printf '%s\n' "$vhost" >> "$backup/sites"
                    sed -i '/location ~ \\\.php\$ {/a \        limit_req zone=wplogin burst=5 nodelay;' "$vhost"
                fi
            done < <(site_vhosts)
            if ! reload_nginx_safe; then
                if [ -f "$backup/rate_limit.conf" ]; then cp -p "$backup/rate_limit.conf" "$RATE_LIMIT_CONF"; else rm -f "$RATE_LIMIT_CONF"; fi
                [ ! -f "$backup/emergency_mode.conf" ] || cp -p "$backup/emergency_mode.conf" "$LEGACY_EMERGENCY_CONF"
                if [ -f "$backup/sites" ]; then
                    while IFS= read -r vhost; do cp -p "$backup/$(basename "$vhost").site" "$vhost"; done < "$backup/sites"
                fi
                rm -rf -- "$backup"
                reload_nginx_safe || true
                exit 1
            fi
            rm -rf -- "$backup"
            ensure_realip_best_effort
            ;;
        fail2ban)
            if [ "$IS_DEBIAN" = true ]; then
                apt-get update && apt-get install -y fail2ban
                apt-get install -y python3-systemd || true
            else
                $PKG_MANAGER install -y epel-release || true
                $PKG_MANAGER install -y fail2ban
                $PKG_MANAGER install -y python3-systemd || true
            fi
            write_fail2ban_sshd_jail
            log "SSH jail enabled for port(s): $(detect_ssh_ports | xargs)"
            systemctl enable fail2ban
            systemctl restart fail2ban
            ;;
        php-protect)
            # curl_exec/curl_multi_exec, allow_url_fopen, memory_limit and size limits
            # are intentionally not enforced: they break WordPress updates, payment
            # gateways, WP_MAX_MEMORY_LIMIT (512M) and the 256M upload limit.
            mkdir -p "$(dirname "$PHP_PROTECT_SNIPPET")"
            cat > "$PHP_PROTECT_SNIPPET" << 'EOF'
php_admin_value[disable_functions] = exec,passthru,shell_exec,system,proc_open,popen,pcntl_exec,parse_ini_file,show_source
php_admin_flag[allow_url_include] = off
php_admin_value[max_input_time] = 60
EOF
            if ! sync_php_protect_pools apply; then
                rm -f "$PHP_PROTECT_SNIPPET"
                log "ERROR: PHP-FPM config test failed — protection rolled back."
                exit 1
            fi
            rm -f "/etc/php/wootify-protect.conf" "/etc/opt/remi/wootify-protect.conf"
            log "PHP protection applied to all site pools."
            ;;
        bot-block)
            cat > /etc/nginx/conf.d/bot_block.conf << 'EOF'
# Block bad bots
map $http_user_agent $bad_bot {
    default 0;
    # Aggressive scrapers and SEO crawlers only — search engines are not blocked.
    ~*(80legs|SemrushBot|AhrefsBot|Bytespider|DotBot|MJ12bot|PetalBot|BLEXBot|DataForSeoBot) 1;
}
EOF
            reload_nginx_safe
            ;;

        emergency)
            log "Emergency Mode is now part of Nginx Rate Limit. Installing Nginx Rate Limit instead..."
            MODULE=rate-limit
            install_module
            return
            ;;
        *)
            log "Unknown module: $MODULE"
            exit 1
            ;;
    esac
    log "Module $MODULE installed/enabled successfully."
}

ensure_nginx_module_unused() {
    local pattern="$1" excluded="$2" nginx_root="${3:-/etc/nginx}" file
    for file in "$nginx_root"/conf.d/*.conf "$nginx_root"/sites-available/*; do
        [ -f "$file" ] || continue
        [ "$(basename "$file")" != "$excluded" ] || continue
        if grep -Ev '^[[:space:]]*#' "$file" | grep -Eq "$pattern"; then
            echo "Disable this protection layer on its sites before uninstalling it: $file" >&2
            return 1
        fi
    done
    return 0
}

uninstall_module() {
    log "Disabling module..."
    case "$MODULE" in

        cloudflare)
            configure_cloudflare_lockdown uninstall
            ;;
        rate-limit)
            local zones='global|wplogin'
            [ -f "$LEGACY_EMERGENCY_CONF" ] || zones='global|wplogin|emergency'
            ensure_nginx_module_unused "limit_req[[:space:]]+zone=(${zones})|limit_conn[[:space:]]+addr" rate_limit.conf
            rm -f "$RATE_LIMIT_CONF"
            reload_nginx_safe
            ;;
        fail2ban)
            rm -f /etc/fail2ban/jail.d/woopanel-sshd.local
            systemctl disable --now fail2ban || true
            ;;
        php-protect)
            sync_php_protect_pools strip || { log "ERROR: PHP-FPM config test failed while removing protection."; exit 1; }
            rm -f "$PHP_PROTECT_SNIPPET"
            rm -f "/etc/php/wootify-protect.conf"
            rm -f "/etc/opt/remi/wootify-protect.conf"
            ;;
        bot-block)
            ensure_nginx_module_unused '\$bad_bot' bot_block.conf
            rm -f /etc/nginx/conf.d/bot_block.conf
            reload_nginx_safe
            ;;

        emergency)
            if [ ! -f "$LEGACY_EMERGENCY_CONF" ]; then
                log "Emergency Mode is part of Nginx Rate Limit; disable it per site or uninstall Nginx Rate Limit."
                return 0
            fi
            ensure_nginx_module_unused 'limit_req[[:space:]]+zone=emergency' emergency_mode.conf
            rm -f "$LEGACY_EMERGENCY_CONF"
            reload_nginx_safe
            ;;
        *)
            log "Unknown module: $MODULE"
            exit 1
            ;;
    esac
    log "Module $MODULE uninstalled/disabled successfully."
}

if [ "$ACTION" == "status" ]; then
    status_module
    exit $?
elif [ "$ACTION" == "install" ]; then
    require_root "manage_system_module.sh install"
    # Kiểm tra tương thích: chỉ cho phép cài module nếu LEMP (Nginx) đã được thiết lập
    if ! command -v nginx >/dev/null 2>&1; then
        log "Lỗi: LEMP stack chưa được cài đặt. Không thể cài module."
        echo "ERROR: LEMP stack required"
        exit 1
    fi
    install_module
elif [ "$ACTION" == "uninstall" ]; then
    require_root "manage_system_module.sh uninstall"
    uninstall_module
elif [ "$ACTION" == "refresh" ] && [ "$MODULE" == "cloudflare-ips" ]; then
    # Weekly cron: keep the trusted Cloudflare ranges current.
    require_root "manage_system_module.sh refresh"
    install_cloudflare_realip "$NGINX_ROOT" "$SELF_PATH"
    if MODULE=cloudflare status_module; then
        configure_cloudflare_lockdown install
    fi
else
    echo "Invalid action"
    exit 1
fi
