#!/bin/bash

require_root() {
    local context="${1:-This script}"

    if [ "$(id -u)" -ne 0 ]; then
        echo "ERROR: ${context} must be run as root. Please use sudo or run it from the root panel service."
        exit 1
    fi
}

# The helpers below act on $POOL_USER.
is_dedicated_pool_user() {
    local entry shell comment
    entry="$(getent passwd "$POOL_USER")" || return 1
    comment="$(printf '%s' "$entry" | cut -d: -f5)"
    shell="$(printf '%s' "$entry" | cut -d: -f7)"
    case "$shell" in */nologin|*/false) ;; *) return 1 ;; esac
    case "$comment" in "WooPanel PHP pool "*) return 0 ;; *) return 1 ;; esac
}

# PIDs of the pool user that are not PHP-FPM workers (a backdoor daemon,
# a miner, a reverse shell...).
stray_pids() {
    ps -u "$POOL_USER" -o pid=,comm= 2>/dev/null | awk '$2 !~ /^php-fpm/ {print $1}'
}

# TERM, then KILL what is left. Prints how many processes got the TERM.
# Callers must check is_dedicated_pool_user first: a shared user's
# processes are not the site's.
kill_stray_pids() {
    local pid killed=0
    for pid in $(stray_pids); do
        kill -TERM "$pid" 2>/dev/null && killed=$((killed + 1))
    done
    if [ "$killed" -gt 0 ]; then
        sleep 2
        for pid in $(stray_pids); do kill -KILL "$pid" 2>/dev/null || true; done
    fi
    echo "$killed"
}
