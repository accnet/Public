#!/bin/bash

require_root() {
    local context="${1:-This script}"

    if [ "$(id -u)" -ne 0 ]; then
        echo "ERROR: ${context} must be run as root. Please use sudo or run it from the root panel service."
        exit 1
    fi
}
