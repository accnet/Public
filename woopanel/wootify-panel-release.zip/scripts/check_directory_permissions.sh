#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/os_detect.sh"

failures=0

check_path() {
    local path="$1"
    local expected_owner="$2"
    local expected_group="$3"
    local expected_mode="$4"
    local required="${5:-required}"

    if [ ! -e "$path" ]; then
        if [ "$required" = "optional" ]; then
            printf 'SKIP missing optional %s\n' "$path"
            return 0
        fi
        printf 'FAIL missing %s\n' "$path"
        failures=$((failures + 1))
        return 0
    fi

    local owner group mode actual
    owner="$(stat -c '%U' "$path")"
    group="$(stat -c '%G' "$path")"
    mode="$(stat -c '%a' "$path")"
    actual="$(stat -c '%A %U:%G' "$path")"

    if [ "$owner" = "$expected_owner" ] && [ "$group" = "$expected_group" ] && [ "$mode" = "$expected_mode" ]; then
        printf 'OK   %s %s\n' "$actual" "$path"
        return 0
    fi

    printf 'WARN expected %s:%s %s, got %s %s\n' "$expected_owner" "$expected_group" "$expected_mode" "$actual" "$path"
    failures=$((failures + 1))
}

check_site_root() {
    local root="$1"
    local label="${2:-site}"

    [ -d "$root" ] || return 0
    printf 'Checking %s %s\n' "$label" "$root"
    check_path "$root" "$WEB_USER" "$WEB_GROUP" "755"

    if [ -f "$root/wp-config.php" ]; then
        check_path "$root/wp-config.php" "$WEB_USER" "$WEB_GROUP" "640"
    fi

    if [ -d "$root/wp-content/uploads" ]; then
        check_path "$root/wp-content/uploads" "$WEB_USER" "$WEB_GROUP" "755"
    fi
}

printf 'Detected OS=%s, web user=%s, web group=%s, nginx conf dir=%s\n' "$OS" "$WEB_USER" "$WEB_GROUP" "$NGINX_CONF_DIR"

check_path "/var/www" "root" "root" "755" "optional"
check_path "/var/cache" "root" "root" "755" "optional"
check_path "/var/cache/wootify" "root" "root" "755" "optional"
check_path "/var/cache/wootify/wp-cli" "root" "root" "755" "optional"

if [ -d "/var/cache/wootify/wp-cli/${WEB_USER}" ]; then
    check_path "/var/cache/wootify/wp-cli/${WEB_USER}" "$WEB_USER" "$WEB_GROUP" "755"
    check_path "/var/cache/wootify/wp-cli/${WEB_USER}/cache" "$WEB_USER" "$WEB_GROUP" "755"
fi

check_path "$NGINX_CONF_DIR" "root" "root" "755" "optional"

if [ "$IS_DEBIAN" = true ]; then
    check_path "/run/php" "$WEB_USER" "$WEB_GROUP" "755" "optional"
elif [ "$IS_RHEL" = true ]; then
    check_path "/run/php-fpm" "root" "root" "755" "optional"
fi

for root in /var/www/*; do
    [ -d "$root" ] || continue
    [ -f "$root/wp-config.php" ] || continue

    case "$(basename "$root")" in
        *_bak_*|*.bak-*|*.backup-*|*.old)
            check_site_root "$root" "backup"
            ;;
        *)
            check_site_root "$root" "site"
            ;;
    esac
done

if [ "$failures" -gt 0 ]; then
    printf 'Directory permission check completed with %d warning(s).\n' "$failures"
    exit 1
fi

printf 'Directory permission check passed.\n'
