#!/bin/bash
# Shared WordPress migration helpers (clone_site.sh, rename_site.sh).
# Callers must define: log, fail, run_wp_cli.

read_wp_define() {
    local file="$1"
    local key="$2"
    sed -n "s/.*define([[:space:]]*'${key}'[[:space:]]*,[[:space:]]*'\\([^']*\\)'.*/\\1/p" "$file" | head -n1
}

run_search_replace() {
    local root="$1"
    local source_domain="$2"
    local target_domain="$3"
    local target_scheme="$4"

    log "Updating WordPress URLs from ${source_domain} to ${target_domain}..."

    run_wp_cli option update home "${target_scheme}://${target_domain}" --path="$root" >/dev/null
    run_wp_cli option update siteurl "${target_scheme}://${target_domain}" --path="$root" >/dev/null

    # One regex pass covers http/https, www/non-www and JSON-escaped URLs
    # (https:\/\/source, as stored by Elementor/Gutenberg). The lookahead stops
    # "shop.com" from matching inside "shop.com.vn", which also keeps the pass
    # idempotent when the target domain extends the source domain.
    local src_re="${source_domain//./\\.}"
    local pattern='https?:(\\/\\/|//)(www\.)?'"${src_re}"'(?![A-Za-z0-9-]|\.[A-Za-z0-9])'
    local replacement="${target_scheme}:\${1}\${2}${target_domain}"
    run_wp_cli search-replace "$pattern" "$replacement" --regex --regex-delimiter='#' --regex-flags=i \
        --all-tables-with-prefix --skip-columns=guid --path="$root" --quiet \
        || fail "search-replace failed; the cloned site would still point at ${source_domain}."
}

# Cache/config files from plugins (WP Rocket, W3TC, advanced-cache.php, .user.ini)
# embed the absolute source path; point them at the target and drop page caches
# that still contain source URLs.
rewrite_source_paths() {
    local root="$1" source_root="$2" target_root="$3" src_re
    src_re="$(printf '%s' "$source_root" | sed 's/[.[\*^$/]/\\&/g')"
    grep -rlIZ -F --exclude-dir=uploads --exclude-dir=cache \
        --include='*.php' --include='*.ini' --include='.htaccess' --include='.user.ini' --include='*.json' \
        "$source_root" "$root" 2>/dev/null \
        | xargs -0 -r sed -i -E "s/${src_re}([^A-Za-z0-9.-]|\$)/$(printf '%s' "$target_root" | sed 's/[\/&]/\\&/g')\1/g"
    if [ -d "$root/wp-content/cache" ]; then
        find "$root/wp-content/cache" -mindepth 1 -maxdepth 1 -exec rm -rf -- {} +
    fi
}

# df/du in KB; sums requirements per filesystem so a shared disk is not double-counted.
ensure_free_space() {
    local -A need=() where=()
    local path kb dev avail
    while [ "$#" -ge 2 ]; do
        path="$1"; kb="$2"; shift 2
        while [ ! -e "$path" ]; do path="$(dirname "$path")"; done
        dev="$(stat -c %d "$path")"
        need[$dev]=$(( ${need[$dev]:-0} + kb ))
        where[$dev]="$path"
    done
    for dev in "${!need[@]}"; do
        avail="$(df -Pk "${where[$dev]}" | awk 'NR == 2 {print $4}')"
        if [ "${avail:-0}" -lt "${need[$dev]}" ]; then
            fail "Not enough disk space on $(df -P "${where[$dev]}" | awk 'NR == 2 {print $6}'): need ~$(( need[$dev] / 1024 )) MB, available $(( ${avail:-0} / 1024 )) MB."
        fi
    done
}

# Points the object cache at <domain>'s own Redis namespace. Uses "wp config"
# only, which does not boot WordPress (so it can't touch the shared cache).
set_wp_cache_namespace() {
    local root="$1" domain="$2" prefix
    prefix="$(wp_redis_prefix "$domain")"
    if [ -f "$root/wp-content/object-cache.php" ] || grep -q "WP_REDIS_PREFIX" "$root/wp-config.php"; then
        run_wp_cli config set WP_REDIS_PREFIX "$prefix" --type=constant --path="$root" >/dev/null
    fi
    if grep -q "WP_CACHE_KEY_SALT" "$root/wp-config.php"; then
        run_wp_cli config set WP_CACHE_KEY_SALT "$prefix" --type=constant --path="$root" >/dev/null
    fi
}
