#!/bin/bash
# rename_site.sh — step 3 of "change domain": move a WordPress site from
# <old> to <new> in place (same site, DB, pool user and settings).
#
# Usage: rename_site.sh --old <domain> --new <domain> --email <email> [--php-version X.Y]
#
# Requires rename_ssl_prepare.sh to have issued a certificate for <new>.
# Every step records what it changed; on any failure (or SIGTERM) the EXIT
# trap undoes them in reverse order and restores the database dump.
set -Eeuo pipefail

OLD=""
NEW=""
EMAIL=""
PHP_VERSION=""
while [ "$#" -gt 0 ]; do
    case "$1" in
        --old) OLD="${2:-}"; shift 2 ;;
        --new) NEW="${2:-}"; shift 2 ;;
        --email) EMAIL="${2:-}"; shift 2 ;;
        --php-version) PHP_VERSION="${2:-}"; shift 2 ;;
        *) echo "Unknown argument: $1" >&2; exit 1 ;;
    esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
source "${SCRIPT_DIR}/logging.sh"
source "${SCRIPT_DIR}/os_detect.sh"
source "${SCRIPT_DIR}/permissions.sh"
source "${SCRIPT_DIR}/nginx_site_template.sh"
source "${SCRIPT_DIR}/wp_migrate.sh"
LOG_FILE="$(resolve_log_file "wootify_rename.log")"

log() {
    echo "[INFO] $1"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [RENAME] $1" >> "$LOG_FILE"
}
fail() {
    log "$1"
    echo "ERROR: $1" >&2
    exit 1
}

require_root "rename_site.sh"
validate_site_domain "$OLD" && validate_site_domain "$NEW" || fail "Invalid domain"
[ "$OLD" != "$NEW" ] || fail "New domain must differ from the current domain"
[ -n "$EMAIL" ] || fail "--email is required"

OLD_ROOT="/var/www/${OLD}"
NEW_ROOT="/var/www/${NEW}"
TEMP_MARKER="# WOOPANEL-RENAME-TEMP source=${OLD}"
NEW_CONF="${NGINX_CONF_DIR}/${NEW}.conf"
OLD_CONF="$(resolve_nginx_site_conf "$OLD" || true)"
WP_CLI_RUNTIME_BASE="/var/cache/wootify/wp-cli"

cron_slug() {
    local slug
    slug="$(printf '%s' "$1" | tr -c 'a-zA-Z0-9' '_')"
    slug="${slug%_}"
    printf '%s' "${slug:-wp_site}"
}
OLD_SLUG="$(cron_slug "$OLD")"
NEW_SLUG="$(cron_slug "$NEW")"

# --------------------------------------------------------------- preflight
[ -d "$OLD_ROOT" ] || fail "Site root ${OLD_ROOT} not found"
[ -f "$OLD_ROOT/wp-config.php" ] || fail "Only WordPress sites can change domain"
[ ! -e "$NEW_ROOT" ] || fail "${NEW_ROOT} already exists"
[ -n "$OLD_CONF" ] && [ -f "$OLD_CONF" ] || fail "Nginx config for ${OLD} not found"
[ -f "$NEW_CONF" ] && head -n 1 "$NEW_CONF" | grep -qxF "$TEMP_MARKER" \
    || fail "SSL for ${NEW} has not been prepared (temporary vhost missing). Activate SSL first."
[ -f "/etc/letsencrypt/live/${NEW}/fullchain.pem" ] || fail "Certificate for ${NEW} not found. Activate SSL first."
if grep -Eq "define\(\s*['\"]MULTISITE['\"]\s*,\s*true" "$OLD_ROOT/wp-config.php"; then
    fail "WordPress Multisite networks cannot change domain yet."
fi
# Malware isolation/remediation state is refused by the Go handler (DB is authoritative).

OLD_POOL_CONF=""
for f in "/etc/php-fpm.d/${OLD}.conf" /etc/php/*/fpm/pool.d/"${OLD}".conf; do
    [ -f "$f" ] && OLD_POOL_CONF="$f" && break
done
[ -n "$OLD_POOL_CONF" ] || fail "Per-site PHP-FPM pool for ${OLD} not found"
NEW_POOL_CONF="$(dirname "$OLD_POOL_CONF")/${NEW}.conf"
[ ! -e "$NEW_POOL_CONF" ] || fail "PHP-FPM pool ${NEW_POOL_CONF} already exists"
if [[ "$OLD_POOL_CONF" =~ ^/etc/php/([0-9]+\.[0-9]+)/ ]]; then PHP_VERSION="${BASH_REMATCH[1]}"; fi
POOL_USER="$(resolve_pool_user_from_config "$OLD" || true)"
[ -n "$POOL_USER" ] && id "$POOL_USER" >/dev/null 2>&1 || fail "Pool user for ${OLD} not found"
OLD_COMMENT="$(getent passwd "$POOL_USER" | cut -d: -f5)"
NEW_SOCKET="$(awk -F'=' '/^[[:space:]]*listen[[:space:]]*=/ {gsub(/[[:space:]]/, "", $2); print $2; exit}' "$OLD_POOL_CONF" | sed "s#/${OLD//./\\.}\.sock\$#/${NEW}.sock#")"

DB_NAME="$(read_wp_define "$OLD_ROOT/wp-config.php" "DB_NAME")"
[ -n "$DB_NAME" ] || fail "Could not read DB_NAME from wp-config.php"
dump_cmd() { command -v mariadb-dump || command -v mysqldump; }
DUMP_TOOL="$(dump_cmd)" || fail "mysqldump/mariadb-dump is required"

WP_CLI_HOME="${WP_CLI_RUNTIME_BASE}/${POOL_USER}"
WP_CLI_CACHE_DIR="${WP_CLI_HOME}/cache"
install -d -m 755 -o "$POOL_USER" -g "$WEB_GROUP" "$WP_CLI_HOME" "$WP_CLI_CACHE_DIR"
run_wp_cli() {
    sudo -H -u "$POOL_USER" env HOME="$WP_CLI_HOME" WP_CLI_CACHE_DIR="$WP_CLI_CACHE_DIR" \
        /usr/local/bin/wp --no-color "$@"
}
[ -x /usr/local/bin/wp ] || fail "WP-CLI not found at /usr/local/bin/wp"

# ------------------------------------------------------------------ backup
BACKUP_ROOT="${PROJECT_DIR}/storage/backups/rename"
install -d -m 750 -o root -g "$WEB_GROUP" "$BACKUP_ROOT"
DATADIR="$(mariadb -NBe 'SELECT @@datadir' 2>/dev/null || echo /var/lib/mysql)"
ensure_free_space "$BACKUP_ROOT" "$(du -sk "${DATADIR%/}/${DB_NAME}" 2>/dev/null | awk '{print $1}' || echo 0)"
BACKUP_DIR="${BACKUP_ROOT}/${OLD}-$(date '+%Y%m%d-%H%M%S')"
install -d -m 750 -o root -g "$WEB_GROUP" "$BACKUP_DIR"
log "Backing up ${OLD} to ${BACKUP_DIR}..."
"$DUMP_TOOL" --single-transaction --quick --routines --triggers --hex-blob "$DB_NAME" > "${BACKUP_DIR}/database.sql"
[ -s "${BACKUP_DIR}/database.sql" ] || fail "Database backup is empty"
cp -p "$OLD_CONF" "${BACKUP_DIR}/nginx-old.conf"
cp -p "$NEW_CONF" "${BACKUP_DIR}/nginx-temp.conf"
cp -p "$OLD_POOL_CONF" "${BACKUP_DIR}/pool.conf"
cp -p "$OLD_ROOT/wp-config.php" "${BACKUP_DIR}/wp-config.php"
install -d -m 700 "${BACKUP_DIR}/cron"
for f in /etc/cron.d/wootify-wp-"${OLD_SLUG}" $(grep -lxF "# WOOPANEL_SITE=${OLD}" /etc/cron.d/woopanel-custom-* 2>/dev/null || true); do
    [ -f "$f" ] && cp -p "$f" "${BACKUP_DIR}/cron/"
done
chmod -R go-rwx "${BACKUP_DIR}"

# ---------------------------------------------------------------- rollback
MAINT=false ROOT_MOVED=false POOL_MOVED=false COMMENT_CHANGED=false
FILES_REWRITTEN=false DB_TOUCHED=false NGINX_SWITCHED=false CRON_MOVED=false SELINUX_SWITCHED=false
NEW_CRON_FILES=()

rollback() {
    local status="$1" failed=false
    trap - EXIT ERR
    set +e
    if [ "$status" -ne 0 ]; then
        log "Rename failed — rolling back ${NEW} -> ${OLD}..."
        if [ "$NGINX_SWITCHED" = true ]; then
            cp -p "${BACKUP_DIR}/nginx-old.conf" "$OLD_CONF" || failed=true
            cp -p "${BACKUP_DIR}/nginx-temp.conf" "$NEW_CONF" || failed=true
        fi
        if [ "$CRON_MOVED" = true ]; then
            rm -f -- "${NEW_CRON_FILES[@]}"
            cp -p "${BACKUP_DIR}"/cron/* /etc/cron.d/ 2>/dev/null || true
        fi
        if [ "$DB_TOUCHED" = true ]; then
            { mariadb -e "DROP DATABASE IF EXISTS \`${DB_NAME}\`; CREATE DATABASE \`${DB_NAME}\`;" \
                && mariadb "$DB_NAME" < "${BACKUP_DIR}/database.sql"; } || failed=true
        fi
        if [ "$FILES_REWRITTEN" = true ]; then
            rewrite_source_paths "$NEW_ROOT" "$NEW_ROOT" "$OLD_ROOT" || failed=true
        fi
        if [ "$ROOT_MOVED" = true ]; then
            cp -p "${BACKUP_DIR}/wp-config.php" "$NEW_ROOT/wp-config.php" || failed=true
            mv -- "$NEW_ROOT" "$OLD_ROOT" || failed=true
        fi
        if [ "$SELINUX_SWITCHED" = true ]; then
            remove_wp_selinux_contexts "$NEW_ROOT"
            apply_wp_selinux_contexts "$OLD_ROOT"
        fi
        if [ "$POOL_MOVED" = true ]; then
            rm -f -- "$NEW_POOL_CONF"
            cp -p "${BACKUP_DIR}/pool.conf" "$OLD_POOL_CONF" || failed=true
            restart_php_fpm_for_version "$PHP_VERSION" || failed=true
        fi
        [ "$COMMENT_CHANGED" != true ] || usermod -c "$OLD_COMMENT" "$POOL_USER" || failed=true
        if nginx -t >/dev/null 2>&1; then systemctl reload nginx || failed=true; else failed=true; fi
        [ "$MAINT" != true ] || rm -f "$OLD_ROOT/.maintenance"
        if [ "$failed" = true ]; then
            echo "[ERROR] Rename rollback incomplete; backup kept at ${BACKUP_DIR}" >&2
        else
            log "Rollback complete; ${OLD} is serving again."
        fi
    fi
    return "$status"
}
RENAME_MAIN_PID=$BASHPID
trap 'status=$?; if [ "$BASHPID" = "$RENAME_MAIN_PID" ]; then rollback "$status"; fi' EXIT
trap 'echo "[ERROR] Rename failed on line $LINENO" >&2' ERR
trap 'exit 1' INT TERM

# ------------------------------------------------------------------- steps
log "Changing domain ${OLD} -> ${NEW}..."

# 1. Maintenance page (a plain .maintenance file does not boot WordPress).
#    "time()" is evaluated on every request: WordPress ignores a .maintenance
#    whose timestamp is older than 10 minutes, and search-replace can take longer.
printf '<?php $upgrading = time(); ?>\n' > "$OLD_ROOT/.maintenance"
MAINT=true

# 2. Move the web root (same filesystem: instant).
log "Moving ${OLD_ROOT} -> ${NEW_ROOT}..."
mv -- "$OLD_ROOT" "$NEW_ROOT"
ROOT_MOVED=true
remove_wp_selinux_contexts "$OLD_ROOT"
apply_wp_selinux_contexts "$NEW_ROOT"
SELINUX_SWITCHED=true

# 3. Own object-cache namespace before anything boots WordPress, then fix
#    absolute paths baked into plugin/cache files.
set_wp_cache_namespace "$NEW_ROOT" "$NEW"
for key in WP_HOME WP_SITEURL; do
    if grep -q "$key" "$NEW_ROOT/wp-config.php"; then
        run_wp_cli config set "$key" "https://${NEW}" --type=constant --path="$NEW_ROOT" >/dev/null
    fi
done
rewrite_source_paths "$NEW_ROOT" "$OLD_ROOT" "$NEW_ROOT"
FILES_REWRITTEN=true

# 4. Database: home/siteurl first, then every URL (regex: http/https, www,
#    JSON-escaped; never matches look-alike domains).
DB_TOUCHED=true
run_search_replace "$NEW_ROOT" "$OLD" "$NEW" "https"
run_wp_cli cache flush --path="$NEW_ROOT" >/dev/null 2>&1 || true

# 5. PHP-FPM pool: same user, new name/section/socket/open_basedir.
log "Renaming PHP-FPM pool..."
OLD_RE="${OLD//./\\.}"
sed -E \
    -e "s#^\[${OLD_RE}\]\$#[${NEW}]#" \
    -e "s#/${OLD_RE}\.sock#/${NEW}.sock#g" \
    -e "s#/var/www/${OLD_RE}([^A-Za-z0-9.-]|\$)#/var/www/${NEW}\1#g" \
    -e "s#per-site pool for ${OLD_RE}\$#per-site pool for ${NEW}#" \
    "$OLD_POOL_CONF" > "$NEW_POOL_CONF"
chmod --reference="$OLD_POOL_CONF" "$NEW_POOL_CONF"
rm -f -- "$OLD_POOL_CONF"
POOL_MOVED=true
usermod -c "WooPanel PHP pool ${NEW}" "$POOL_USER"
COMMENT_CHANGED=true
restart_php_fpm_for_version "$PHP_VERSION"
for _ in $(seq 1 15); do [ -S "$NEW_SOCKET" ] && break; sleep 1; done
[ -S "$NEW_SOCKET" ] || fail "PHP-FPM socket ${NEW_SOCKET} not ready"

# 6. Nginx: real vhost replaces the placeholder, old vhost goes away (no 301),
#    then certbot re-installs the already-issued certificate (no new issuance).
log "Switching Nginx to ${NEW}..."
NGINX_SWITCHED=true
render_wp_site_nginx_conf "$NEW" "$NEW_ROOT" "$NEW_SOCKET" "$NEW_CONF"
rm -f -- "$OLD_CONF"
nginx -t >/dev/null 2>&1 || { nginx -t || true; fail "Nginx rejected the new site config"; }
systemctl reload nginx
log "Installing certificate for ${NEW}..."
bash "${SCRIPT_DIR}/install_ssl.sh" "$NEW" "$EMAIL" reissue || fail "Could not install the certificate for ${NEW}"

# 7. Cron jobs, logs and malware state follow the new name.
CRON_MOVED=true
if [ -f "/etc/cron.d/wootify-wp-${OLD_SLUG}" ]; then
    sed -E \
        -e "s#/var/www/${OLD_RE}([^A-Za-z0-9.-]|\$)#/var/www/${NEW}\1#g" \
        -e "s#wootify-${OLD_SLUG}\.cron\.lock#wootify-${NEW_SLUG}.cron.lock#g" \
        -e "s#wp-cron-${OLD_SLUG}\.log#wp-cron-${NEW_SLUG}.log#g" \
        "/etc/cron.d/wootify-wp-${OLD_SLUG}" > "/etc/cron.d/wootify-wp-${NEW_SLUG}"
    chmod 644 "/etc/cron.d/wootify-wp-${NEW_SLUG}"
    NEW_CRON_FILES+=("/etc/cron.d/wootify-wp-${NEW_SLUG}")
    rm -f "/etc/cron.d/wootify-wp-${OLD_SLUG}"
fi
for f in $(grep -lxF "# WOOPANEL_SITE=${OLD}" /etc/cron.d/woopanel-custom-* 2>/dev/null || true); do
    sed -i -E \
        -e "s#^\# WOOPANEL_SITE=${OLD_RE}\$#\# WOOPANEL_SITE=${NEW}#" \
        -e "s#/var/www/${OLD_RE}([^A-Za-z0-9.-]|\$)#/var/www/${NEW}\1#g" "$f"
done
for f in "${PROJECT_DIR}/storage/logs/wp-cron-${OLD_SLUG}.log"*; do
    [ -e "$f" ] && mv -f -- "$f" "${f/wp-cron-${OLD_SLUG}/wp-cron-${NEW_SLUG}}"
done
rm -f "/etc/nginx/woopanel/${OLD}-blocks.conf"
for kind in access error; do
    [ -f "/var/log/nginx/${OLD}_${kind}.log" ] && mv -f "/var/log/nginx/${OLD}_${kind}.log" "/var/log/nginx/${NEW}_${kind}.before-rename.log"
done
for dir in "${PROJECT_DIR}/storage/backups/malware" "${PROJECT_DIR}/storage/isolation"; do
    [ -d "${dir}/${OLD}" ] && [ ! -e "${dir}/${NEW}" ] && mv -- "${dir}/${OLD}" "${dir}/${NEW}"
done

# 8. Back online.
rm -f "$NEW_ROOT/.maintenance"
MAINT=false

# ------------------------------------------------- point of no return: tidy
trap - EXIT ERR
set +e
for name in $(certbot certificates 2>/dev/null | awk -v d="$OLD" '
        /Certificate Name:/ {name = $3}
        /Domains:/ { for (i = 2; i <= NF; i++) if ($i == d || $i == "www." d) { print name; break } }' | sort -u); do
    [ "$name" = "$NEW" ] && continue
    log "Removing certificate lineage ${name} for the old domain..."
    certbot delete --cert-name "$name" --non-interactive >/dev/null 2>&1 || log "Warning: could not delete certificate ${name}"
done
rm -rf -- "/var/www/.woopanel-rename/${NEW}"
rmdir /var/www/.woopanel-rename 2>/dev/null
ls -1dt "${BACKUP_ROOT}/${OLD}-"[0-9]* 2>/dev/null | tail -n +4 | while IFS= read -r old_backup; do rm -rf -- "$old_backup"; done

log "Domain changed: ${OLD} -> ${NEW}"
echo "RENAME_OK"
