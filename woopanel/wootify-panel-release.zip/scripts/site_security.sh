#!/bin/bash
set -e

DOMAIN=$1
MODULE=$2
STATUS=$3

if [ -z "$DOMAIN" ] || [ -z "$MODULE" ] || [ -z "$STATUS" ]; then
    echo "Usage: $0 domain module on|off"
    exit 1
fi

source "$(dirname "$0")/logging.sh"
source "$(dirname "$0")/permissions.sh"
LOG_FILE="$(resolve_log_file "wootify_security.log")"
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') [SITE-SECURITY] $DOMAIN - $MODULE: $1" >> "$LOG_FILE"
}

source "$(dirname "$0")/os_detect.sh"

CONF_FILE="$(resolve_nginx_site_conf "$DOMAIN" || true)"

if [ ! -f "$CONF_FILE" ]; then
    log "Config file not found: $CONF_FILE"
    exit 1
fi

enable_module() {
    case "$MODULE" in
        rate-limit)
            if ! grep -q "limit_req zone=global burst=40" "$CONF_FILE"; then
                sed -i '/location \/ {/a \        limit_req zone=global burst=40;\n        limit_conn addr 30;' "$CONF_FILE"
                log "rate-limit enabled"
            fi
            # Login brute force (POST wp-login.php / xmlrpc.php) is handled by PHP,
            # which "location /" never sees. Only when the zone exists (older
            # rate_limit.conf files predate it).
            if grep -qs 'zone=wplogin:' /etc/nginx/conf.d/rate_limit.conf && ! grep -q "zone=wplogin" "$CONF_FILE"; then
                sed -i '/location ~ \\\.php\$ {/a \        limit_req zone=wplogin burst=5 nodelay;' "$CONF_FILE"
                log "login rate limit enabled"
            fi
            ;;
        bot-block)
            if ! grep -q "if (\$bad_bot)" "$CONF_FILE"; then
                # xmlrpc.php is already denied by the site template; adding a second
                # "location = /xmlrpc.php" made nginx -t fail on every template site.
                sed -i '/server_name/a \    if ($bad_bot) { return 403; }' "$CONF_FILE"
                log "bot-block enabled"
            fi
            ;;

        emergency)
            if ! grep -q "limit_req zone=emergency" "$CONF_FILE"; then
                sed -i '/location \/ {/a \        limit_req zone=emergency burst=10;' "$CONF_FILE"
                log "emergency enabled"
            fi
            ;;
        *)
            log "Unknown module $MODULE"
            ;;
    esac
}

disable_module() {
    case "$MODULE" in
        rate-limit)
            sed -i '/limit_req zone=global burst=40/d' "$CONF_FILE"
            sed -i '/limit_conn addr 30/d' "$CONF_FILE"
            sed -i '/limit_req zone=wplogin/d' "$CONF_FILE"
            log "rate-limit disabled"
            ;;
        bot-block)
            sed -i '/if (\$bad_bot) { return 403; }/d' "$CONF_FILE"
            sed -i '/location = \/xmlrpc.php { deny all; }/d' "$CONF_FILE"
            log "bot-block disabled"
            ;;

        emergency)
            sed -i '/limit_req zone=emergency/d' "$CONF_FILE"
            log "emergency disabled"
            ;;
        *)
            log "Unknown module $MODULE"
            ;;
    esac
}

BACKUP=""
if [ "$STATUS" = on ] || [ "$STATUS" = off ]; then
    BACKUP="$(mktemp)"
    cp -p "$CONF_FILE" "$BACKUP"
    rollback_security() {
        local status="$?"
        trap - EXIT
        if [ "$status" -ne 0 ]; then
            cp -p "$BACKUP" "$CONF_FILE"
            if nginx -t; then systemctl reload nginx || true; fi
        fi
        rm -f "$BACKUP"
        exit "$status"
    }
    trap rollback_security EXIT
fi

if [ "$STATUS" == "on" ]; then
    require_root "site_security.sh on"
    enable_module
elif [ "$STATUS" == "off" ]; then
    require_root "site_security.sh off"
    disable_module
elif [ "$STATUS" == "status" ]; then
    case "$MODULE" in
        rate-limit) grep -q "limit_req zone=global burst=40" "$CONF_FILE" && echo "1" || echo "0" ;;
        bot-block) grep -q "if (\$bad_bot)" "$CONF_FILE" && echo "1" || echo "0" ;;

        emergency) grep -q "limit_req zone=emergency" "$CONF_FILE" && echo "1" || echo "0" ;;
        *) echo "0" ;;
    esac
    exit 0
else
    echo "Invalid action. Must be 'on', 'off', or 'status'."
    exit 1
fi

if nginx -t >/dev/null 2>&1; then
    systemctl reload nginx
    echo "Success: $MODULE is now $STATUS for $DOMAIN"
else
    log "Nginx config test failed after modifying $MODULE to $STATUS"
    echo "Failed: Nginx test error"
    exit 1
fi
