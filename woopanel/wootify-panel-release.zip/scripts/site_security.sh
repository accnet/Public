#!/bin/bash
set -e

DOMAIN=$1
MODULE=$2
STATUS=$3

if [ -z "$DOMAIN" ] || [ -z "$MODULE" ] || [ -z "$STATUS" ]; then
    echo "Usage: $0 domain module on|off|status, or: $0 domain php-allowlist paths <file>"
    exit 1
fi

source "$(dirname "$0")/logging.sh"
source "$(dirname "$0")/permissions.sh"
LOG_FILE="$(resolve_log_file "wootify_security.log")"
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') [SITE-SECURITY] $DOMAIN - $MODULE: $1" >> "$LOG_FILE"
}

source "$(dirname "$0")/os_detect.sh"

CONF_FILE="$(resolve_nginx_site_conf "$DOMAIN" || true)"

if [ ! -f "$CONF_FILE" ]; then
    log "Config file not found: $CONF_FILE"
    exit 1
fi

# php-allowlist: PHP runs only from WordPress entry points, wp-admin and
# plugin/theme code. Backdoors dropped anywhere else (decoy trees such as
# well-known/a/b/c/, random top-level dirs, wp-content/<random>/) get 404.
# Per-site extra URI prefixes live in storage, one per line.
ALLOWLIST_STATE="$(cd "$(dirname "$0")/.." && pwd)/storage/php-allowlist/${DOMAIN}"
ALLOWLIST_PATHS="${ALLOWLIST_STATE}/paths"
ALLOWLIST_CONF="/etc/nginx/woopanel/${DOMAIN}-php-allowlist.conf"
ALLOWLIST_INCLUDE="include ${ALLOWLIST_CONF};"

source "$(dirname "$0")/php_allowlist.sh"

enable_module() {
    case "$MODULE" in
        rate-limit)
            if ! grep -q "limit_req zone=global burst=40" "$CONF_FILE"; then
                sed -i '/location \/ {/a \        limit_req zone=global burst=40;\n        limit_conn addr 30;' "$CONF_FILE"
                log "rate-limit enabled"
            fi
            # Login brute force (POST wp-login.php / xmlrpc.php) is handled by PHP,
            # which "location /" never sees. Only when the zone exists (older
            # rate_limit.conf files predate it).
            if grep -qs 'zone=wplogin:' /etc/nginx/conf.d/rate_limit.conf && ! grep -q "zone=wplogin" "$CONF_FILE"; then
                sed -i '/location ~ \\\.php\$ {/a \        limit_req zone=wplogin burst=5 nodelay;' "$CONF_FILE"
                log "login rate limit enabled"
            fi
            ;;
        bot-block)
            if ! grep -q "if (\$bad_bot)" "$CONF_FILE"; then
                # xmlrpc.php is already denied by the site template; adding a second
                # "location = /xmlrpc.php" made nginx -t fail on every template site.
                sed -i '/server_name/a \    if ($bad_bot) { return 403; }' "$CONF_FILE"
                log "bot-block enabled"
            fi
            ;;

        emergency)
            if ! grep -q "limit_req zone=emergency" "$CONF_FILE"; then
                sed -i '/location \/ {/a \        limit_req zone=emergency burst=10;' "$CONF_FILE"
                log "emergency enabled"
            fi
            ;;
        php-allowlist)
            install -d -m 755 "$(dirname "$ALLOWLIST_CONF")"
            render_php_allowlist "$ALLOWLIST_PATHS" "$ALLOWLIST_CONF"
            chmod 0644 "$ALLOWLIST_CONF"
            # Before every other location: Nginx uses the first matching regex.
            if ! grep -qF "$ALLOWLIST_INCLUDE" "$CONF_FILE"; then
                sed -i "/^[[:space:]]*server_name[[:space:]]/a \\    ${ALLOWLIST_INCLUDE}" "$CONF_FILE"
            fi
            log "php-allowlist enabled"
            ;;
        *)
            log "Unknown module $MODULE"
            ;;
    esac
}

disable_module() {
    case "$MODULE" in
        rate-limit)
            sed -i '/limit_req zone=global burst=40/d' "$CONF_FILE"
            sed -i '/limit_conn addr 30/d' "$CONF_FILE"
            sed -i '/limit_req zone=wplogin/d' "$CONF_FILE"
            log "rate-limit disabled"
            ;;
        bot-block)
            sed -i '/if (\$bad_bot) { return 403; }/d' "$CONF_FILE"
            sed -i '/location = \/xmlrpc.php { deny all; }/d' "$CONF_FILE"
            log "bot-block disabled"
            ;;

        emergency)
            sed -i '/limit_req zone=emergency/d' "$CONF_FILE"
            log "emergency disabled"
            ;;
        php-allowlist)
            local tmp
            tmp="$(mktemp)"
            awk -v line="$ALLOWLIST_INCLUDE" 'index($0, line) == 0' "$CONF_FILE" > "$tmp" && cat "$tmp" > "$CONF_FILE"
            rm -f "$tmp" "$ALLOWLIST_CONF"
            log "php-allowlist disabled"
            ;;
        *)
            log "Unknown module $MODULE"
            ;;
    esac
}

BACKUP=""
ALLOWLIST_BACKUP=""
if [ "$STATUS" = on ] || [ "$STATUS" = off ] || [ "$STATUS" = paths ]; then
    BACKUP="$(mktemp)"
    cp -p "$CONF_FILE" "$BACKUP"
    # The allowlist lives in its own include file; roll it back too.
    if [ "$MODULE" = php-allowlist ]; then
        ALLOWLIST_BACKUP="$(mktemp -d)"
        [ ! -f "$ALLOWLIST_CONF" ] || cp -p "$ALLOWLIST_CONF" "$ALLOWLIST_BACKUP/conf"
        [ ! -f "$ALLOWLIST_PATHS" ] || cp -p "$ALLOWLIST_PATHS" "$ALLOWLIST_BACKUP/paths"
    fi
    rollback_security() {
        local status="$?"
        trap - EXIT
        if [ "$status" -ne 0 ]; then
            cp -p "$BACKUP" "$CONF_FILE"
            if [ -n "$ALLOWLIST_BACKUP" ]; then
                if [ -f "$ALLOWLIST_BACKUP/conf" ]; then cp -p "$ALLOWLIST_BACKUP/conf" "$ALLOWLIST_CONF"; else rm -f "$ALLOWLIST_CONF"; fi
                if [ -f "$ALLOWLIST_BACKUP/paths" ]; then cp -p "$ALLOWLIST_BACKUP/paths" "$ALLOWLIST_PATHS"; else rm -f "$ALLOWLIST_PATHS"; fi
            fi
            if nginx -t; then systemctl reload nginx || true; fi
        fi
        rm -rf "$BACKUP" "$ALLOWLIST_BACKUP"
        exit "$status"
    }
    trap rollback_security EXIT
fi

if [ "$STATUS" == "on" ]; then
    require_root "site_security.sh on"
    enable_module
elif [ "$STATUS" == "off" ]; then
    require_root "site_security.sh off"
    disable_module
elif [ "$STATUS" == "paths" ] && [ "$MODULE" == "php-allowlist" ]; then
    # Usage: site_security.sh <domain> php-allowlist paths <file>
    require_root "site_security.sh paths"
    php_allowlist_extras "${4:-/dev/null}" >/dev/null
    install -d -m 700 "$ALLOWLIST_STATE"
    grep -v '^[[:space:]]*$' "${4:-/dev/null}" > "$ALLOWLIST_PATHS" || true
    log "php-allowlist extra paths updated"
    if ! grep -qF "$ALLOWLIST_INCLUDE" "$CONF_FILE"; then
        echo "Success: allowlist paths saved for $DOMAIN"
        exit 0
    fi
    render_php_allowlist "$ALLOWLIST_PATHS" "$ALLOWLIST_CONF"
elif [ "$STATUS" == "status" ]; then
    case "$MODULE" in
        rate-limit) grep -q "limit_req zone=global burst=40" "$CONF_FILE" && echo "1" || echo "0" ;;
        bot-block) grep -q "if (\$bad_bot)" "$CONF_FILE" && echo "1" || echo "0" ;;

        emergency) grep -q "limit_req zone=emergency" "$CONF_FILE" && echo "1" || echo "0" ;;
        php-allowlist) grep -qF "$ALLOWLIST_INCLUDE" "$CONF_FILE" && echo "1" || echo "0" ;;
        *) echo "0" ;;
    esac
    exit 0
else
    echo "Invalid action. Must be 'on', 'off', or 'status'."
    exit 1
fi

if nginx -t >/dev/null 2>&1; then
    systemctl reload nginx
    echo "Success: $MODULE is now $STATUS for $DOMAIN"
else
    log "Nginx config test failed after modifying $MODULE to $STATUS"
    echo "Failed: Nginx test error"
    exit 1
fi
