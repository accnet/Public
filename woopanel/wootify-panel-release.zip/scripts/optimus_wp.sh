#!/bin/bash
set -e

DOMAIN=${1:-}

if [ -z "$DOMAIN" ]; then
    echo "Usage: $0 domain [options]"
    exit 1
fi

shift

WEB_ROOT="/var/www/$DOMAIN"
CRON_SLUG="$(printf '%s' "$DOMAIN" | tr -c 'a-zA-Z0-9' '_')"
CRON_SLUG="${CRON_SLUG%_}"
[ -n "$CRON_SLUG" ] || CRON_SLUG="wp_site"
SYSTEM_CRON_FILE="/etc/cron.d/wootify-wp-${CRON_SLUG}"
WP_CLI_RUNTIME_BASE="/var/cache/wootify/wp-cli"
WP_CLI_HOME=""
WP_CLI_CACHE_DIR=""
source "$(dirname "$0")/logging.sh"
source "$(dirname "$0")/permissions.sh"
LOG_FILE="$(resolve_log_file "wootify_install.log")"

log() {
    echo "[INFO] $1"
    # Write to log file for websocket stream
    echo "[OPTIMUS] $1" >> $LOG_FILE
}

log "Starting optimization for $DOMAIN..."

require_root "optimus_wp.sh"

cd "$WEB_ROOT"

source "$(dirname "$0")/os_detect.sh"

prepare_wp_cli_runtime() {
    WP_CLI_HOME="${WP_CLI_RUNTIME_BASE}/${WEB_USER}"
    WP_CLI_CACHE_DIR="${WP_CLI_HOME}/cache"

    install -d -m 755 -o "$WEB_USER" -g "$WEB_GROUP" "$WP_CLI_HOME"
    install -d -m 755 -o "$WEB_USER" -g "$WEB_GROUP" "$WP_CLI_CACHE_DIR"
}

run_wp_cli() {
    sudo -H -u "$WEB_USER" env \
        HOME="$WP_CLI_HOME" \
        WP_CLI_CACHE_DIR="$WP_CLI_CACHE_DIR" \
        /usr/local/bin/wp "$@"
}

# Ensure WP-CLI is installed (must be pre-installed by the stack installer)
if [ ! -x /usr/local/bin/wp ]; then
    echo "ERROR: WP-CLI not found at /usr/local/bin/wp. Please install the LEMP stack first."
    exit 1
fi

prepare_wp_cli_runtime

# Parse Flags
while [ "$#" -gt 0 ]; do
  case "$1" in
    --permalinks)
       log "Enabling Pretty Permalinks..."
       run_wp_cli rewrite structure '/%postname%/' --path="$WEB_ROOT" || true
       run_wp_cli rewrite flush --path="$WEB_ROOT" || true
       ;;
    --redis)
       if nc -z localhost 6379 2>/dev/null; then
           log "Installing Redis Object Cache..."
           run_wp_cli plugin install redis-cache --activate --path="$WEB_ROOT" || \
               log "Warning: failed to install redis-cache plugin, continuing..."
           run_wp_cli redis enable --path="$WEB_ROOT" || true
       else
           log "Redis service not detected. Skipping."
       fi
       ;;
    --clear-defaults)
       log "Cleaning up defaults and installing Storefront..."
       # Install Storefront
       run_wp_cli theme install storefront --activate --path="$WEB_ROOT" || true
       # Delete other themes
       THEMES_TO_DELETE="$(run_wp_cli theme list --field=name --path="$WEB_ROOT" | grep -vx "storefront" || true)"
       if [ -n "$THEMES_TO_DELETE" ]; then
           run_wp_cli theme delete $THEMES_TO_DELETE --path="$WEB_ROOT" || true
       fi
       # Delete default plugins (Hello Dolly, Akismet)
       run_wp_cli plugin delete hello akismet --path="$WEB_ROOT" || true
       ;;
    --install-plugins)
       log "Installing Optimus Plugins..."
       for plugin in classic-editor classic-widgets contact-form-7 disable-xml-rpc easy-wp-smtp woocommerce; do
           run_wp_cli plugin install "$plugin" --activate --path="$WEB_ROOT" || \
               log "Warning: failed to install/activate plugin $plugin, continuing..."
       done
       ;;
    --wp-cron)
       log "Disabling WP-Cron and adding Linux cron..."
       run_wp_cli config set DISABLE_WP_CRON true --raw --type=constant --path="$WEB_ROOT" || true
       # Ensure cron.d directory exists
       if [ ! -d /etc/cron.d ]; then
           mkdir -p /etc/cron.d
       fi
       # Use wp-cli directly instead of curl so the cron job works regardless of
       # whether the site has HTTP-only or HTTPS (curl -fsS without -L would silently
       # skip wp-cron when nginx returns a 301 redirect for SSL-enabled sites).
       cat > "$SYSTEM_CRON_FILE" <<EOF
SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
*/5 * * * * $WEB_USER /usr/bin/flock -n /tmp/wootify-${CRON_SLUG}.cron.lock env HOME=${WP_CLI_RUNTIME_BASE}/${WEB_USER} WP_CLI_CACHE_DIR=${WP_CLI_RUNTIME_BASE}/${WEB_USER}/cache /usr/local/bin/wp --path=/var/www/${DOMAIN} cron event run --due-now --quiet >/dev/null 2>&1
EOF
       chmod 644 "$SYSTEM_CRON_FILE"
       if command -v systemctl >/dev/null 2>&1; then
           systemctl reload cron 2>/dev/null || systemctl reload crond 2>/dev/null || true
       fi
       ;;
  esac
  shift
done

# Always do basic cleanup
log "Doing basic cleanup..."
run_wp_cli transient delete --all --path="$WEB_ROOT" || true
run_wp_cli cache flush --path="$WEB_ROOT" || true

log "Optimization complete for $DOMAIN."
