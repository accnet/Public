#!/bin/bash

# ==================== OS DETECTION ====================
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
    LIKE=${ID_LIKE:-}
else
    echo "Hệ điều hành quá cũ hoặc không được hỗ trợ!"
    exit 1
fi

# Biến cờ (Flag) rút gọn
IS_DEBIAN=false
IS_RHEL=false

if [[ "$OS" == "ubuntu" || "$OS" == "debian" || "$LIKE" == *"debian"* ]]; then
    IS_DEBIAN=true
    PKG_MANAGER="apt-get"
    WEB_USER="www-data"
    WEB_GROUP="www-data"
    NGINX_CONF_DIR="/etc/nginx/conf.d"
elif [[ "$OS" == "centos" || "$OS" == "rhel" || "$OS" == "fedora" || "$OS" == "almalinux" || "$OS" == "rocky" || "$LIKE" == *"rhel"* || "$LIKE" == *"fedora"* ]]; then
    IS_RHEL=true
    if command -v dnf &> /dev/null; then
        PKG_MANAGER="dnf"
    else
        PKG_MANAGER="yum"
    fi
    WEB_USER="nginx"
    WEB_GROUP="nginx"
    NGINX_CONF_DIR="/etc/nginx/conf.d"
fi

# The stack installer only implements EL 8/9 (Remi module streams + /etc/php-fpm.d)
# and Debian/Ubuntu. Fail fast instead of half-installing on anything else.
assert_supported_os() {
    local major="${VERSION_ID%%.*}"
    if [ "$IS_RHEL" = true ]; then
        if [ "$OS" = "fedora" ] || [ "${major:-0}" -lt 8 ] || [ "${major:-0}" -gt 9 ]; then
            echo "ERROR: ${PRETTY_NAME:-$OS $VERSION_ID} is not supported yet. Use AlmaLinux/Rocky/RHEL 8 or 9, Ubuntu or Debian."
            exit 1
        fi
    elif [ "$IS_DEBIAN" != true ]; then
        echo "ERROR: ${PRETTY_NAME:-$OS} is not supported. Use AlmaLinux/Rocky/RHEL 8 or 9, Ubuntu or Debian."
        exit 1
    fi
}

detect_nginx_runtime_user() {
    local configured_user=""

    if [ -f /etc/nginx/nginx.conf ]; then
        configured_user=$(awk '/^[[:space:]]*user[[:space:]]+/ {gsub(";", "", $2); print $2; exit}' /etc/nginx/nginx.conf)
    fi

    if [ -n "$configured_user" ]; then
        printf '%s\n' "$configured_user"
    else
        printf '%s\n' "$WEB_USER"
    fi
}

resolve_nginx_site_conf() {
    local domain="$1"
    local candidates=(
        "${NGINX_CONF_DIR}/${domain}.conf"
        "/etc/nginx/sites-available/${domain}.conf"
        "/etc/nginx/sites-available/${domain}"
    )
    local candidate

    for candidate in "${candidates[@]}"; do
        if [ -f "$candidate" ]; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done

    printf '%s\n' "${NGINX_CONF_DIR}/${domain}.conf"
    return 1
}

resolve_php_fpm_service_name() {
    local php_version="$1"
    local version_nodot="${php_version//./}"
    local candidates=()
    local candidate

    if [ "$IS_DEBIAN" = true ]; then
        candidates=("php${php_version}-fpm")
    else
        candidates=(
            "php${version_nodot}-php-fpm"
            "php-fpm"
        )
    fi

    for candidate in "${candidates[@]}"; do
        if systemctl list-unit-files "${candidate}.service" --no-legend 2>/dev/null | awk 'NF { found=1 } END { exit(found ? 0 : 1) }'; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done

    printf '%s\n' "${candidates[0]}"
    return 1
}

restart_php_fpm_for_version() {
    local php_version="$1"
    local service_name=""

    service_name="$(resolve_php_fpm_service_name "$php_version" || true)"
    if [ -z "$service_name" ]; then
        return 1
    fi

    systemctl restart "$service_name"
}

resolve_php_fpm_socket_for_version() {
    local php_version="$1"
    local version_nodot="${php_version//./}"
    local candidates=()
    local candidate

    if [ "$IS_DEBIAN" = true ]; then
        candidates=(
            "/run/php/php${php_version}-fpm.sock"
            "/run/php/php-fpm.sock"
        )
    else
        candidates=(
            "/run/php-fpm/php${version_nodot}-php-fpm.sock"
            "/run/php-fpm/www.sock"
            "/run/php/php${php_version}-fpm.sock"
            "/run/php/php-fpm.sock"
        )
    fi

    for candidate in "${candidates[@]}"; do
        if [ -S "$candidate" ]; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done

    printf '%s\n' "${candidates[0]}"
    return 1
}

# ---------------------------------------------------------------------------
# Read the Linux pool user from the per-site PHP-FPM pool config file.
# Returns the user name on success, or an empty string if no pool config is
# found (the caller should fall back to the web server user).
# Usage: POOL_USER="$(resolve_pool_user_from_config "$DOMAIN")"
# ---------------------------------------------------------------------------
resolve_pool_user_from_config() {
    local domain="$1"
    local conf=""

    # Try RHEL paths
    for f in "/etc/php-fpm.d/${domain}.conf" "/etc/php-fpm.d/${domain//./_}.conf"; do
        [ -f "$f" ] && conf="$f" && break
    done

    # Try Debian paths (glob over PHP versions)
    if [ -z "$conf" ]; then
        for f in /etc/php/*/fpm/pool.d/${domain}.conf; do
            [ -f "$f" ] && conf="$f" && break
        done
    fi
    if [ -z "$conf" ]; then
        for f in /etc/php/*/fpm/pool.d/${domain//./_}.conf; do
            [ -f "$f" ] && conf="$f" && break
        done
    fi

    if [ -z "$conf" ]; then
        printf ''
        return 1
    fi

    grep -E '^\s*user\s*=' "$conf" 2>/dev/null | head -n 1 | awk -F'=' '{print $2}' | tr -d ' '
}
# =======================================================

# ==================== SELINUX (RHEL) ====================
selinux_is_active() {
    [ "$IS_RHEL" = true ] && command -v selinuxenabled >/dev/null 2>&1 && selinuxenabled
}

wp_content_fcontext_spec() {
    local root="${1%/}"
    printf '%s/wp-content(/.*)?' "${root//./\\.}"
}

# Persist the writable context via semanage so restorecon or a full relabel
# does not silently revert wp-content to read-only (chcon is not persistent).
apply_wp_selinux_contexts() {
    local root="$1" spec
    selinux_is_active || return 0
    if command -v semanage >/dev/null 2>&1; then
        spec="$(wp_content_fcontext_spec "$root")"
        semanage fcontext -a -t httpd_sys_rw_content_t "$spec" 2>/dev/null \
            || semanage fcontext -m -t httpd_sys_rw_content_t "$spec" 2>/dev/null || true
        restorecon -R "$root" >/dev/null 2>&1 || true
    else
        chcon -R -t httpd_sys_content_t "$root" 2>/dev/null || true
        [ -d "$root/wp-content" ] && chcon -R -t httpd_sys_rw_content_t "$root/wp-content" 2>/dev/null || true
    fi
}

# Relabel a path under /var/www with its default (web-readable) context.
apply_selinux_web_context() {
    selinux_is_active || return 0
    restorecon -R "$1" >/dev/null 2>&1 || true
}

remove_wp_selinux_contexts() {
    selinux_is_active || return 0
    command -v semanage >/dev/null 2>&1 || return 0
    semanage fcontext -d "$(wp_content_fcontext_spec "$1")" 2>/dev/null || true
}

# ==================== WORDPRESS OBJECT CACHE ====================
# Redis Object Cache keys are only namespaced by WP_REDIS_PREFIX; without a
# per-site prefix every site on this server shares "alloptions" (siteurl!).
wp_redis_prefix() {
    printf '%s:' "$1"
}

# ==================== SSH / FAIL2BAN ====================
# Real SSH listening port(s); never assume 22 when banning or firewalling.
detect_ssh_ports() {
    local ports=""
    if command -v sshd >/dev/null 2>&1; then
        ports="$(sshd -T 2>/dev/null | awk '$1 == "port" {print $2}' | sort -un | tr '\n' ' ')"
    fi
    if [ -z "${ports// /}" ] && command -v ss >/dev/null 2>&1; then
        ports="$(ss -ltnpH 2>/dev/null | awk '/"sshd"/ {n = split($4, a, ":"); print a[n]}' | sort -un | tr '\n' ' ')"
    fi
    [ -n "${ports// /}" ] || ports="22"
    printf '%s\n' "$ports"
}

# EL's fail2ban ships every jail disabled (Debian enables sshd via
# defaults-debian.conf), so write an explicit sshd jail on both families.
write_fail2ban_sshd_jail() {
    local ports backend="auto" banaction=""
    ports="$(detect_ssh_ports | xargs | tr ' ' ',')"
    if [ "$IS_RHEL" = true ]; then
        backend="systemd"
        if systemctl is-active --quiet firewalld 2>/dev/null; then
            banaction="firewallcmd-rich-rules"
        else
            banaction="nftables-multiport"
        fi
    elif [ ! -f /var/log/auth.log ]; then
        backend="systemd"
    fi
    mkdir -p /etc/fail2ban/jail.d
    {
        echo "# Managed by WooPanel"
        echo "[sshd]"
        echo "enabled = true"
        echo "port = ${ports}"
        echo "backend = ${backend}"
        [ -z "$banaction" ] || echo "banaction = ${banaction}"
    } > /etc/fail2ban/jail.d/woopanel-sshd.local
}

# ==================== PHP-FPM PROTECT ====================
# php_admin_value lines only work inside a pool section, so the snippet is
# injected into every per-site pool (right after its [section] header, so a
# later malware lockdown block appended at the end still takes precedence).
PHP_PROTECT_SNIPPET="/etc/woopanel/php-protect.conf"
PHP_PROTECT_START="; WOOPANEL-PHP-PROTECT-START"
PHP_PROTECT_END="; WOOPANEL-PHP-PROTECT-END"

strip_php_protect_block() {
    sed -i "/^${PHP_PROTECT_START}\$/,/^${PHP_PROTECT_END}\$/d" "$1"
}

apply_php_protect_block() {
    local conf="$1" tmp
    [ -f "$PHP_PROTECT_SNIPPET" ] && [ -f "$conf" ] || return 0
    strip_php_protect_block "$conf"
    tmp="$(mktemp)"
    awk -v snippet="$PHP_PROTECT_SNIPPET" -v s="$PHP_PROTECT_START" -v e="$PHP_PROTECT_END" '
        { print }
        !done && /^\[[^]]+\]/ { print s; while ((getline line < snippet) > 0) print line; print e; done = 1 }
    ' "$conf" > "$tmp" && cat "$tmp" > "$conf"
    rm -f "$tmp"
}

list_site_pool_confs() {
    local f
    for f in /etc/php-fpm.d/*.conf /etc/php/*/fpm/pool.d/*.conf; do
        [ -f "$f" ] || continue
        [ "$(basename "$f")" = "www.conf" ] && continue
        printf '%s\n' "$f"
    done
}

# Prints "<service> <test-binary>" for each PHP-FPM owning one of the given pools.
php_fpm_targets_for_confs() {
    local conf ver
    for conf in "$@"; do
        if [[ "$conf" =~ ^/etc/php/([0-9]+\.[0-9]+)/fpm/ ]]; then
            ver="${BASH_REMATCH[1]}"
            printf '%s %s\n' "$(resolve_php_fpm_service_name "$ver" || true)" "php-fpm${ver}"
        else
            printf '%s %s\n' "$(resolve_php_fpm_service_name "" || true)" "php-fpm"
        fi
    done | sort -u
}

# Applies (mode=apply) or removes (mode=strip) the protect block on every site
# pool, validates with php-fpm -t and rolls everything back on failure.
sync_php_protect_pools() {
    local mode="$1" backup_dir conf svc bin failed=false
    local confs=()
    mapfile -t confs < <(list_site_pool_confs)
    [ "${#confs[@]}" -gt 0 ] || return 0

    backup_dir="$(mktemp -d)"
    for conf in "${confs[@]}"; do
        cp -p "$conf" "${backup_dir}/$(printf '%s' "$conf" | tr '/' '_')"
        if [ "$mode" = "apply" ]; then apply_php_protect_block "$conf"; else strip_php_protect_block "$conf"; fi
    done

    while read -r svc bin; do
        [ -n "$bin" ] && command -v "$bin" >/dev/null 2>&1 || continue
        "$bin" -t >/dev/null 2>&1 || failed=true
    done < <(php_fpm_targets_for_confs "${confs[@]}")

    if [ "$failed" = true ]; then
        for conf in "${confs[@]}"; do
            cat "${backup_dir}/$(printf '%s' "$conf" | tr '/' '_')" > "$conf"
        done
        rm -rf "$backup_dir"
        return 1
    fi
    rm -rf "$backup_dir"

    while read -r svc bin; do
        [ -n "$svc" ] || continue
        systemctl reload "$svc" 2>/dev/null || systemctl restart "$svc"
    done < <(php_fpm_targets_for_confs "${confs[@]}")
}

# Domain-derived names retain a digest so long names cannot share an identity.
resolve_pool_username() {
    local domain="${1:-${DOMAIN:-}}" stem digest
    stem="$(printf '%s' "$domain" | tr '.-' '__' | cut -c1-20)"
    digest="$(printf '%s' "$domain" | sha256sum | cut -c1-8)"
    printf 'wp_%s_%s' "$stem" "$digest"
}

validate_site_domain() {
    [[ "$1" =~ ^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$ ]] && [ "${#1}" -le 253 ]
}

pool_user_is_unshared() {
    local domain="$1" user="$2" f
    for f in /etc/php-fpm.d/*.conf /etc/php/*/fpm/pool.d/*.conf; do
        [ -f "$f" ] || continue
        [ "$(basename "$f")" = "$domain.conf" ] && continue
        if awk -F= -v u="$user" '/^[[:space:]]*user[[:space:]]*=/ {gsub(/[[:space:]]/, "", $2); if ($2 == u) found=1} END {exit(found ? 0 : 1)}' "$f"; then
            return 1
        fi
    done
    return 0
}
