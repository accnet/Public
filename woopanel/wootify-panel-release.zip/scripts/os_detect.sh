#!/bin/bash

# ==================== OS DETECTION ====================
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
    LIKE=$ID_LIKE
else
    echo "Hệ điều hành quá cũ hoặc không được hỗ trợ!"
    exit 1
fi

# Biến cờ (Flag) rút gọn
IS_DEBIAN=false
IS_RHEL=false

if [[ "$OS" == "ubuntu" || "$OS" == "debian" || "$LIKE" == *"debian"* ]]; then
    IS_DEBIAN=true
    PKG_MANAGER="apt-get"
    WEB_USER="www-data"
    WEB_GROUP="www-data"
    NGINX_CONF_DIR="/etc/nginx/conf.d"
elif [[ "$OS" == "centos" || "$OS" == "rhel" || "$OS" == "fedora" || "$OS" == "almalinux" || "$OS" == "rocky" || "$LIKE" == *"rhel"* || "$LIKE" == *"fedora"* ]]; then
    IS_RHEL=true
    if command -v dnf &> /dev/null; then
        PKG_MANAGER="dnf"
    else
        PKG_MANAGER="yum"
    fi
    WEB_USER="nginx"
    WEB_GROUP="nginx"
    NGINX_CONF_DIR="/etc/nginx/conf.d"
fi

detect_nginx_runtime_user() {
    local configured_user=""

    if [ -f /etc/nginx/nginx.conf ]; then
        configured_user=$(awk '/^[[:space:]]*user[[:space:]]+/ {gsub(";", "", $2); print $2; exit}' /etc/nginx/nginx.conf)
    fi

    if [ -n "$configured_user" ]; then
        printf '%s\n' "$configured_user"
    else
        printf '%s\n' "$WEB_USER"
    fi
}

resolve_nginx_site_conf() {
    local domain="$1"
    local candidates=(
        "${NGINX_CONF_DIR}/${domain}.conf"
        "/etc/nginx/sites-available/${domain}.conf"
        "/etc/nginx/sites-available/${domain}"
    )
    local candidate

    for candidate in "${candidates[@]}"; do
        if [ -f "$candidate" ]; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done

    printf '%s\n' "${NGINX_CONF_DIR}/${domain}.conf"
    return 1
}

resolve_php_fpm_service_name() {
    local php_version="$1"
    local version_nodot="${php_version//./}"
    local candidates=()
    local candidate

    if [ "$IS_DEBIAN" = true ]; then
        candidates=("php${php_version}-fpm")
    else
        candidates=(
            "php${version_nodot}-php-fpm"
            "php-fpm"
        )
    fi

    for candidate in "${candidates[@]}"; do
        if systemctl list-unit-files "${candidate}.service" --no-legend 2>/dev/null | awk 'NF { found=1 } END { exit(found ? 0 : 1) }'; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done

    printf '%s\n' "${candidates[0]}"
    return 1
}

restart_php_fpm_for_version() {
    local php_version="$1"
    local service_name=""

    service_name="$(resolve_php_fpm_service_name "$php_version" || true)"
    if [ -z "$service_name" ]; then
        return 1
    fi

    systemctl restart "$service_name"
}

resolve_php_fpm_socket_for_version() {
    local php_version="$1"
    local version_nodot="${php_version//./}"
    local candidates=()
    local candidate

    if [ "$IS_DEBIAN" = true ]; then
        candidates=(
            "/run/php/php${php_version}-fpm.sock"
            "/run/php/php-fpm.sock"
        )
    else
        candidates=(
            "/run/php-fpm/php${version_nodot}-php-fpm.sock"
            "/run/php-fpm/www.sock"
            "/run/php/php${php_version}-fpm.sock"
            "/run/php/php-fpm.sock"
        )
    fi

    for candidate in "${candidates[@]}"; do
        if [ -S "$candidate" ]; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done

    printf '%s\n' "${candidates[0]}"
    return 1
}

# ---------------------------------------------------------------------------
# Read the Linux pool user from the per-site PHP-FPM pool config file.
# Returns the user name on success, or an empty string if no pool config is
# found (the caller should fall back to the web server user).
# Usage: POOL_USER="$(resolve_pool_user_from_config "$DOMAIN")"
# ---------------------------------------------------------------------------
resolve_pool_user_from_config() {
    local domain="$1"
    local conf=""

    # Try RHEL paths
    for f in "/etc/php-fpm.d/${domain}.conf" "/etc/php-fpm.d/${domain//./_}.conf"; do
        [ -f "$f" ] && conf="$f" && break
    done

    # Try Debian paths (glob over PHP versions)
    if [ -z "$conf" ]; then
        for f in /etc/php/*/fpm/pool.d/${domain}.conf; do
            [ -f "$f" ] && conf="$f" && break
        done
    fi
    if [ -z "$conf" ]; then
        for f in /etc/php/*/fpm/pool.d/${domain//./_}.conf; do
            [ -f "$f" ] && conf="$f" && break
        done
    fi

    if [ -z "$conf" ]; then
        printf ''
        return 1
    fi

    grep -E '^\s*user\s*=' "$conf" 2>/dev/null | head -n 1 | awk -F'=' '{print $2}' | tr -d ' '
}
# =======================================================
