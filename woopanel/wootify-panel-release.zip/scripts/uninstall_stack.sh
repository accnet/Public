#!/bin/bash
set -e

# Configuration
export DEBIAN_FRONTEND=noninteractive
PRESERVE_NGINX_CONFIG=${PRESERVE_NGINX_CONFIG:-"false"}
PRESERVE_SQL_DATA=${PRESERVE_SQL_DATA:-"false"}
PRESERVE_SITE_DATA=${PRESERVE_SITE_DATA:-"false"}
source "$(dirname "$0")/logging.sh"
source "$(dirname "$0")/permissions.sh"
LOG_FILE="$(resolve_log_file "wootify_uninstall.log")"

# Helper Functions
log() {
    echo "[INFO] $1"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [INFO] $1" >> "$LOG_FILE"
}

progress() {
    echo "[PROGRESS] $1"
}

source "$(dirname "$0")/os_detect.sh"

require_root "uninstall_stack.sh"

# Error Handling
trap 'echo "[ERROR] Uninstallation failed on line $LINENO"; exit 1' ERR

# --- Main Uninstallation ---

progress 5
log "Initializing uninstallation..."
log "WARNING: This will remove Nginx, PHP (all versions), and MariaDB binaries."
log "Preserve Nginx config: ${PRESERVE_NGINX_CONFIG}"
log "Preserve SQL data/config: ${PRESERVE_SQL_DATA}"
log "Preserve site files: ${PRESERVE_SITE_DATA}"

progress 10
log "Stopping services..."
systemctl stop nginx > /dev/null 2>&1 || true
systemctl stop mariadb > /dev/null 2>&1 || true
# Stop all PHP-FPM services via systemctl to avoid killing unrelated processes
for _svc in $(systemctl list-units --type=service --state=running --no-legend 2>/dev/null | awk '{print $1}' | grep -E 'php.*fpm'); do
    systemctl stop "$_svc" > /dev/null 2>&1 || true
done
pkill -f php-fpm > /dev/null 2>&1 || true  # fallback for non-systemd

progress 30
log "Removing Nginx Web Server..."
if [ "$IS_DEBIAN" = true ]; then
    if [ "$PRESERVE_NGINX_CONFIG" = "true" ]; then
        apt-get remove -y nginx nginx-common nginx-core > /dev/null 2>&1 || true
    else
        apt-get remove --purge -y nginx nginx-common nginx-core > /dev/null 2>&1 || true
    fi
elif [ "$IS_RHEL" = true ]; then
    $PKG_MANAGER remove -y nginx > /dev/null 2>&1 || true
fi

progress 50
log "Removing PHP and Extensions..."
# Remove Redis Server and specific extensions explicitly first
if [ "$IS_DEBIAN" = true ]; then
    systemctl stop redis-server > /dev/null 2>&1 || true
    apt-get remove --purge -y redis-server "php*-redis" "php*-imagick" "php*-opcache" > /dev/null 2>&1 || true
    # Remove all PHP versions
    apt-get remove --purge -y "php*" > /dev/null 2>&1 || true
elif [ "$IS_RHEL" = true ]; then
    systemctl stop redis > /dev/null 2>&1 || true
    bash "$(dirname "$0")/manage_extension.sh" uninstall redis > /dev/null 2>&1 || true
    bash "$(dirname "$0")/manage_extension.sh" uninstall imagick > /dev/null 2>&1 || true
    bash "$(dirname "$0")/manage_extension.sh" uninstall opcache > /dev/null 2>&1 || true
    $PKG_MANAGER remove -y redis > /dev/null 2>&1 || true
    $PKG_MANAGER remove -y "php*" > /dev/null 2>&1 || true
fi

progress 70
log "Removing MariaDB Database..."
if [ "$IS_DEBIAN" = true ]; then
    if [ "$PRESERVE_SQL_DATA" = "true" ]; then
        apt-get remove -y mariadb-server mariadb-client "mysql*" > /dev/null 2>&1 || true
    else
        apt-get remove --purge -y mariadb-server mariadb-client "mysql*" > /dev/null 2>&1 || true
    fi
elif [ "$IS_RHEL" = true ]; then
    $PKG_MANAGER remove -y MariaDB-server MariaDB-client mariadb-server mariadb > /dev/null 2>&1 || true
fi
# Note: We do NOT remove /var/lib/mysql automatically to preserve data safety,
# unless preserve mode is disabled.
if [ "$PRESERVE_SQL_DATA" != "true" ]; then
    log "Purging MariaDB data directory (/var/lib/mysql)..."
    rm -rf /var/lib/mysql > /dev/null 2>&1 || true
fi

progress 90
log "Cleaning up system packages..."
if [ "$IS_DEBIAN" = true ]; then
    apt-get autoremove -y > /dev/null 2>&1
    apt-get clean > /dev/null 2>&1
elif [ "$IS_RHEL" = true ]; then
    $PKG_MANAGER autoremove -y > /dev/null 2>&1
    $PKG_MANAGER clean all > /dev/null 2>&1
fi

log "Resetting VPS optimization state markers (PHP/MariaDB/Nginx)..."
# PHP optimization markers (Debian)
find /etc/php -type f -name "www.conf.bak" -delete > /dev/null 2>&1 || true
# PHP optimization markers (RHEL)
rm -f /etc/php-fpm.d/www.conf.bak > /dev/null 2>&1 || true

# MariaDB optimization markers
if [ "$PRESERVE_SQL_DATA" != "true" ]; then
    rm -f /etc/mysql/mariadb.conf.d/50-server.cnf.bak > /dev/null 2>&1 || true
    rm -f /etc/mysql/mariadb.conf.d/99-wootify-custom.cnf > /dev/null 2>&1 || true
    rm -f /etc/mysql/mariadb.conf.d/99-wootify-performance.cnf > /dev/null 2>&1 || true
    rm -f /etc/my.cnf.d/mariadb-server.cnf.bak > /dev/null 2>&1 || true
    rm -f /etc/my.cnf.d/99-wootify-custom.cnf > /dev/null 2>&1 || true
    rm -f /etc/my.cnf.d/99-wootify-performance.cnf > /dev/null 2>&1 || true
fi

# Nginx optimization markers
if [ "$PRESERVE_NGINX_CONFIG" != "true" ]; then
    rm -f /etc/nginx/nginx.conf.bak > /dev/null 2>&1 || true
    rm -f /etc/nginx/nginx.conf.bak-wootify > /dev/null 2>&1 || true
fi
rm -f /etc/apt/sources.list.d/nginx.list > /dev/null 2>&1 || true
rm -f /etc/apt/preferences.d/99nginx > /dev/null 2>&1 || true
rm -f /etc/yum.repos.d/nginx.repo > /dev/null 2>&1 || true

# Remove config directories
if [ "$PRESERVE_NGINX_CONFIG" != "true" ]; then
    rm -rf /etc/nginx > /dev/null 2>&1 || true
fi
rm -rf /etc/php > /dev/null 2>&1 || true
rm -rf /etc/php-fpm.d > /dev/null 2>&1 || true

# Remove site files when not preserving data for reinstall
if [ "$PRESERVE_SITE_DATA" != "true" ]; then
    log "Purging site files under /var/www..."
    rm -rf /var/www/* > /dev/null 2>&1 || true
fi

progress 100
log "Uninstallation Completed Successfully!"
