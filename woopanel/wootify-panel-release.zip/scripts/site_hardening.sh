#!/bin/bash
# site_hardening.sh — "Hardened mode": WordPress code is read-only for PHP.
#
# Usage:
#   site_hardening.sh <domain> lock              enable + lock now
#   site_hardening.sh <domain> unlock <minutes>  writable for updates, relocks later
#   site_hardening.sh <domain> disable           back to normal (writable) mode
#   site_hardening.sh <domain> status            "enabled=0|1 locked=0|1 unlock_until=<epoch>"
#   site_hardening.sh relock-due                 relock every site whose unlock expired (cron)
#
# Locked: everything is root:<site group>, so the site's PHP user can read but
# not modify core, plugins, themes or wp-config.php (0640, read via group).
# Only the data directories below stay owned by the PHP user. Requires the
# per-site group model (run Repair Permissions on older sites first).
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
STATE_BASE="${PROJECT_DIR}/storage/hardened"
source "${SCRIPT_DIR}/logging.sh"
source "${SCRIPT_DIR}/permissions.sh"
source "${SCRIPT_DIR}/os_detect.sh"
LOG_FILE="$(resolve_log_file "wootify_malware.log")"

# wp-content subdirectories WordPress and common plugins must write at runtime.
WRITABLE_DIRS=(uploads cache upgrade upgrade-temp-backup wflogs w3tc-config et-cache litespeed wpo-cache ai1wm-backups updraft)

if [ "${1:-}" = "relock-due" ]; then
    now="$(date +%s)"
    for state in "$STATE_BASE"/*; do
        [ -f "$state/enabled" ] && [ -f "$state/unlock_until" ] || continue
        [ "$(cat "$state/unlock_until")" -le "$now" ] || continue
        bash "${BASH_SOURCE[0]}" "$(basename "$state")" lock || true
    done
    exit 0
fi

DOMAIN="${1:-}"
ACTION="${2:-status}"
MINUTES="${3:-30}"
validate_site_domain "$DOMAIN" || { echo "Invalid domain" >&2; exit 1; }
log() { echo "$(date '+%Y-%m-%d %H:%M:%S') [HARDENED] ${DOMAIN} $1" >> "$LOG_FILE"; }

WEB_ROOT="/var/www/${DOMAIN}"
STATE="${STATE_BASE}/${DOMAIN}"
QUARANTINE_DIR="${WEB_ROOT}/.woopanel-quarantine"
[ -d "$WEB_ROOT" ] || { echo "Web root not found: ${WEB_ROOT}" >&2; exit 1; }
POOL_USER="$(resolve_pool_user_from_config "$DOMAIN" || true)"
[ -n "$POOL_USER" ] && id "$POOL_USER" >/dev/null 2>&1 || { echo "Pool user for ${DOMAIN} not found" >&2; exit 1; }
SITE_GROUP="$(site_group_of "$POOL_USER")"

own_tree() {
    # Physical walk: never follow symlinks, never touch the quarantine.
    find -P "$1" -path "$QUARANTINE_DIR" -prune -o ! -type l -exec chown -h "$2" {} +
}

status() {
    local enabled=0 locked=0 until=0
    [ -f "$STATE/enabled" ] && enabled=1
    [ -f "$STATE/unlock_until" ] && until="$(cat "$STATE/unlock_until")"
    if [ "$enabled" = 1 ] && [ "$(stat -c '%U' "$WEB_ROOT")" = "root" ]; then locked=1; fi
    echo "enabled=${enabled} locked=${locked} unlock_until=${until}"
}

lock() {
    require_root "site_hardening.sh lock"
    if [ "$SITE_GROUP" = "$WEB_GROUP" ]; then
        echo "This site still shares the ${WEB_GROUP} group with other sites. Run Repair Permissions first." >&2
        exit 1
    fi
    install -d -m 0700 "$STATE"
    own_tree "$WEB_ROOT" "root:${SITE_GROUP}"
    local dir
    install -d -m 0755 -o "$POOL_USER" -g "$SITE_GROUP" "$WEB_ROOT/wp-content/uploads"
    for dir in "${WRITABLE_DIRS[@]}"; do
        [ -d "$WEB_ROOT/wp-content/$dir" ] && own_tree "$WEB_ROOT/wp-content/$dir" "${POOL_USER}:${SITE_GROUP}"
    done
    if [ -f "$WEB_ROOT/wp-config.php" ]; then
        chown root:"$SITE_GROUP" "$WEB_ROOT/wp-config.php"
        chmod 0640 "$WEB_ROOT/wp-config.php"
    fi
    chmod 0750 "$WEB_ROOT"
    touch "$STATE/enabled"
    rm -f "$STATE/unlock_until"
    apply_wp_selinux_contexts "$WEB_ROOT"
    log "Hardened mode locked"
    echo "Hardened mode: code is read-only for PHP; only wp-content/{$(IFS=,; echo "${WRITABLE_DIRS[*]}")} stay writable."
}

unlock() {
    require_root "site_hardening.sh unlock"
    own_tree "$WEB_ROOT" "${POOL_USER}:${SITE_GROUP}"
    [ ! -f "$WEB_ROOT/wp-config.php" ] || chmod 0600 "$WEB_ROOT/wp-config.php"
    [ "$SITE_GROUP" = "$WEB_GROUP" ] || chmod 0750 "$WEB_ROOT"
    apply_wp_selinux_contexts "$WEB_ROOT"
}

case "$ACTION" in
    status) status ;;
    lock) lock ;;
    unlock)
        [[ "$MINUTES" =~ ^[0-9]+$ ]] && [ "$MINUTES" -ge 1 ] && [ "$MINUTES" -le 1440 ] || { echo "Minutes must be 1-1440" >&2; exit 1; }
        [ -f "$STATE/enabled" ] || { echo "Hardened mode is not enabled" >&2; exit 1; }
        unlock
        echo $(( $(date +%s) + MINUTES * 60 )) > "$STATE/unlock_until"
        log "Unlocked for ${MINUTES} minute(s)"
        echo "Unlocked for ${MINUTES} minute(s); it locks again automatically."
        ;;
    disable)
        unlock
        rm -rf -- "$STATE"
        log "Hardened mode disabled"
        echo "Hardened mode disabled; the site's PHP user owns its files again."
        ;;
    *) echo "Usage: $0 <domain> lock|unlock <minutes>|disable|status" >&2; exit 1 ;;
esac
