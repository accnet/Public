#!/bin/bash
set -e

# Error Handling
trap 'echo "[ERROR] Installation failed on line $LINENO"; exit 1' ERR

# Configuration
export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a
export NEEDRESTART_SUSPEND=1
PHP_VERSION=${PHP_VERSION:-"8.2"}
MARIADB_VERSION=${MARIADB_VERSION:-"11.8"}
NGINX_VERSION_SERIES=${NGINX_VERSION_SERIES:-"1.27"}
INSTALL_NGINX=${INSTALL_NGINX:-"true"}
INSTALL_MARIADB=${INSTALL_MARIADB:-"true"}
source "$(dirname "$0")/logging.sh"
source "$(dirname "$0")/permissions.sh"
LOG_FILE="$(resolve_log_file "wootify_install.log")"

# Colors (Not used in log function but kept for reference)
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

source "$(dirname "$0")/os_detect.sh"

require_root "install_stack.sh"

# Helper Functions
log() {
    echo "[INFO] $1"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [INFO] $1" >> "$LOG_FILE"
}

progress() {
    echo "[PROGRESS] $1"
}

ensure_line_in_file() {
    local line="$1"
    local file="$2"

    touch "$file"
    grep -Fqx "$line" "$file" 2>/dev/null || echo "$line" >> "$file"
}

replace_or_append_setting() {
    local file="$1"
    local key_regex="$2"
    local new_line="$3"

    if grep -Eq "^[;[:space:]]*${key_regex}[[:space:]]*=" "$file" 2>/dev/null; then
        sed -i -E "s|^[;[:space:]]*${key_regex}[[:space:]]*=.*|${new_line}|" "$file"
    else
        echo "$new_line" >> "$file"
    fi
}

get_system_profile() {
    local mem_mb cpu_cores

    mem_mb=$(( $(awk '/MemTotal/ {print $2}' /proc/meminfo) / 1024 ))
    cpu_cores=$(nproc 2>/dev/null || echo 1)

    SYSTEM_RAM_MB=${mem_mb:-2048}
    SYSTEM_CPU_CORES=${cpu_cores:-1}

    if [ "$SYSTEM_RAM_MB" -ge 8192 ] && [ "$SYSTEM_CPU_CORES" -ge 4 ]; then
        STACK_PROFILE="large"
    elif [ "$SYSTEM_RAM_MB" -ge 4096 ] && [ "$SYSTEM_CPU_CORES" -ge 2 ]; then
        STACK_PROFILE="medium"
    else
        STACK_PROFILE="small"
    fi

    log "Detected system profile: RAM=${SYSTEM_RAM_MB}MB, CPU=${SYSTEM_CPU_CORES} cores, profile=${STACK_PROFILE}"
}

is_wsl() {
    grep -qiE 'microsoft|wsl' /proc/version 2>/dev/null
}

retry() {
    local n=1
    local max=3
    local delay=5
    while true; do
        "$@" && break || {
            local exit_code=$?
            if [[ $exit_code -eq 137 || $exit_code -eq 130 ]]; then
                log "Process was killed or interrupted (Code: $exit_code). This usually means Out-Of-Memory."
                # We don't return here to allow the outer loop to retry or fail
            fi
            
            if [[ $n -lt $max ]]; then
                ((n++))
                log "Command failed. Retrying in $delay seconds ($n/$max)..."
                sleep $delay;
            else
                log "Command failed after $n attempts."
                return 1
            fi
        }
    done
}

port_80_in_use() {
    if command -v ss >/dev/null 2>&1; then
        ss -ltn '( sport = :80 )' | tail -n +2 | grep -q ':80'
        return $?
    fi

    if command -v netstat >/dev/null 2>&1; then
        netstat -ltn 2>/dev/null | awk '{print $4}' | grep -Eq '(^|[:.])80$'
        return $?
    fi

    return 1
}

port_80_process_names() {
    if command -v ss >/dev/null 2>&1; then
        ss -ltnpH '( sport = :80 )' 2>/dev/null | grep -o 'users:((".*"))' | \
            sed -E 's/.*users:\(\("([^"]+)".*/\1/' | sort -u
        return 0
    fi

    if command -v lsof >/dev/null 2>&1; then
        lsof -nP -iTCP:80 -sTCP:LISTEN 2>/dev/null | awk 'NR>1 {print $1}' | sort -u
        return 0
    fi

    return 1
}

port_80_owned_by_nginx() {
    local names

    if ! port_80_in_use; then
        return 1
    fi

    if systemctl is-active --quiet nginx 2>/dev/null; then
        return 0
    fi

    names="$(port_80_process_names || true)"
    echo "$names" | grep -Eq '(^|[[:space:]])nginx($|[[:space:]])'
}

current_php_version() {
    php -r "echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION;" 2>/dev/null || true
}

nginx_is_installed() {
    command -v nginx >/dev/null 2>&1
}

php_target_version_installed() {
    local current_ver

    if ! command -v php >/dev/null 2>&1; then
        return 1
    fi

    current_ver="$(current_php_version)"
    [ "$current_ver" = "$PHP_VERSION" ]
}

mariadb_is_installed() {
    command -v mariadb >/dev/null 2>&1 || command -v mysql >/dev/null 2>&1
}

stop_conflicting_web_servers() {
    local svc

    for svc in httpd apache2 caddy openlitespeed lsws; do
        if systemctl list-unit-files "${svc}.service" >/dev/null 2>&1; then
            if systemctl is-active --quiet "${svc}" || systemctl is-enabled --quiet "${svc}" 2>/dev/null; then
                log "Stopping conflicting web server: ${svc}"
                systemctl stop "${svc}" || true
                systemctl disable "${svc}" || true
            fi
        fi
    done
}

apache2_is_installed() {
    if [ "$IS_DEBIAN" != "true" ]; then
        return 1
    fi

    dpkg-query -W -f='${Status}' apache2 2>/dev/null | grep -q "install ok installed"
}

apache2_controls_port_80() {
    if [ "$IS_DEBIAN" != "true" ]; then
        return 1
    fi

    if ! apache2_is_installed; then
        return 1
    fi

    if ! port_80_in_use; then
        return 1
    fi

    if command -v ss >/dev/null 2>&1; then
        if ss -ltnp '( sport = :80 )' 2>/dev/null | grep -qi 'apache2'; then
            return 0
        fi
    fi

    if systemctl is-active --quiet apache2 2>/dev/null || systemctl is-enabled --quiet apache2 2>/dev/null; then
        return 0
    fi

    return 1
}

remove_apache2_if_conflicting() {
    if ! apache2_controls_port_80; then
        return 0
    fi

    log "Apache2 detected on Ubuntu/Debian and port 80 is busy. Removing Apache2 so LEMP can install Nginx..."
    systemctl stop apache2 2>/dev/null || true
    systemctl disable apache2 2>/dev/null || true
    killall apache2 apache2ctl > /dev/null 2>&1 || true
    pkill -9 apache2 > /dev/null 2>&1 || true
    retry apt-get purge -y apache2 apache2-bin apache2-data apache2-utils
    retry apt-get autoremove -y
}

ensure_nginx_can_bind() {
    stop_conflicting_web_servers
    remove_apache2_if_conflicting

    if port_80_in_use; then
        if port_80_owned_by_nginx; then
            log "Port 80 is already bound by Nginx. Reusing the existing Nginx listener."
            return 0
        fi

        log "Port 80 is already in use. Nginx cannot start until that service is stopped."
        local owners
        owners="$(port_80_process_names || true)"
        if [ -n "$owners" ]; then
            log "Port 80 listeners detected: $owners"
        fi
        if command -v ss >/dev/null 2>&1; then
            ss -ltnp '( sport = :80 )' >> "$LOG_FILE" 2>&1 || true
        fi
        echo "ERROR: PORT_80_IN_USE"
        return 1
    fi
}

dump_nginx_failure_details() {
    log "Nginx failed to start or reload. Collecting diagnostics..."
    local pid_file
    pid_file="$(resolve_nginx_pid_file)"

    if command -v nginx >/dev/null 2>&1; then
        nginx -t >> "$LOG_FILE" 2>&1 || true
        nginx -V >> "$LOG_FILE" 2>&1 || true
    fi

    echo "--- systemctl cat nginx.service ---" >> "$LOG_FILE"
    systemctl cat nginx.service >> "$LOG_FILE" 2>&1 || true
    echo "--- systemctl status nginx.service ---" >> "$LOG_FILE"
    systemctl status nginx.service --no-pager -l >> "$LOG_FILE" 2>&1 || true
    echo "--- journalctl -xeu nginx.service ---" >> "$LOG_FILE"
    journalctl -xeu nginx.service --no-pager -n 80 >> "$LOG_FILE" 2>&1 || true
    echo "--- runtime path details ---" >> "$LOG_FILE"
    ls -ldZ /run /run/nginx /var/run /var/log/nginx /var/lib/nginx >> "$LOG_FILE" 2>&1 || true
    ls -lZ "$pid_file" /etc/nginx/nginx.conf /etc/nginx/conf.d >> "$LOG_FILE" 2>&1 || true
    echo "--- nginx error.log ---" >> "$LOG_FILE"
    tail -n 80 /var/log/nginx/error.log >> "$LOG_FILE" 2>&1 || true
}

normalize_nginx_config_permissions() {
    [ -d /etc/nginx ] || return 0

    chown root:root /etc/nginx 2>/dev/null || true
    find /etc/nginx -type d -exec chmod 755 {} + 2>/dev/null || true
    find /etc/nginx -type f -exec chmod 644 {} + 2>/dev/null || true
    find /etc/nginx -type l -exec test -e {} \; 2>/dev/null || true

    if command -v restorecon >/dev/null 2>&1; then
        restorecon -Rv /etc/nginx >> "$LOG_FILE" 2>&1 || true
    fi
}

restore_nginx_path_context() {
    local target_path="$1"

    if command -v restorecon >/dev/null 2>&1; then
        restorecon -v "$target_path" >> "$LOG_FILE" 2>&1 || true
    fi
}

restore_path_context_recursive() {
    local target_path="$1"

    if [ -e "$target_path" ] && command -v restorecon >/dev/null 2>&1; then
        restorecon -Rv "$target_path" >> "$LOG_FILE" 2>&1 || true
    fi
}

normalize_web_stack_selinux_contexts() {
    local path

    [ "$IS_RHEL" = true ] || return 0

    for path in \
        /etc/nginx \
        /var/log/nginx \
        /var/lib/nginx \
        /usr/share/nginx/html \
        /var/www \
        /var/www/html \
        /run \
        /run/nginx \
        /run/php-fpm \
        /var/run/php-fpm \
        /etc/php-fpm.d \
        /etc/php-fpm.conf; do
        restore_path_context_recursive "$path"
    done
}

apply_rhel_selinux_booleans() {
    [ "$IS_RHEL" = true ] || return 0
    command -v setsebool >/dev/null 2>&1 || return 0

    # Only apply when SELinux is active (enforcing or permissive)
    if command -v getenforce >/dev/null 2>&1; then
        getenforce | grep -qiE 'Enforcing|Permissive' || return 0
    fi

    log "Applying SELinux booleans for web stack compatibility..."
    setsebool -P httpd_can_network_connect 1 || true
    setsebool -P httpd_can_network_connect_db 1 || true
    setsebool -P httpd_setrlimit 1 || true
}

resolve_nginx_pid_file() {
    local pid_file

    pid_file="$(awk '
        /^[[:space:]]*pid[[:space:]]+[^;]+;/ {
            gsub(";", "", $2)
            print $2
            exit
        }
    ' /etc/nginx/nginx.conf 2>/dev/null)"

    if [ -n "$pid_file" ]; then
        printf '%s\n' "$pid_file"
        return 0
    fi

    printf '%s\n' "/run/nginx.pid"
}

normalize_nginx_runtime_state() {
    local pid_file pid_dir

    pid_file="$(resolve_nginx_pid_file)"
    pid_dir="$(dirname "$pid_file")"

    mkdir -p "$pid_dir"
    chown root:root "$pid_dir" 2>/dev/null || true
    chmod 755 "$pid_dir" 2>/dev/null || true
    restore_path_context_recursive "$pid_dir"

    if [ -f "$pid_file" ] && ! pgrep -x nginx >/dev/null 2>&1; then
        rm -f "$pid_file"
    fi

    # Always ensure the pid file exists with the correct SELinux context before nginx
    # starts. On SELinux-enforcing systems systemd may pre-create the file with the
    # generic var_run_t label; nginx (httpd_t domain) then cannot write to it.
    # Pre-creating + restorecon gives it httpd_var_run_t so the write is allowed.
    if [ ! -f "$pid_file" ]; then
        touch "$pid_file" 2>/dev/null || true
    fi
    chown root:root "$pid_file" 2>/dev/null || true
    chmod 644 "$pid_file" 2>/dev/null || true
    restore_path_context_recursive "$pid_file"

    systemctl reset-failed nginx >/dev/null 2>&1 || true
}

safe_nginx_start() {
    normalize_nginx_config_permissions
    normalize_nginx_runtime_state

    if command -v nginx >/dev/null 2>&1; then
        if ! nginx -t; then
            dump_nginx_failure_details
            return 1
        fi
    fi

    if ! systemctl start nginx; then
        dump_nginx_failure_details
        return 1
    fi
}

safe_nginx_restart() {
    normalize_nginx_config_permissions
    normalize_nginx_runtime_state

    if command -v nginx >/dev/null 2>&1; then
        if ! nginx -t; then
            dump_nginx_failure_details
            return 1
        fi
    fi

    if ! systemctl restart nginx; then
        dump_nginx_failure_details
        return 1
    fi
}

# Ensure minimum swap for stable installation on low RAM VPS
ensure_swap() {
    local ram_kb=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    local swap_kb=$(grep SwapTotal /proc/meminfo | awk '{print $2}')
    
    if [ "$ram_kb" -lt 2000000 ] && [ "$swap_kb" -lt 500000 ]; then
        log "Low RAM detected ($((ram_kb/1024))MB) and no/low swap. Creating 1GB temporary swap for stable installation..."
        if [ ! -f /wootify_tmp_swap ]; then
            fallocate -l 1G /wootify_tmp_swap || dd if=/dev/zero of=/wootify_tmp_swap bs=1M count=1024
            chmod 600 /wootify_tmp_swap
            mkswap /wootify_tmp_swap
            swapon /wootify_tmp_swap
            log "Temporary swap enabled."
        fi
    fi
}

optimize_sysctl() {
    log "Optimizing system limits..."
    cat > /etc/sysctl.d/99-wootify.conf <<EOF
fs.file-max = 100000
net.core.somaxconn = 4096
net.ipv4.tcp_max_syn_backlog = 8192
net.ipv4.tcp_tw_reuse = 1
net.ipv4.ip_local_port_range = 10240 65535
vm.swappiness = 10
vm.dirty_ratio = 15
vm.dirty_background_ratio = 5
EOF
    sysctl -p /etc/sysctl.d/99-wootify.conf || true
}

optimize_nginx() {
    log "Tuning Nginx configuration..."
    local worker_connections keepalive_timeout

    case "$STACK_PROFILE" in
        large)
            worker_connections=4096
            keepalive_timeout=30
            ;;
        medium)
            worker_connections=2048
            keepalive_timeout=20
            ;;
        *)
            worker_connections=1024
            keepalive_timeout=15
            ;;
    esac

    cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.bak-wootify 2>/dev/null || true

    sed -i -E 's/^[[:space:]]*worker_processes .*/worker_processes auto;/' /etc/nginx/nginx.conf
    if grep -Eq '^[[:space:]]*worker_rlimit_nofile' /etc/nginx/nginx.conf; then
        sed -i -E 's/^[[:space:]]*worker_rlimit_nofile .*/worker_rlimit_nofile 65535;/' /etc/nginx/nginx.conf
    else
        sed -i '/^worker_processes/a worker_rlimit_nofile 65535;' /etc/nginx/nginx.conf
    fi

    sed -i -E "s/^[[:space:]]*worker_connections .*/        worker_connections ${worker_connections};/" /etc/nginx/nginx.conf
    sed -i -E 's/^[[:space:]]*#?[[:space:]]*multi_accept .*/        multi_accept on;/' /etc/nginx/nginx.conf
    sed -i -E 's/^[[:space:]]*#?[[:space:]]*tcp_nopush .*/    tcp_nopush on;/' /etc/nginx/nginx.conf
    sed -i -E 's/^[[:space:]]*#?[[:space:]]*tcp_nodelay .*/    tcp_nodelay on;/' /etc/nginx/nginx.conf

    if grep -Eq '^[[:space:]]*keepalive_timeout ' /etc/nginx/nginx.conf; then
        sed -i -E "s/^[[:space:]]*keepalive_timeout .*/    keepalive_timeout ${keepalive_timeout};/" /etc/nginx/nginx.conf
    else
        sed -i "/http {/a \    keepalive_timeout ${keepalive_timeout};" /etc/nginx/nginx.conf
    fi

    if grep -Eq '^[[:space:]]*client_max_body_size ' /etc/nginx/nginx.conf; then
        sed -i -E 's/^[[:space:]]*client_max_body_size .*/    client_max_body_size 256M;/' /etc/nginx/nginx.conf
    else
        sed -i '/http {/a \    client_max_body_size 256M;' /etc/nginx/nginx.conf
    fi

    mkdir -p /etc/nginx/conf.d
    # Create FastCGI cache directory with correct ownership
    mkdir -p /var/cache/nginx/fastcgi
    chown nginx:nginx /var/cache/nginx/fastcgi 2>/dev/null || chown www-data:www-data /var/cache/nginx/fastcgi 2>/dev/null || true
    chmod 750 /var/cache/nginx/fastcgi

    cat > /etc/nginx/conf.d/99-wootify-performance.conf <<EOF
server_tokens off;

gzip on;
gzip_vary on;
gzip_proxied any;
gzip_comp_level 5;
gzip_min_length 1024;
gzip_types
    text/plain
    text/css
    text/xml
    text/javascript
    application/javascript
    application/json
    application/xml
    application/rss+xml
    image/svg+xml;

open_file_cache max=10000 inactive=30s;
open_file_cache_valid 60s;
open_file_cache_min_uses 2;
open_file_cache_errors on;

# FastCGI response cache (anonymous page cache for all sites)
fastcgi_cache_path /var/cache/nginx/fastcgi levels=1:2
    keys_zone=WOOTIFY:64m inactive=60m max_size=512m use_temp_path=off;
fastcgi_cache_key "\$scheme\$request_method\$host\$request_uri";
fastcgi_cache_use_stale error timeout updating invalid_header http_500 http_503;
fastcgi_cache_lock on;
fastcgi_ignore_headers Cache-Control Expires Set-Cookie;
EOF
    chown root:root /etc/nginx/conf.d/99-wootify-performance.conf 2>/dev/null || true
    chmod 644 /etc/nginx/conf.d/99-wootify-performance.conf 2>/dev/null || true
    restore_nginx_path_context /etc/nginx/conf.d/99-wootify-performance.conf
    normalize_web_stack_selinux_contexts

    safe_nginx_restart
}

resolve_php_fpm_endpoint() {
    local pool_conf listen_value

    if [ "$IS_DEBIAN" = true ]; then
        pool_conf="/etc/php/$PHP_VERSION/fpm/pool.d/www.conf"
    else
        pool_conf="/etc/php-fpm.d/www.conf"
    fi

    if [ -f "$pool_conf" ]; then
        listen_value="$(awk -F '=' '/^[[:space:]]*listen[[:space:]]*=/{gsub(/[[:space:]]/, "", $2); print $2; exit}' "$pool_conf")"
        if [ -n "$listen_value" ]; then
            if [[ "$listen_value" = /* ]]; then
                echo "unix:${listen_value}"
            else
                echo "$listen_value"
            fi
            return 0
        fi
    fi

    if [ -S "/run/php/php${PHP_VERSION}-fpm.sock" ]; then
        echo "unix:/run/php/php${PHP_VERSION}-fpm.sock"
        return 0
    fi

    if [ -S "/var/run/php/php${PHP_VERSION}-fpm.sock" ]; then
        echo "unix:/var/run/php/php${PHP_VERSION}-fpm.sock"
        return 0
    fi

    if [ -S "/run/php-fpm/www.sock" ]; then
        echo "unix:/run/php-fpm/www.sock"
        return 0
    fi

    if [ -S "/var/run/php-fpm/www.sock" ]; then
        echo "unix:/var/run/php-fpm/www.sock"
        return 0
    fi

    echo "127.0.0.1:9000"
}

patch_default_nginx_php_location() {
    local conf_file="$1"
    local fpm_endpoint="$2"
    local doc_root="$3"
    local php_block tmp_file

    [ -f "$conf_file" ] || return 0

    cp "$conf_file" "${conf_file}.bak-wootify" 2>/dev/null || true

    php_block="$(cat <<EOF
    location ~ [.]php$ {
        root           ${doc_root};
        fastcgi_pass   ${fpm_endpoint};
        fastcgi_index  index.php;
        fastcgi_param  SCRIPT_FILENAME  \$document_root\$fastcgi_script_name;
        include        fastcgi_params;
    }
EOF
)"

    tmp_file="$(mktemp "$(dirname "$conf_file")/.wootify-nginx.XXXXXX")"

    if grep -Eq '^[[:space:]]*location[[:space:]]+~[[:space:]]+[^[:space:]]*php\$' "$conf_file"; then
        awk -v block="$php_block" '
            BEGIN { in_php = 0; depth = 0; replaced = 0 }
            {
                if (!in_php && $0 ~ /^[[:space:]]*location[[:space:]]+~[[:space:]]+[^[:space:]]*php[$][[:space:]]*\{/) {
                    in_php = 1
                    depth = 1
                    if (!replaced) {
                        print block
                        replaced = 1
                    }
                    next
                }

                if (in_php) {
                    line = $0
                    open_count = gsub(/\{/, "{", line)
                    close_count = gsub(/\}/, "}", line)
                    depth += open_count - close_count
                    if (depth <= 0) {
                        in_php = 0
                    }
                    next
                }

                print
            }
        ' "$conf_file" > "$tmp_file"
        mv "$tmp_file" "$conf_file"
        chown root:root "$conf_file" 2>/dev/null || true
        chmod 644 "$conf_file" 2>/dev/null || true
        restore_nginx_path_context "$conf_file"
        return 0
    fi

    awk -v block="$php_block" '
        BEGIN { in_server = 0; depth = 0; inserted = 0 }
        {
            line = $0
            if (!in_server && line ~ /^[[:space:]]*server[[:space:]]*\{/) {
                in_server = 1
            }

            if (in_server && !inserted && depth == 1 && line ~ /^[[:space:]]*}[[:space:]]*$/) {
                print block
                inserted = 1
            }

            print

            if (in_server) {
                open_count = gsub(/\{/, "{", line)
                close_count = gsub(/\}/, "}", line)
                depth += open_count - close_count
                if (depth <= 0) {
                    in_server = 0
                }
            }
        }
    ' "$conf_file" > "$tmp_file"
    mv "$tmp_file" "$conf_file"
    chown root:root "$conf_file" 2>/dev/null || true
    chmod 644 "$conf_file" 2>/dev/null || true
    restore_nginx_path_context "$conf_file"
}

configure_nginx_php_fpm() {
    local fpm_endpoint default_conf default_site root_from_conf

    if [ "$INSTALL_NGINX" != "true" ]; then
        return 0
    fi

    if ! nginx_is_installed; then
        return 0
    fi

    fpm_endpoint="$(resolve_php_fpm_endpoint)"
    default_conf="/etc/nginx/conf.d/default.conf"
    default_site="/etc/nginx/sites-available/default"

    log "Configuring Nginx PHP-FPM integration (endpoint: ${fpm_endpoint})..."

    if [ -f "$default_conf" ]; then
        root_from_conf="$(awk '/^[[:space:]]*root[[:space:]]+[^;]+;/{gsub(";", "", $2); print $2; exit}' "$default_conf")"
        [ -n "$root_from_conf" ] || root_from_conf="/usr/share/nginx/html"
        patch_default_nginx_php_location "$default_conf" "$fpm_endpoint" "$root_from_conf"
    fi

    if [ -f "$default_site" ]; then
        root_from_conf="$(awk '/^[[:space:]]*root[[:space:]]+[^;]+;/{gsub(";", "", $2); print $2; exit}' "$default_site")"
        [ -n "$root_from_conf" ] || root_from_conf="/var/www/html"
        patch_default_nginx_php_location "$default_site" "$fpm_endpoint" "$root_from_conf"
    fi

    safe_nginx_restart
}

verify_php_through_nginx() {
    local test_root test_file response expected="WOOTIFY_PHP_OK"

    if [ "$INSTALL_NGINX" != "true" ]; then
        return 0
    fi

    if ! nginx_is_installed; then
        return 0
    fi

    test_root="/usr/share/nginx/html"
    if [ -f /etc/nginx/conf.d/default.conf ]; then
        test_root="$(awk '/^[[:space:]]*root[[:space:]]+[^;]+;/{gsub(";", "", $2); print $2; exit}' /etc/nginx/conf.d/default.conf)"
    elif [ -f /etc/nginx/sites-available/default ]; then
        test_root="$(awk '/^[[:space:]]*root[[:space:]]+[^;]+;/{gsub(";", "", $2); print $2; exit}' /etc/nginx/sites-available/default)"
    fi
    [ -n "$test_root" ] || test_root="/usr/share/nginx/html"

    mkdir -p "$test_root"
    restore_path_context_recursive "$test_root"
    test_file="${test_root}/__wootify_php_check.php"
    printf '<?php echo "%s";' "$expected" > "$test_file"
    chmod 644 "$test_file" 2>/dev/null || true
    restore_path_context_recursive "$test_file"

    response="$(curl -s --max-time 5 http://127.0.0.1/__wootify_php_check.php || true)"
    rm -f "$test_file"

    if [ "$response" != "$expected" ]; then
        log "PHP request through Nginx failed. Received: ${response}"
        echo "ERROR: NGINX_PHP_FPM_NOT_WORKING"
        return 1
    fi

    log "PHP request through Nginx validated successfully."
}

optimize_php() {
    log "Tuning PHP $PHP_VERSION configuration..."
    local php_ini php_fpm_conf php_pool_conf php_memory_limit opcache_memory max_children start_servers min_spare max_spare

    if [ "$IS_DEBIAN" = true ]; then
        php_ini="/etc/php/$PHP_VERSION/fpm/php.ini"
        php_fpm_conf="/etc/php/$PHP_VERSION/fpm/php-fpm.conf"
        php_pool_conf="/etc/php/$PHP_VERSION/fpm/pool.d/www.conf"
    elif [ "$IS_RHEL" = true ]; then
        php_ini="/etc/php.ini"
        php_fpm_conf="/etc/php-fpm.conf"
        php_pool_conf="/etc/php-fpm.d/www.conf"
    fi

    case "$STACK_PROFILE" in
        large)
            php_memory_limit="512M"
            opcache_memory="256"
            max_children=40
            start_servers=6
            min_spare=4
            max_spare=12
            ;;
        medium)
            php_memory_limit="384M"
            opcache_memory="192"
            max_children=20
            start_servers=4
            min_spare=2
            max_spare=6
            ;;
        *)
            php_memory_limit="256M"
            opcache_memory="128"
            max_children=8
            start_servers=2
            min_spare=1
            max_spare=3
            ;;
    esac

    if [ -f "$php_ini" ]; then
        cp "$php_ini" "${php_ini}.bak-wootify" 2>/dev/null || true
        replace_or_append_setting "$php_ini" "memory_limit" "memory_limit = ${php_memory_limit}"
        replace_or_append_setting "$php_ini" "upload_max_filesize" "upload_max_filesize = 256M"
        replace_or_append_setting "$php_ini" "post_max_size" "post_max_size = 256M"
        replace_or_append_setting "$php_ini" "max_execution_time" "max_execution_time = 600"
        replace_or_append_setting "$php_ini" "max_input_time" "max_input_time = 600"
        replace_or_append_setting "$php_ini" "max_input_vars" "max_input_vars = 5000"
        replace_or_append_setting "$php_ini" "realpath_cache_size" "realpath_cache_size = 4096K"
        replace_or_append_setting "$php_ini" "realpath_cache_ttl" "realpath_cache_ttl = 600"
        replace_or_append_setting "$php_ini" "cgi.fix_pathinfo" "cgi.fix_pathinfo = 0"
        replace_or_append_setting "$php_ini" "opcache.enable" "opcache.enable = 1"
        replace_or_append_setting "$php_ini" "opcache.enable_cli" "opcache.enable_cli = 1"
        replace_or_append_setting "$php_ini" "opcache.memory_consumption" "opcache.memory_consumption = ${opcache_memory}"
        replace_or_append_setting "$php_ini" "opcache.interned_strings_buffer" "opcache.interned_strings_buffer = 16"
        replace_or_append_setting "$php_ini" "opcache.max_accelerated_files" "opcache.max_accelerated_files = 40000"
        replace_or_append_setting "$php_ini" "opcache.validate_timestamps" "opcache.validate_timestamps = 1"
        replace_or_append_setting "$php_ini" "opcache.revalidate_freq" "opcache.revalidate_freq = 60"
        replace_or_append_setting "$php_ini" "opcache.save_comments" "opcache.save_comments = 1"
        # opcache.fast_shutdown was removed in PHP 7.2+ and must not be set on PHP 8.x
    fi

    if [ -f "$php_fpm_conf" ]; then
        cp "$php_fpm_conf" "${php_fpm_conf}.bak-wootify" 2>/dev/null || true
        replace_or_append_setting "$php_fpm_conf" "emergency_restart_threshold" "emergency_restart_threshold = 10"
        replace_or_append_setting "$php_fpm_conf" "emergency_restart_interval" "emergency_restart_interval = 1m"
        replace_or_append_setting "$php_fpm_conf" "process_control_timeout" "process_control_timeout = 10s"
        restore_path_context_recursive "$php_fpm_conf"
    fi

    if [ -f "$php_pool_conf" ]; then
        cp "$php_pool_conf" "${php_pool_conf}.bak-wootify" 2>/dev/null || true
        replace_or_append_setting "$php_pool_conf" "pm" "pm = dynamic"
        replace_or_append_setting "$php_pool_conf" "pm\\.max_children" "pm.max_children = ${max_children}"
        replace_or_append_setting "$php_pool_conf" "pm\\.start_servers" "pm.start_servers = ${start_servers}"
        replace_or_append_setting "$php_pool_conf" "pm\\.min_spare_servers" "pm.min_spare_servers = ${min_spare}"
        replace_or_append_setting "$php_pool_conf" "pm\\.max_spare_servers" "pm.max_spare_servers = ${max_spare}"
        replace_or_append_setting "$php_pool_conf" "pm\\.max_requests" "pm.max_requests = 500"
        replace_or_append_setting "$php_pool_conf" "request_terminate_timeout" "request_terminate_timeout = 600s"
        replace_or_append_setting "$php_pool_conf" "catch_workers_output" "catch_workers_output = yes"
        replace_or_append_setting "$php_pool_conf" "listen\.group" "listen.group = $(detect_nginx_runtime_user)"
        restore_path_context_recursive "$php_pool_conf"
    fi

    # Fix PHP session/opcache/wsdlcache directory permissions for nginx user.
    # On RHEL-based systems these dirs default to group=apache which blocks nginx.
    local nginx_user
    nginx_user="$(detect_nginx_runtime_user)"
    for _phpdir in /var/lib/php/session /var/lib/php/opcache /var/lib/php/wsdlcache; do
        if [ -d "$_phpdir" ]; then
            chown root:"$nginx_user" "$_phpdir" 2>/dev/null || true
            chmod 770 "$_phpdir" 2>/dev/null || true
            restore_path_context_recursive "$_phpdir"
        fi
    done

    normalize_web_stack_selinux_contexts

    restart_php_fpm_for_version "$PHP_VERSION"
}

optimize_mariadb() {
    local innodb_buffer_pool tmp_table_size max_connections table_open_cache thread_cache

    log "Tuning MariaDB configuration..."

    case "$STACK_PROFILE" in
        large)
            innodb_buffer_pool="2G"
            tmp_table_size="128M"
            max_connections=120
            table_open_cache=4000
            thread_cache=64
            ;;
        medium)
            innodb_buffer_pool="1G"
            tmp_table_size="64M"
            max_connections=80
            table_open_cache=2000
            thread_cache=32
            ;;
        *)
            innodb_buffer_pool="256M"
            tmp_table_size="32M"
            max_connections=40
            table_open_cache=1000
            thread_cache=16
            ;;
    esac

    if [ "$IS_DEBIAN" = true ]; then
        mkdir -p /etc/mysql/mariadb.conf.d
        cat > /etc/mysql/mariadb.conf.d/99-wootify-performance.cnf <<EOF
[mysqld]
innodb_buffer_pool_size = ${innodb_buffer_pool}
innodb_buffer_pool_instances = 1
innodb_log_file_size = 256M
innodb_flush_method = O_DIRECT
innodb_flush_log_at_trx_commit = 2
innodb_io_capacity = 200
innodb_read_io_threads = 4
innodb_write_io_threads = 4
max_connections = ${max_connections}
thread_cache_size = ${thread_cache}
table_open_cache = ${table_open_cache}
tmp_table_size = ${tmp_table_size}
max_heap_table_size = ${tmp_table_size}
query_cache_type = 0
query_cache_size = 0
skip_name_resolve = 1
EOF
    else
        mkdir -p /etc/my.cnf.d
        cat > /etc/my.cnf.d/99-wootify-performance.cnf <<EOF
[mysqld]
innodb_buffer_pool_size = ${innodb_buffer_pool}
innodb_buffer_pool_instances = 1
innodb_log_file_size = 256M
innodb_flush_method = O_DIRECT
innodb_flush_log_at_trx_commit = 2
innodb_io_capacity = 200
innodb_read_io_threads = 4
innodb_write_io_threads = 4
max_connections = ${max_connections}
thread_cache_size = ${thread_cache}
table_open_cache = ${table_open_cache}
tmp_table_size = ${tmp_table_size}
max_heap_table_size = ${tmp_table_size}
query_cache_type = 0
query_cache_size = 0
skip_name_resolve = 1
EOF
    fi

    systemctl restart mariadb
}

setup_nginx_repo() {
    log "Configuring official NGINX mainline repository..."

    if [ "$IS_DEBIAN" = true ]; then
        local repo_dist keyring_pkg

        repo_dist="ubuntu"
        keyring_pkg="ubuntu-keyring"
        if [ "$OS" = "debian" ]; then
            repo_dist="debian"
            keyring_pkg="debian-archive-keyring"
        fi

        retry apt-get install -y curl gnupg2 ca-certificates lsb-release "$keyring_pkg"
        curl -fsSL https://nginx.org/keys/nginx_signing.key | gpg --dearmor > /usr/share/keyrings/nginx-archive-keyring.gpg
        chmod 644 /usr/share/keyrings/nginx-archive-keyring.gpg

        cat > /etc/apt/sources.list.d/nginx.list <<EOF
deb [signed-by=/usr/share/keyrings/nginx-archive-keyring.gpg] https://nginx.org/packages/mainline/${repo_dist} $(lsb_release -cs) nginx
EOF

        cat > /etc/apt/preferences.d/99nginx <<EOF
Package: *
Pin: origin nginx.org
Pin: release o=nginx
Pin-Priority: 900
EOF

        retry apt-get update -y
    elif [ "$IS_RHEL" = true ]; then
        retry $PKG_MANAGER install -y yum-utils
        # nginx.org renamed the repo path from 'centos' to 'rhel' starting with
        # RHEL 8 derivatives (AlmaLinux, Rocky Linux, RHEL).
        # CentOS 7 still uses the 'centos' path.
        local major_ver nginx_os_path
        major_ver="$(echo "${VERSION_ID:-7}" | cut -d. -f1)"
        if [ "$OS" = "centos" ] && [ "${major_ver}" -le 7 ]; then
            nginx_os_path="centos"
        else
            nginx_os_path="rhel"
        fi
        cat > /etc/yum.repos.d/nginx.repo <<EOF
[nginx-stable]
name=nginx stable repo
baseurl=https://nginx.org/packages/${nginx_os_path}/\$releasever/\$basearch/
gpgcheck=1
enabled=0
gpgkey=https://nginx.org/keys/nginx_signing.key
module_hotfixes=true
priority=9

[nginx-mainline]
name=nginx mainline repo
baseurl=https://nginx.org/packages/mainline/${nginx_os_path}/\$releasever/\$basearch/
gpgcheck=1
enabled=1
gpgkey=https://nginx.org/keys/nginx_signing.key
module_hotfixes=true
priority=9
EOF
        retry $PKG_MANAGER makecache -y
    fi
}

resolve_nginx_version() {
    local version=""

    if [ "$IS_DEBIAN" = true ]; then
        version="$(apt-cache madison nginx | awk '{print $3}' | awk -v series="$NGINX_VERSION_SERIES" '$0 ~ ("^" series "\\.")' | sort -Vr | head -n1)"
    elif [ "$IS_RHEL" = true ]; then
        version="$($PKG_MANAGER --showduplicates list nginx 2>/dev/null | awk -v series="$NGINX_VERSION_SERIES" '
            $1 == "nginx.x86_64" || $1 == "nginx.aarch64" || $1 == "nginx" {
                if ($2 ~ ("^" series "\\.")) print $2
            }
        ' | sort -Vr | head -n1)"
    fi

    if [ -z "$version" ]; then
        return 1
    fi

    echo "$version"
}

install_nginx_version() {
    local nginx_version="$1"

    log "Installing NGINX ${nginx_version} from the official repository..."

    if [ "$IS_DEBIAN" = true ]; then
        retry apt-get install -y "nginx=${nginx_version}"
    elif [ "$IS_RHEL" = true ]; then
        retry $PKG_MANAGER install -y "nginx-${nginx_version}"
    fi
}

setup_mariadb_repo() {
    local repo_script="/tmp/mariadb_repo_setup"
    local repo_version="mariadb-${MARIADB_VERSION}"
    local major_ver

    log "Configuring official MariaDB repository for ${repo_version}..."
    if [ "$IS_DEBIAN" = true ]; then
        retry apt-get install -y curl ca-certificates
        retry curl -fsSL https://downloads.mariadb.com/MariaDB/mariadb_repo_setup -o "$repo_script"
        chmod +x "$repo_script"
        retry "$repo_script" --skip-check-installed --mariadb-server-version="$repo_version"
        retry apt-get update -y
        return 0
    fi

    retry $PKG_MANAGER install -y curl ca-certificates
    major_ver="$(echo "$VERSION_ID" | cut -d. -f1)"
    mkdir -p /etc/yum.repos.d
    rm -f /etc/yum.repos.d/mariadb.repo

    cat > /etc/yum.repos.d/mariadb.repo <<EOF
[mariadb-main]
name = MariaDB Server
baseurl = https://dlm.mariadb.com/repo/mariadb-server/${MARIADB_VERSION}/yum/rhel/${major_ver}/\$basearch
gpgkey = https://supplychain.mariadb.com/MariaDB-Server-GPG-KEY
gpgcheck = 1
enabled = 1
module_hotfixes = 1
EOF

    retry rpm --import https://supplychain.mariadb.com/MariaDB-Server-GPG-KEY
    retry $PKG_MANAGER makecache -y
}

# --- Main Installation ---

force_unlock_dpkg() {
    log "Checking for stuck package manager processes..."
    
    # Kill running apt/dpkg processes (requires psmisc)
    # We use lsof or fuser if available, else pkill
    killall apt apt-get dpkg > /dev/null 2>&1 || true
    
    # Remove lock files
    rm -f /var/lib/dpkg/lock
    rm -f /var/lib/dpkg/lock-frontend
    rm -f /var/cache/apt/archives/lock
    
    # Repair
    log "Repairing package manager state..."
    dpkg --configure -a || true
}

# --- Main Installation ---

progress 5
log "Initializing installation..."
ensure_swap
get_system_profile
if is_wsl; then
    log "WSL environment detected. Using Linux service flow via systemd where available."
fi

# Unlock and repair package manager
if [ "$IS_DEBIAN" = true ]; then
    force_unlock_dpkg
elif [ "$IS_RHEL" = true ]; then
    log "Checking for stuck $PKG_MANAGER processes..."
    rm -f /var/run/yum.pid
fi

progress 10
log "Updating system repositories..."
if [ "$IS_DEBIAN" = true ]; then
    retry apt-get update -y
    log "Installing base dependencies..."
    retry apt-get install -y curl wget unzip gnupg2 ca-certificates lsb-release psmisc netcat-openbsd lsof cron
    systemctl enable cron 2>/dev/null || true
    systemctl start cron 2>/dev/null || true
    remove_apache2_if_conflicting
elif [ "$IS_RHEL" = true ]; then
    log "Installing base dependencies for RHEL..."
    retry $PKG_MANAGER install -y epel-release
    retry $PKG_MANAGER install -y curl wget unzip ca-certificates nmap-ncat lsof policycoreutils policycoreutils-python-utils
fi

progress 20
NGINX_ALREADY_INSTALLED="false"
if [ "$INSTALL_NGINX" = "true" ]; then
    if nginx_is_installed; then
        NGINX_ALREADY_INSTALLED="true"
        log "Nginx is already installed. Skipping Nginx setup for this run..."
    else
        log "Installing Nginx Web Server..."
        setup_nginx_repo
        if NGINX_RESOLVED_VERSION="$(resolve_nginx_version)"; then
            install_nginx_version "$NGINX_RESOLVED_VERSION"
        else
            log "NGINX ${NGINX_VERSION_SERIES}.x is not available in the official repo for this environment. Falling back to the latest mainline package."
            retry $PKG_MANAGER install -y nginx
        fi
        systemctl enable nginx
        ensure_nginx_can_bind
        if systemctl is-active --quiet nginx 2>/dev/null; then
            log "Nginx is already running. Skipping start."
        else
            safe_nginx_start
        fi
        systemctl enable nginx
        mkdir -p /etc/systemd/system/nginx.service.d
        cat > /etc/systemd/system/nginx.service.d/override.conf <<EOF
[Service]
LimitNOFILE=65535
EOF
        systemctl daemon-reload
        optimize_nginx
    fi
else
    log "Skipping Nginx..."
fi

progress 50
PHP_ALREADY_INSTALLED="false"
if [ "$IS_DEBIAN" = true ]; then
    if php_target_version_installed && systemctl list-unit-files "php$PHP_VERSION-fpm.service" >/dev/null 2>&1; then
        PHP_ALREADY_INSTALLED="true"
        log "PHP $PHP_VERSION is already installed. Skipping PHP-FPM setup for this run..."
    else
        log "Configuring PHP repositories for Debian/Ubuntu..."
        if ! grep -q "ondrej/php" /etc/apt/sources.list.d/* 2>/dev/null; then
            retry apt-get install -y software-properties-common
            retry add-apt-repository ppa:ondrej/php -y
            retry apt-get update -y
        fi

        log "Installing PHP $PHP_VERSION and extensions..."
        retry apt-get install -y \
            php$PHP_VERSION php$PHP_VERSION-fpm php$PHP_VERSION-mysql \
            php$PHP_VERSION-common php$PHP_VERSION-cli php$PHP_VERSION-curl \
            php$PHP_VERSION-mbstring php$PHP_VERSION-xml php$PHP_VERSION-zip \
            php$PHP_VERSION-bcmath php$PHP_VERSION-intl php$PHP_VERSION-gd

        # opcache: separate package on 8.3-; may be bundled in php-common on 8.4+
        if apt-cache show "php${PHP_VERSION}-opcache" >/dev/null 2>&1; then
            retry apt-get install -y "php${PHP_VERSION}-opcache"
        else
            log "php${PHP_VERSION}-opcache not available as separate package (bundled in php${PHP_VERSION}-common)"
        fi

        # imagick: not yet packaged for all PHP versions — install if available, skip otherwise
        if apt-cache show "php${PHP_VERSION}-imagick" >/dev/null 2>&1; then
            apt-get install -y "php${PHP_VERSION}-imagick" \
                || log "Warning: php${PHP_VERSION}-imagick install failed, continuing without it"
        else
            log "php${PHP_VERSION}-imagick not available in repos, skipping"
        fi

        systemctl enable php$PHP_VERSION-fpm
        systemctl start php$PHP_VERSION-fpm
        optimize_php
    fi
elif [ "$IS_RHEL" = true ]; then
    if php_target_version_installed && systemctl list-unit-files "php-fpm.service" >/dev/null 2>&1; then
        PHP_ALREADY_INSTALLED="true"
        log "PHP $PHP_VERSION is already installed. Skipping PHP-FPM setup for this run..."
    else
        log "Configuring PHP repositories for RHEL..."
        # Install Remi repository
        MAJOR_VER=$(echo $VERSION_ID | cut -d. -f1)
        retry $PKG_MANAGER install -y https://rpms.remirepo.net/enterprise/remi-release-${MAJOR_VER}.rpm
        
        # Clean PHP $PHP_VERSION format (e.g. 8.2 -> 82)
        PHP_VER_SHORT=$(echo $PHP_VERSION | tr -d '.')
        
        log "Installing PHP $PHP_VERSION from Remi repository..."
        if [[ "$MAJOR_VER" == "9" || "$MAJOR_VER" == "8" ]]; then
            $PKG_MANAGER module reset php -y
            $PKG_MANAGER module enable php:remi-$PHP_VERSION -y
            retry $PKG_MANAGER install -y \
                php php-fpm php-mysqlnd php-common php-cli php-curl \
                php-mbstring php-xml php-zip php-bcmath php-intl \
                php-gd php-opcache cronie crontabs
            # php-imagick may be named differently across Remi/EPEL builds;
            # install separately so a missing package does not abort PHP setup.
            $PKG_MANAGER install -y php-imagick \
                || $PKG_MANAGER install -y php-pecl-imagick \
                || log "Warning: php-imagick/php-pecl-imagick not available on this system, continuing without it"
        else
            retry $PKG_MANAGER install -y \
                php$PHP_VER_SHORT-php-fpm php$PHP_VER_SHORT-php-mysqlnd \
                php$PHP_VER_SHORT-php-common php$PHP_VER_SHORT-php-cli \
                php$PHP_VER_SHORT-php-curl php$PHP_VER_SHORT-php-mbstring \
                php$PHP_VER_SHORT-php-xml php$PHP_VER_SHORT-php-zip \
                php$PHP_VER_SHORT-php-bcmath php$PHP_VER_SHORT-php-intl \
                php$PHP_VER_SHORT-php-gd php$PHP_VER_SHORT-php-imagick \
                php$PHP_VER_SHORT-php-opcache cronie crontabs
        fi
        systemctl enable crond
        systemctl start crond

        systemctl enable php-fpm
        
        # Set user/group to appropriate web user in php-fpm on RHEL
        if [ -f /etc/php-fpm.d/www.conf ]; then
            sed -i "s/user = apache/user = $WEB_USER/" /etc/php-fpm.d/www.conf
            sed -i "s/group = apache/group = $WEB_GROUP/" /etc/php-fpm.d/www.conf
            sed -i "s/;listen.owner = nobody/listen.owner = $WEB_USER/" /etc/php-fpm.d/www.conf
            sed -i "s/;listen.group = nobody/listen.group = $WEB_GROUP/" /etc/php-fpm.d/www.conf
            sed -i 's/;listen.mode = 0660/listen.mode = 0660/' /etc/php-fpm.d/www.conf
        fi

        systemctl start php-fpm
        mkdir -p /etc/systemd/system/php-fpm.service.d
        cat > /etc/systemd/system/php-fpm.service.d/override.conf <<EOF
[Service]
LimitNOFILE=65535
EOF
        systemctl daemon-reload
        optimize_php
    fi
fi

if [ "$NGINX_ALREADY_INSTALLED" = "true" ] && [ "$PHP_ALREADY_INSTALLED" = "true" ]; then
    log "Skipping Nginx/PHP integration checks because both components were already installed."
else
    configure_nginx_php_fpm
    verify_php_through_nginx
fi

progress 80
MARIADB_ALREADY_INSTALLED="false"
if [ "$INSTALL_MARIADB" = "true" ]; then
    if mariadb_is_installed && systemctl list-unit-files "mariadb.service" >/dev/null 2>&1; then
        MARIADB_ALREADY_INSTALLED="true"
        log "MariaDB is already installed. Skipping MariaDB setup for this run..."
    else
        log "Installing MariaDB ${MARIADB_VERSION} Database..."
        setup_mariadb_repo
        if [ "$IS_DEBIAN" = true ]; then
            retry apt-get install -y mariadb-server mariadb-client
        elif [ "$IS_RHEL" = true ]; then
            # MariaDB's post-install scriptlet runs `semodule -i mariadb.pp`.
            # When SELinux is disabled the semodule binary still exists but
            # fails with "Failed to resolve typeattributeset statement" because
            # the policy store is inconsistent on a disabled-SELinux system.
            # Temporarily shadow semodule with a no-op wrapper so the RPM
            # scriptlet exits 0 and dnf does not print a scary warning.
            _semodule_bypass_dir=""
            if command -v semodule >/dev/null 2>&1 \
                && ! getenforce 2>/dev/null | grep -qiE 'Enforcing|Permissive' 2>/dev/null; then
                log "SELinux is not active — bypassing semodule during MariaDB install..."
                _semodule_bypass_dir="$(mktemp -d /tmp/semodule_bypass.XXXXXX)"
                printf '#!/bin/bash\nexit 0\n' > "${_semodule_bypass_dir}/semodule"
                chmod +x "${_semodule_bypass_dir}/semodule"
                export PATH="${_semodule_bypass_dir}:${PATH}"
            fi
            retry $PKG_MANAGER install -y MariaDB-server MariaDB-client
            if [ -n "$_semodule_bypass_dir" ]; then
                export PATH="${PATH#${_semodule_bypass_dir}:}"
                rm -rf "$_semodule_bypass_dir"
            fi
        fi
        systemctl enable mariadb
        systemctl start mariadb
        optimize_mariadb
    fi
else
    log "Skipping MariaDB..."
fi

apply_rhel_selinux_booleans

progress 90
log "Optimizing system kernel parameters..."
optimize_sysctl

log "Cleaning up package cache..."
if [ "$IS_DEBIAN" = true ]; then
    apt-get autoremove -y
    apt-get clean
elif [ "$IS_RHEL" = true ]; then
    $PKG_MANAGER autoremove -y
    $PKG_MANAGER clean all
fi

progress 100
log "Installation Completed Successfully!"
