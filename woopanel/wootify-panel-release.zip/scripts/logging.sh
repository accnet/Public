#!/bin/bash

resolve_log_file() {
    local log_name="${1:-wootify.log}"
    local preferred_dir="/var/log"
    local script_dir project_dir fallback_dir tmp_dir

    script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    project_dir="$(cd "${script_dir}/.." && pwd)"
    fallback_dir="${project_dir}/storage/logs"
    tmp_dir="/tmp"

    if [ -d "${preferred_dir}" ] && [ -w "${preferred_dir}" ]; then
        echo "${preferred_dir}/${log_name}"
        return 0
    fi

    mkdir -p "${fallback_dir}" 2>/dev/null || true
    if [ -d "${fallback_dir}" ] && [ -w "${fallback_dir}" ]; then
        echo "${fallback_dir}/${log_name}"
        return 0
    fi

    echo "${tmp_dir}/${log_name}"
}
