#!/bin/bash
set -Ee

# Arguments
DOMAIN=$1
WP_USER=$2
WP_PASS=$3
WP_EMAIL=$4
PHP_VERSION=${5:-"8.2"}

# Validate input
if [ -z "$DOMAIN" ] || [ -z "$WP_USER" ] || [ -z "$WP_PASS" ] || [ -z "$WP_EMAIL" ]; then
    echo "Usage: $0 domain wp_user wp_pass wp_email [php_version]"
    exit 1
fi

# Basic Email Validation Fallback
if [[ ! "$WP_EMAIL" == *"@"* ]]; then
    WP_EMAIL="admin@$DOMAIN"
fi

WEB_ROOT="/var/www/$DOMAIN"
WP_CLI_RUNTIME_BASE="/var/cache/wootify/wp-cli"
WP_CLI_HOME=""
WP_CLI_CACHE_DIR=""
source "$(dirname "$0")/logging.sh"
LOG_FILE="$(resolve_log_file "wootify_sites.log")"

source "$(dirname "$0")/os_detect.sh"
source "$(dirname "$0")/nginx_site_template.sh"

NGINX_CONF="$NGINX_CONF_DIR/$DOMAIN.conf"
BACKUP_SUFFIX="$(date '+%Y%m%d-%H%M%S')"
BACKUP_WEB_ROOT=""
BACKUP_NGINX_CONF=""
CREATED_WEB_ROOT=false
CREATED_DB=false
CREATED_DB_USER=false
CREATED_NGINX_CONF=false
NGINX_RUNTIME_USER=""
POOL_USER=""
POOL_CONF_FILE=""
CREATED_POOL_USER=false
CREATED_POOL_CONF=false

# Default PHP Version Detection
if [ -z "$PHP_VERSION" ]; then
    PHP_VERSION=$(php -r "echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION;")
fi

log() {
    echo "[INFO] $1"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [INFO] $1" >> "$LOG_FILE"
}

fail() {
    echo "[ERROR] $1"
    log "$1"
    exit 1
}

validate_domain() {
    [[ "$DOMAIN" =~ ^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$ ]]
}

validate_wp_user() {
    [[ "$WP_USER" =~ ^[a-zA-Z0-9._-]{3,32}$ ]]
}

validate_email() {
    [[ "$WP_EMAIL" =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]
}

validate_php_version() {
    [[ "$PHP_VERSION" =~ ^[5-9]\.[0-9]+$ ]] || [[ "$PHP_VERSION" =~ ^[1-9][0-9]+\.[0-9]+$ ]]
}

apply_selinux_contexts() {
    apply_wp_selinux_contexts "$WEB_ROOT"
}

normalize_web_root_permissions() {
    log "Normalizing web root ownership and permissions..."

    chown -R "${POOL_USER:-$WEB_USER}:$WEB_GROUP" "$WEB_ROOT"
    find "$WEB_ROOT" -type d ! -perm 755 -exec chmod 755 {} +
    find "$WEB_ROOT" -type f ! -perm 644 -exec chmod 644 {} +

    if [ -f "$WEB_ROOT/wp-config.php" ]; then
        chmod 600 "$WEB_ROOT/wp-config.php"
    fi

    apply_selinux_contexts
}

prepare_wordpress_runtime_baseline() {
    log "Applying WordPress runtime baseline..."

    run_wp_cli config set WP_MEMORY_LIMIT '256M' --type=constant --path="$WEB_ROOT" --quiet
    run_wp_cli config set WP_MAX_MEMORY_LIMIT '512M' --type=constant --path="$WEB_ROOT" --quiet
    run_wp_cli config set AUTOSAVE_INTERVAL 120 --raw --type=constant --path="$WEB_ROOT" --quiet
    run_wp_cli config set WP_POST_REVISIONS 10 --raw --type=constant --path="$WEB_ROOT" --quiet
    run_wp_cli config set EMPTY_TRASH_DAYS 7 --raw --type=constant --path="$WEB_ROOT" --quiet
    run_wp_cli config set WP_CRON_LOCK_TIMEOUT 60 --raw --type=constant --path="$WEB_ROOT" --quiet
    run_wp_cli config set DISALLOW_FILE_EDIT true --raw --type=constant --path="$WEB_ROOT" --quiet
    run_wp_cli config set WP_CACHE true --raw --type=constant --path="$WEB_ROOT" --quiet
}

prepare_wp_cli_runtime() {
    local wp_user="${POOL_USER:-$WEB_USER}"
    WP_CLI_HOME="${WP_CLI_RUNTIME_BASE}/${wp_user}"
    WP_CLI_CACHE_DIR="${WP_CLI_HOME}/cache"

    install -d -m 755 -o "$wp_user" -g "$WEB_GROUP" "$WP_CLI_HOME"
    install -d -m 755 -o "$wp_user" -g "$WEB_GROUP" "$WP_CLI_CACHE_DIR"
}

run_wp_cli() {
    local wp_user="${POOL_USER:-$WEB_USER}"
    sudo -H -u "$wp_user" env \
        HOME="$WP_CLI_HOME" \
        WP_CLI_CACHE_DIR="$WP_CLI_CACHE_DIR" \
        /usr/local/bin/wp --no-color "$@"
}

verify_downloaded_wordpress_core() {
    local wp_version wp_locale

    wp_version="$(run_wp_cli core version --path="$WEB_ROOT" 2>/dev/null | tr -d '\r' | head -n 1)"
    if [ -z "$wp_version" ]; then
        fail "Could not determine downloaded WordPress core version."
    fi

    wp_locale="$(run_wp_cli config get WPLANG --type=constant --path="$WEB_ROOT" 2>/dev/null | tr -d '\r' | head -n 1 || true)"
    if [ -z "$wp_locale" ] || [ "$wp_locale" = "false" ] || [ "$wp_locale" = "null" ]; then
        wp_locale="en_US"
    fi

    log "Verifying WordPress core checksums for version ${wp_version} (${wp_locale})..."
    if ! run_wp_cli core verify-checksums --path="$WEB_ROOT" --version="$wp_version" --locale="$wp_locale" --quiet; then
        if repair_wordpress_core_from_cached_archive "$wp_version" "$wp_locale"; then
            log "Retrying WordPress core checksum verification after cached archive repair..."
            if run_wp_cli core verify-checksums --path="$WEB_ROOT" --version="$wp_version" --locale="$wp_locale" --quiet; then
                return 0
            fi
        fi
        fail "Downloaded WordPress core failed checksum verification."
    fi
}

repair_wordpress_core_from_cached_archive() {
    local wp_version="$1"
    local wp_locale="$2"
    local archive=""
    local tmpdir=""

    archive="${WP_CLI_CACHE_DIR}/core/wordpress-${wp_version}-${wp_locale}.tar.gz"
    if [ ! -f "$archive" ]; then
        log "No cached WordPress archive available for repair: ${archive}"
        return 1
    fi

    if ! command -v tar >/dev/null 2>&1; then
        log "tar is not available, cannot repair downloaded WordPress core."
        return 1
    fi

    tmpdir="$(mktemp -d)"
    log "Repairing WordPress core from cached archive ${archive}..."

    if ! tar -xzf "$archive" -C "$tmpdir"; then
        rm -rf "$tmpdir"
        log "Failed to extract cached WordPress archive."
        return 1
    fi

    if [ ! -d "${tmpdir}/wordpress" ]; then
        rm -rf "$tmpdir"
        log "Cached WordPress archive does not contain the expected wordpress/ directory."
        return 1
    fi

    find "$WEB_ROOT" -mindepth 1 -maxdepth 1 ! -name 'wp-content' -exec rm -rf {} +
    cp -a "${tmpdir}/wordpress/." "$WEB_ROOT/"
    rm -rf "$tmpdir"

    # Ownership must match the pool user so WP-CLI (which runs as the
    # pool user) can continue writing to the web root after the repair.
    chown -R "${POOL_USER:-$WEB_USER}:${WEB_GROUP}" "$WEB_ROOT"
    return 0
}

replace_or_append_setting() {
    local file="$1"
    local key_regex="$2"
    local new_line="$3"

    if grep -Eq "^[;[:space:]]*${key_regex}[[:space:]]*=" "$file" 2>/dev/null; then
        sed -i -E "s|^[;[:space:]]*${key_regex}[[:space:]]*=.*|${new_line}|" "$file"
    else
        printf '%s\n' "$new_line" >> "$file"
    fi
}

detect_nginx_runtime_user() {
    local configured_user=""

    if [ -f /etc/nginx/nginx.conf ]; then
        configured_user=$(awk '/^[[:space:]]*user[[:space:]]+/ {gsub(";", "", $2); print $2; exit}' /etc/nginx/nginx.conf)
    fi

    if [ -n "$configured_user" ]; then
        NGINX_RUNTIME_USER="$configured_user"
    elif id nginx >/dev/null 2>&1; then
        NGINX_RUNTIME_USER="nginx"
    else
        NGINX_RUNTIME_USER="$WEB_USER"
    fi
}

# ---------------------------------------------------------------------------
# Per-site PHP-FPM pool
# ---------------------------------------------------------------------------

# Pool usernames are resolved by the shared helper in os_detect.sh.
# Pool conf directory — OS-specific
resolve_per_site_pool_dir() {
    if [ "$IS_DEBIAN" = true ]; then
        printf '/etc/php/%s/fpm/pool.d' "$PHP_VERSION"
    else
        printf '/etc/php-fpm.d'
    fi
}

# Socket run directory — OS-specific
resolve_per_site_socket_dir() {
    if [ "$IS_DEBIAN" = true ]; then
        printf '/run/php'
    else
        printf '/run/php-fpm'
    fi
}

# Reload PHP-FPM gracefully (no traffic drop)
reload_php_fpm_for_pool() {
    local svc=""
    svc="$(resolve_php_fpm_service_name "$PHP_VERSION" 2>/dev/null || true)"
    [ -z "$svc" ] && svc="php-fpm"
    if systemctl is-active --quiet "$svc" 2>/dev/null; then
        systemctl reload "$svc"
    else
        systemctl restart "$svc"
    fi
}

create_per_site_pool_user() {
    POOL_USER="$(resolve_pool_user_from_config "$DOMAIN" || true)"
    [ -n "$POOL_USER" ] || POOL_USER="$(resolve_pool_username "$DOMAIN")"
    pool_user_is_unshared "$DOMAIN" "$POOL_USER" || fail "Pool user is shared by another site"


    if id "$POOL_USER" >/dev/null 2>&1; then
        [ "$(getent passwd "$POOL_USER" | cut -d: -f5)" = "WooPanel PHP pool ${DOMAIN}" ] || fail "Refusing to reuse an unrelated system user"
        log "Pool user $POOL_USER already exists — reusing."
        return 0
    fi

    log "Creating system pool user: $POOL_USER"
    # --gid sets primary group; fall back to plain useradd if gid flag is unsupported
    useradd \
        --system \
        --no-create-home \
        --shell /sbin/nologin \
        --comment "WooPanel PHP pool ${DOMAIN}" \
        --gid "$WEB_GROUP" \
        "$POOL_USER" 2>/dev/null || \
    useradd \
        --system \
        --no-create-home \
        --shell /sbin/nologin \
        --comment "WooPanel PHP pool ${DOMAIN}" \
        "$POOL_USER"

    # Ensure membership in web group so Nginx socket access works
    usermod -aG "$WEB_GROUP" "$POOL_USER" 2>/dev/null || true
    CREATED_POOL_USER=true
    log "Pool user created: $POOL_USER"
}

create_per_site_fpm_pool() {
    local pool_dir socket_dir socket_path pool_conf_path

    detect_nginx_runtime_user
    pool_dir="$(resolve_per_site_pool_dir)"
    socket_dir="$(resolve_per_site_socket_dir)"
    socket_path="${socket_dir}/${DOMAIN}.sock"
    pool_conf_path="${pool_dir}/${DOMAIN}.conf"

    POOL_CONF_FILE="$pool_conf_path"
    mkdir -p "$socket_dir"

    if [ -f "$pool_conf_path" ]; then
        log "PHP-FPM pool conf already exists: $pool_conf_path"
        PHP_FPM_SOCK="$socket_path"
        return 0
    fi

    log "Creating PHP-FPM pool conf: $pool_conf_path"
    # listen.owner/group must match the Nginx runtime user so it can reach the socket
    CREATED_POOL_CONF=true
    cat > "$pool_conf_path" <<POOLEOF
; WooPanel per-site pool for ${DOMAIN}
[${DOMAIN}]
user = ${POOL_USER}
group = ${WEB_GROUP}
listen = ${socket_path}
listen.owner = ${NGINX_RUNTIME_USER}
listen.group = ${NGINX_RUNTIME_USER}
listen.mode = 0660
pm = ondemand
pm.max_children = 10
pm.process_idle_timeout = 10s
pm.max_requests = 500
POOLEOF

    CREATED_POOL_CONF=true
    apply_php_protect_block "$pool_conf_path"
    log "Reloading PHP-FPM to activate pool for $DOMAIN..."
    reload_php_fpm_for_pool

    # Wait up to 15 s for socket to appear
    local i=0
    while [ $i -lt 15 ]; do
        [ -S "$socket_path" ] && break
        sleep 1
        i=$((i + 1))
    done

    if [ ! -S "$socket_path" ]; then
        log "Warning: per-site socket $socket_path not ready after 15s — falling back to shared pool"
        ensure_php_fpm_socket_ready
        return 0
    fi

    PHP_FPM_SOCK="$socket_path"
    log "Per-site PHP-FPM pool ready: $socket_path"
}

restart_php_fpm_service() {
    log "Restarting PHP-FPM service for PHP $PHP_VERSION..."

    if [ "$IS_DEBIAN" = true ]; then
        systemctl restart "php$PHP_VERSION-fpm"
    else
        if systemctl list-unit-files "php${PHP_VERSION//./}-php-fpm.service" >/dev/null 2>&1; then
            systemctl restart "php${PHP_VERSION//./}-php-fpm"
        else
            systemctl restart php-fpm
        fi
    fi
}

restart_php_fpm_socket_unit() {
    local socket_unit="$1"

    if [ -z "$socket_unit" ]; then
        return 1
    fi

    log "Restarting PHP-FPM socket unit $socket_unit"
    systemctl daemon-reload
    systemctl restart "$socket_unit"

    if [ "$IS_DEBIAN" = true ]; then
        systemctl restart "php$PHP_VERSION-fpm"
    else
        if systemctl list-unit-files "php${PHP_VERSION//./}-php-fpm.service" >/dev/null 2>&1; then
            systemctl restart "php${PHP_VERSION//./}-php-fpm"
        else
            systemctl restart php-fpm
        fi
    fi
}

resolve_php_fpm_pool_conf() {
    local version_nodot="${PHP_VERSION//./}"
    local candidates=()
    local candidate

    if [ "$IS_DEBIAN" = true ]; then
        candidates=(
            "/etc/php/${PHP_VERSION}/fpm/pool.d/www.conf"
        )
    else
        candidates=(
            "/etc/php-fpm.d/www.conf"
            "/etc/opt/remi/php${version_nodot}/php-fpm.d/www.conf"
        )
    fi

    for candidate in "${candidates[@]}"; do
        if [ -f "$candidate" ]; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done

    return 1
}

resolve_php_fpm_socket_unit() {
    local version_nodot="${PHP_VERSION//./}"
    local candidates=()
    local candidate

    if [ "$IS_DEBIAN" = true ]; then
        candidates=(
            "php${PHP_VERSION}-fpm.socket"
            "php-fpm.socket"
        )
    else
        candidates=(
            "php${version_nodot}-php-fpm.socket"
            "php-fpm.socket"
        )
    fi

    for candidate in "${candidates[@]}"; do
        if systemctl list-unit-files "$candidate" --no-legend 2>/dev/null | awk 'NF { found=1 } END { exit(found ? 0 : 1) }'; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done

    return 1
}

resolve_php_fpm_socket() {
    local candidates=()
    local version_nodot="${PHP_VERSION//./}"
    local candidate

    if [ "$IS_DEBIAN" = true ]; then
        candidates=(
            "/run/php/php${PHP_VERSION}-fpm.sock"
            "/run/php/php-fpm.sock"
        )
    else
        candidates=(
            "/run/php-fpm/php${version_nodot}-php-fpm.sock"
            "/run/php-fpm/www.sock"
            "/run/php/php${PHP_VERSION}-fpm.sock"
        )
    fi

    for candidate in "${candidates[@]}"; do
        if [ -S "$candidate" ]; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done

    printf '%s\n' "${candidates[0]}"
    return 1
}

nginx_user_can_access_socket() {
    local socket_path="$1"
    local socket_owner socket_group socket_mode owner_perms group_perms other_perms user_groups

    socket_owner=$(stat -c '%U' "$socket_path")
    socket_group=$(stat -c '%G' "$socket_path")
    socket_mode=$(stat -c '%a' "$socket_path")
    owner_perms=${socket_mode: -3:1}
    group_perms=${socket_mode: -2:1}
    other_perms=${socket_mode: -1:1}

    if [ "$NGINX_RUNTIME_USER" = "$socket_owner" ] && [ "$owner_perms" -ge 6 ]; then
        return 0
    fi

    user_groups=$(id -nG "$NGINX_RUNTIME_USER" 2>/dev/null || true)
    if printf '%s\n' "$user_groups" | tr ' ' '\n' | grep -Fxq "$socket_group" && [ "$group_perms" -ge 6 ]; then
        return 0
    fi

    if [ "$other_perms" -ge 6 ]; then
        return 0
    fi

    return 1
}

repair_php_fpm_socket_access() {
    local pool_conf=""
    local socket_unit=""
    local override_dir=""
    local override_conf=""

    pool_conf="$(resolve_php_fpm_pool_conf || true)"
    if [ -n "$pool_conf" ] && [ -f "$pool_conf" ]; then
        log "Attempting to repair PHP-FPM socket access via $pool_conf"
        cp "$pool_conf" "${pool_conf}.bak-wootify" 2>/dev/null || true
        replace_or_append_setting "$pool_conf" "listen\.owner" "listen.owner = ${NGINX_RUNTIME_USER}"
        replace_or_append_setting "$pool_conf" "listen\.group" "listen.group = ${NGINX_RUNTIME_USER}"
        replace_or_append_setting "$pool_conf" "listen\.mode" "listen.mode = 0660"
        restart_php_fpm_service
        sleep 2
        if [ -S "$PHP_FPM_SOCK" ] && nginx_user_can_access_socket "$PHP_FPM_SOCK"; then
            return 0
        fi
    fi

    socket_unit="$(resolve_php_fpm_socket_unit || true)"
    if [ -n "$socket_unit" ]; then
        log "Attempting to repair PHP-FPM socket access via systemd socket unit $socket_unit"
        override_dir="/etc/systemd/system/${socket_unit}.d"
        override_conf="${override_dir}/wootify-socket-permissions.conf"
        mkdir -p "$override_dir"
        cat > "$override_conf" <<EOF
[Socket]
SocketUser=root
SocketGroup=${NGINX_RUNTIME_USER}
SocketMode=0660
EOF
        restart_php_fpm_socket_unit "$socket_unit"
        sleep 2
        if [ -S "$PHP_FPM_SOCK" ] && nginx_user_can_access_socket "$PHP_FPM_SOCK"; then
            return 0
        fi
    fi

    if [ -S "$PHP_FPM_SOCK" ]; then
        log "Pool config not found. Applying temporary socket permissions to $PHP_FPM_SOCK"
        chown root:"$NGINX_RUNTIME_USER" "$PHP_FPM_SOCK" 2>/dev/null || true
        chmod 660 "$PHP_FPM_SOCK" 2>/dev/null || true
        if command -v setfacl >/dev/null 2>&1; then
            setfacl -m "u:${NGINX_RUNTIME_USER}:rw" "$PHP_FPM_SOCK" 2>/dev/null || true
        fi
        return 0
    fi

    return 1
}

ensure_php_fpm_socket_ready() {
    local selected_socket=""
    local socket_owner socket_group socket_mode

    detect_nginx_runtime_user
    log "Detected Nginx runtime user: $NGINX_RUNTIME_USER"

    selected_socket="$(resolve_php_fpm_socket || true)"
    PHP_FPM_SOCK="$selected_socket"

    if [ ! -S "$PHP_FPM_SOCK" ]; then
        log "PHP-FPM socket not found at expected path $PHP_FPM_SOCK"
        restart_php_fpm_service
        sleep 2
        selected_socket="$(resolve_php_fpm_socket || true)"
        PHP_FPM_SOCK="$selected_socket"
    fi

    if [ ! -S "$PHP_FPM_SOCK" ]; then
        fail "PHP-FPM socket for PHP $PHP_VERSION is missing after restart: $PHP_FPM_SOCK"
    fi

    socket_owner=$(stat -c '%U' "$PHP_FPM_SOCK")
    socket_group=$(stat -c '%G' "$PHP_FPM_SOCK")
    socket_mode=$(stat -c '%a' "$PHP_FPM_SOCK")
    log "Selected PHP-FPM socket: $PHP_FPM_SOCK (owner=$socket_owner group=$socket_group mode=$socket_mode)"

    if ! nginx_user_can_access_socket "$PHP_FPM_SOCK"; then
        log "Nginx user $NGINX_RUNTIME_USER cannot access PHP-FPM socket $PHP_FPM_SOCK (owner=$socket_owner group=$socket_group mode=$socket_mode). Attempting repair..."
        repair_php_fpm_socket_access || true
        selected_socket="$(resolve_php_fpm_socket || true)"
        PHP_FPM_SOCK="$selected_socket"

        if [ ! -S "$PHP_FPM_SOCK" ]; then
            fail "PHP-FPM socket for PHP $PHP_VERSION is missing after repair attempt: $PHP_FPM_SOCK"
        fi

        socket_owner=$(stat -c '%U' "$PHP_FPM_SOCK")
        socket_group=$(stat -c '%G' "$PHP_FPM_SOCK")
        socket_mode=$(stat -c '%a' "$PHP_FPM_SOCK")
        log "Rechecked PHP-FPM socket: $PHP_FPM_SOCK (owner=$socket_owner group=$socket_group mode=$socket_mode)"

        if ! nginx_user_can_access_socket "$PHP_FPM_SOCK"; then
            fail "Nginx user $NGINX_RUNTIME_USER cannot access PHP-FPM socket $PHP_FPM_SOCK (owner=$socket_owner group=$socket_group mode=$socket_mode)"
        fi
    fi
}

rollback_on_error() {
    local line_no="$1"
    trap - EXIT ERR
    set +e

    echo "[ERROR] Site creation failed on line $line_no"
    log "Site creation failed on line $line_no. Starting rollback..."

    if [ "$CREATED_NGINX_CONF" = true ] && [ -f "$NGINX_CONF" ]; then
        rm -f "$NGINX_CONF" || true
        log "Rollback: removed Nginx config $NGINX_CONF"
    fi

    if [ "$CREATED_DB_USER" = true ] && [ -n "$DB_USER" ]; then
        mariadb -e "DROP USER IF EXISTS '${DB_USER}'@'localhost';" >/dev/null 2>&1 || true
        log "Rollback: removed database user $DB_USER"
    fi

    if [ "$CREATED_DB" = true ] && [ -n "$DB_NAME" ]; then
        mariadb -e "DROP DATABASE IF EXISTS \`${DB_NAME}\`;" >/dev/null 2>&1 || true
        log "Rollback: removed database $DB_NAME"
    fi

    if [ "$CREATED_WEB_ROOT" = true ] && [ -d "$WEB_ROOT" ]; then
        rm -rf "$WEB_ROOT" || true
        log "Rollback: removed web root $WEB_ROOT"
    fi

    if [ -n "$BACKUP_NGINX_CONF" ] && [ -f "$BACKUP_NGINX_CONF" ] && [ ! -f "$NGINX_CONF" ]; then
        mv "$BACKUP_NGINX_CONF" "$NGINX_CONF" || true
        log "Rollback: restored Nginx config from backup"
    fi

    if [ -n "$BACKUP_WEB_ROOT" ] && [ -d "$BACKUP_WEB_ROOT" ] && [ ! -d "$WEB_ROOT" ]; then
        mv "$BACKUP_WEB_ROOT" "$WEB_ROOT" || true
        log "Rollback: restored original web root from backup"
    fi

    if [ "$CREATED_POOL_CONF" = true ] && [ -n "$POOL_CONF_FILE" ] && [ -f "$POOL_CONF_FILE" ]; then
        rm -f "$POOL_CONF_FILE" || true
        reload_php_fpm_for_pool 2>/dev/null || true
        log "Rollback: removed PHP-FPM pool conf $POOL_CONF_FILE"
    fi

    if [ "$CREATED_POOL_USER" = true ] && [ -n "$POOL_USER" ]; then
        userdel "$POOL_USER" 2>/dev/null || true
        log "Rollback: removed pool user $POOL_USER"
    fi

    exit 1
}

MAIN_PID=$BASHPID
trap 'status=$?; if [ "$BASHPID" = "$MAIN_PID" ] && [ "$status" -ne 0 ]; then rollback_on_error "$LINENO"; fi' EXIT
trap 'echo "[ERROR] Site creation failed on line $LINENO" >&2' ERR
trap 'exit 1' INT TERM

log "Starting creation for $DOMAIN (PHP $PHP_VERSION)..."
log "Validating input..."

if [ "$(id -u)" -ne 0 ]; then
    fail "This script must be run as root"
fi

if ! validate_domain; then
    fail "Invalid domain format: $DOMAIN"
fi

if ! validate_wp_user; then
    fail "Invalid admin username. Allowed: 3-32 chars [a-zA-Z0-9._-]"
fi

if ! validate_email; then
    fail "Invalid admin email format: $WP_EMAIL"
fi

if ! validate_php_version; then
    fail "Unsupported PHP version: $PHP_VERSION"
fi

if printf '%s' "$WP_PASS" | grep -q '[[:cntrl:]]'; then
    fail "Admin password contains unsupported control characters"
fi

# 0. Generate Random Database Credentials
DB_SUFFIX=$(tr -dc a-z0-9 </dev/urandom | head -c 6)
DB_NAME="wp_${DB_SUFFIX}"
DB_USER="user_${DB_SUFFIX}"
DB_PASS=$(openssl rand -base64 12)
DB_CHARSET="utf8mb4"
DB_COLLATION="utf8mb4_unicode_ci"

# 1. Install WP-CLI if missing
if [ ! -x /usr/local/bin/wp ] && ! command -v wp &>/dev/null; then
    log "Installing WP-CLI..."
    curl -fsSL --retry 3 --retry-delay 2 \
        -o /tmp/wp-cli.phar \
        https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar \
        || curl -fsSL --retry 3 --retry-delay 2 \
        -o /tmp/wp-cli.phar \
        https://github.com/wp-cli/wp-cli/releases/latest/download/wp-cli.phar
    chmod +x /tmp/wp-cli.phar
    mv /tmp/wp-cli.phar /usr/local/bin/wp
fi

# Create per-site pool user BEFORE preparing WP-CLI runtime so that
# WP-CLI runs under the per-site user, not the shared web user.
# This ensures WordPress files are owned by the pool user from the start.
create_per_site_pool_user

prepare_wp_cli_runtime

# 2. Create Web Directory
if [ -d "$WEB_ROOT" ]; then
    BACKUP_WEB_ROOT="${WEB_ROOT}.bak-${BACKUP_SUFFIX}"
    log "Web root already exists. Backing up to $BACKUP_WEB_ROOT..."
    mv "$WEB_ROOT" "$BACKUP_WEB_ROOT"
fi
CREATED_WEB_ROOT=true
install -d -m 755 -o "${POOL_USER:-$WEB_USER}" -g "$WEB_GROUP" "$WEB_ROOT"

# Change ownership to the per-site pool user so that WP-CLI (which runs as
# the pool user) can write to the web root for WordPress installation.
# Without this, the pool user cannot write to a web root owned by nginx:nginx.
chown "${POOL_USER}:${WEB_GROUP}" "$WEB_ROOT" 2>/dev/null || true

# 3. Create Database
log "Creating Database $DB_NAME..."
# Plain CREATE refuses a collision; only mark resources after their creation.
mariadb -e "CREATE DATABASE \`${DB_NAME}\` CHARACTER SET ${DB_CHARSET} COLLATE ${DB_COLLATION};"
CREATED_DB=true
mariadb -e "CREATE USER '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';"
CREATED_DB_USER=true
mariadb -e "GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost'; FLUSH PRIVILEGES;"

# 4. Download and Configure WordPress via WP-CLI
log "Installing WordPress Core..."

run_wp_cli core download --path="$WEB_ROOT" --quiet
verify_downloaded_wordpress_core

run_wp_cli config create \
    --dbname="$DB_NAME" \
    --dbuser="$DB_USER" \
    --dbpass="$DB_PASS" \
    --dbcharset="$DB_CHARSET" \
    --dbcollate="$DB_COLLATION" \
    --path="$WEB_ROOT" \
    --quiet

log "Installing WordPress Site..."
run_wp_cli core install --url="$DOMAIN" \
    --title="New WordPress Site" \
    --admin_user="$WP_USER" \
    --admin_password="$WP_PASS" \
    --admin_email="$WP_EMAIL" \
    --path="$WEB_ROOT" --quiet

prepare_wordpress_runtime_baseline

install -d -m 755 -o "$WEB_USER" -g "$WEB_GROUP" "$WEB_ROOT/wp-content/uploads"

# 4a. Fix file ownership so per-site pool user can write to wp-content.
# New sites use WordPress' default wp-cron.php behavior until VPS cron is
# enabled from the Cron Jobs menu.
normalize_web_root_permissions

log "Restarting PHP-FPM to flush stale OPcache before site activation..."
restart_php_fpm_service

# 5. Nginx Configuration
log "Configuring Nginx..."
if [ -f "$NGINX_CONF" ]; then
    BACKUP_NGINX_CONF="${NGINX_CONF}.bak-${BACKUP_SUFFIX}"
    log "Nginx config already exists. Backing up to $BACKUP_NGINX_CONF..."
    mv "$NGINX_CONF" "$BACKUP_NGINX_CONF"
fi

# Create per-site PHP-FPM pool (sets PHP_FPM_SOCK to the per-site socket)
create_per_site_fpm_pool

CREATED_NGINX_CONF=true
render_wp_site_nginx_conf "$DOMAIN" "$WEB_ROOT" "$PHP_FPM_SOCK" "$NGINX_CONF"
CREATED_NGINX_CONF=true


# 6. Verify and Reload Nginx
if nginx -t; then
    systemctl reload nginx
    log "Nginx reloaded successfully."
else
    log "Nginx config test failed. Please check logs."
    rm "$NGINX_CONF"
    exit 1
fi

# 7. Final Output (JSON for handler)
echo "{\"db_name\":\"$DB_NAME\", \"db_user\":\"$DB_USER\", \"db_pass\":\"$DB_PASS\"}"
if [ -n "$BACKUP_WEB_ROOT" ]; then
    log "Original web root preserved at $BACKUP_WEB_ROOT"
fi
if [ -n "$BACKUP_NGINX_CONF" ]; then
    log "Original Nginx config preserved at $BACKUP_NGINX_CONF"
fi
log "Site $DOMAIN created successfully!"
