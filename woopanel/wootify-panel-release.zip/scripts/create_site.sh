#!/bin/bash
set -e

# Arguments
DOMAIN=$1
WP_USER=$2
WP_PASS=$3
WP_EMAIL=$4
PHP_VERSION=${5:-"8.2"}

# Validate input
if [ -z "$DOMAIN" ] || [ -z "$WP_USER" ] || [ -z "$WP_PASS" ] || [ -z "$WP_EMAIL" ]; then
    echo "Usage: $0 domain wp_user wp_pass wp_email [php_version]"
    exit 1
fi

# Basic Email Validation Fallback
if [[ ! "$WP_EMAIL" == *"@"* ]]; then
    WP_EMAIL="admin@$DOMAIN"
fi

WEB_ROOT="/var/www/$DOMAIN"
WP_CLI_RUNTIME_BASE="/var/cache/wootify/wp-cli"
WP_CLI_HOME=""
WP_CLI_CACHE_DIR=""
source "$(dirname "$0")/logging.sh"
LOG_FILE="$(resolve_log_file "wootify_sites.log")"

source "$(dirname "$0")/os_detect.sh"

NGINX_CONF="$NGINX_CONF_DIR/$DOMAIN.conf"
BACKUP_SUFFIX="$(date '+%Y%m%d-%H%M%S')"
BACKUP_WEB_ROOT=""
BACKUP_NGINX_CONF=""
CREATED_WEB_ROOT=false
CREATED_DB=false
CREATED_DB_USER=false
CREATED_NGINX_CONF=false
NGINX_RUNTIME_USER=""

# Default PHP Version Detection
if [ -z "$PHP_VERSION" ]; then
    PHP_VERSION=$(php -r "echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION;")
fi

log() {
    echo "[INFO] $1"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [INFO] $1" >> $LOG_FILE
}

fail() {
    echo "[ERROR] $1"
    log "$1"
    exit 1
}

validate_domain() {
    [[ "$DOMAIN" =~ ^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$ ]]
}

validate_wp_user() {
    [[ "$WP_USER" =~ ^[a-zA-Z0-9._-]{3,32}$ ]]
}

validate_email() {
    [[ "$WP_EMAIL" =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]
}

validate_php_version() {
    [[ "$PHP_VERSION" =~ ^[5-9]\.[0-9]+$ ]] || [[ "$PHP_VERSION" =~ ^[1-9][0-9]+\.[0-9]+$ ]]
}

apply_selinux_contexts() {
    if [ "$IS_RHEL" = true ] && command -v chcon >/dev/null 2>&1; then
        chcon -R -t httpd_sys_content_t "$WEB_ROOT" || true

        if [ -d "$WEB_ROOT/wp-content" ]; then
            chcon -R -t httpd_sys_rw_content_t "$WEB_ROOT/wp-content" || true
        fi

        if [ -d "$WEB_ROOT/wp-content/uploads" ]; then
            chcon -R -t httpd_sys_rw_content_t "$WEB_ROOT/wp-content/uploads" || true
        fi
    fi
}

normalize_web_root_permissions() {
    log "Normalizing web root ownership and permissions..."

    chown -R "$WEB_USER:$WEB_GROUP" "$WEB_ROOT"
    find "$WEB_ROOT" -type d ! -perm 755 -exec chmod 755 {} +
    find "$WEB_ROOT" -type f ! -perm 644 -exec chmod 644 {} +

    if [ -f "$WEB_ROOT/wp-config.php" ]; then
        chmod 640 "$WEB_ROOT/wp-config.php"
    fi

    apply_selinux_contexts
}

prepare_wordpress_runtime_baseline() {
    log "Applying WordPress runtime baseline..."

    run_wp_cli config set WP_MEMORY_LIMIT '256M' --type=constant --path="$WEB_ROOT" --quiet
    run_wp_cli config set WP_MAX_MEMORY_LIMIT '512M' --type=constant --path="$WEB_ROOT" --quiet
    run_wp_cli config set AUTOSAVE_INTERVAL 120 --raw --type=constant --path="$WEB_ROOT" --quiet
    run_wp_cli config set WP_POST_REVISIONS 10 --raw --type=constant --path="$WEB_ROOT" --quiet
    run_wp_cli config set EMPTY_TRASH_DAYS 7 --raw --type=constant --path="$WEB_ROOT" --quiet
    run_wp_cli config set WP_CRON_LOCK_TIMEOUT 60 --raw --type=constant --path="$WEB_ROOT" --quiet
    run_wp_cli config set DISALLOW_FILE_EDIT true --raw --type=constant --path="$WEB_ROOT" --quiet
    run_wp_cli config set WP_CACHE true --raw --type=constant --path="$WEB_ROOT" --quiet
}

configure_system_wp_cron() {
    local cron_line=""

    CRON_SLUG="$(printf '%s' "$DOMAIN" | tr -c 'a-zA-Z0-9' '_')"
    CRON_SLUG="${CRON_SLUG%_}"
    [ -n "$CRON_SLUG" ] || CRON_SLUG="wp_site"
    WP_CRON_FILE="/etc/cron.d/wootify-wp-${CRON_SLUG}"

    log "Configuring system cron for WordPress..."

    run_wp_cli config set DISABLE_WP_CRON true --raw --type=constant --path="$WEB_ROOT" --quiet

    # Use wp-cli directly so the cron job works regardless of HTTP/HTTPS scheme.
    # curl -fsS without -L would silently skip wp-cron when nginx returns a 301
    # redirect for SSL-enabled sites.
    cron_line="*/5 * * * * ${WEB_USER} /usr/bin/flock -n /tmp/wootify-${CRON_SLUG}.cron.lock env HOME=${WP_CLI_RUNTIME_BASE}/${WEB_USER} WP_CLI_CACHE_DIR=${WP_CLI_RUNTIME_BASE}/${WEB_USER}/cache /usr/local/bin/wp --path=${WEB_ROOT} cron event run --due-now --quiet >/dev/null 2>&1"
    {
        echo "SHELL=/bin/bash"
        echo "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
        echo "$cron_line"
    } > "$WP_CRON_FILE"

    chmod 644 "$WP_CRON_FILE"
}

prepare_wp_cli_runtime() {
    WP_CLI_HOME="${WP_CLI_RUNTIME_BASE}/${WEB_USER}"
    WP_CLI_CACHE_DIR="${WP_CLI_HOME}/cache"

    install -d -m 755 -o "$WEB_USER" -g "$WEB_GROUP" "$WP_CLI_HOME"
    install -d -m 755 -o "$WEB_USER" -g "$WEB_GROUP" "$WP_CLI_CACHE_DIR"
}

run_wp_cli() {
    sudo -H -u "$WEB_USER" env \
        HOME="$WP_CLI_HOME" \
        WP_CLI_CACHE_DIR="$WP_CLI_CACHE_DIR" \
        /usr/local/bin/wp "$@"
}

verify_downloaded_wordpress_core() {
    local wp_version wp_locale

    wp_version="$(run_wp_cli core version --path="$WEB_ROOT" 2>/dev/null | tr -d '\r' | head -n 1)"
    if [ -z "$wp_version" ]; then
        fail "Could not determine downloaded WordPress core version."
    fi

    wp_locale="$(run_wp_cli config get WPLANG --type=constant --path="$WEB_ROOT" 2>/dev/null | tr -d '\r' | head -n 1 || true)"
    if [ -z "$wp_locale" ] || [ "$wp_locale" = "false" ] || [ "$wp_locale" = "null" ]; then
        wp_locale="en_US"
    fi

    log "Verifying WordPress core checksums for version ${wp_version} (${wp_locale})..."
    if ! run_wp_cli core verify-checksums --path="$WEB_ROOT" --version="$wp_version" --locale="$wp_locale" --quiet; then
        if repair_wordpress_core_from_cached_archive "$wp_version" "$wp_locale"; then
            log "Retrying WordPress core checksum verification after cached archive repair..."
            if run_wp_cli core verify-checksums --path="$WEB_ROOT" --version="$wp_version" --locale="$wp_locale" --quiet; then
                return 0
            fi
        fi
        fail "Downloaded WordPress core failed checksum verification."
    fi
}

repair_wordpress_core_from_cached_archive() {
    local wp_version="$1"
    local wp_locale="$2"
    local archive=""
    local tmpdir=""

    archive="${WP_CLI_CACHE_DIR}/core/wordpress-${wp_version}-${wp_locale}.tar.gz"
    if [ ! -f "$archive" ]; then
        log "No cached WordPress archive available for repair: ${archive}"
        return 1
    fi

    if ! command -v tar >/dev/null 2>&1; then
        log "tar is not available, cannot repair downloaded WordPress core."
        return 1
    fi

    tmpdir="$(mktemp -d)"
    log "Repairing WordPress core from cached archive ${archive}..."

    if ! tar -xzf "$archive" -C "$tmpdir"; then
        rm -rf "$tmpdir"
        log "Failed to extract cached WordPress archive."
        return 1
    fi

    if [ ! -d "${tmpdir}/wordpress" ]; then
        rm -rf "$tmpdir"
        log "Cached WordPress archive does not contain the expected wordpress/ directory."
        return 1
    fi

    find "$WEB_ROOT" -mindepth 1 -maxdepth 1 ! -name 'wp-content' -exec rm -rf {} +
    cp -a "${tmpdir}/wordpress/." "$WEB_ROOT/"
    rm -rf "$tmpdir"

    chown -R "$WEB_USER:$WEB_GROUP" "$WEB_ROOT"
    return 0
}

replace_or_append_setting() {
    local file="$1"
    local key_regex="$2"
    local new_line="$3"

    if grep -Eq "^[;[:space:]]*${key_regex}[[:space:]]*=" "$file" 2>/dev/null; then
        sed -i -E "s|^[;[:space:]]*${key_regex}[[:space:]]*=.*|${new_line}|" "$file"
    else
        printf '%s\n' "$new_line" >> "$file"
    fi
}

detect_nginx_runtime_user() {
    local configured_user=""

    if [ -f /etc/nginx/nginx.conf ]; then
        configured_user=$(awk '/^[[:space:]]*user[[:space:]]+/ {gsub(";", "", $2); print $2; exit}' /etc/nginx/nginx.conf)
    fi

    if [ -n "$configured_user" ]; then
        NGINX_RUNTIME_USER="$configured_user"
    elif id nginx >/dev/null 2>&1; then
        NGINX_RUNTIME_USER="nginx"
    else
        NGINX_RUNTIME_USER="$WEB_USER"
    fi
}

restart_php_fpm_service() {
    log "Restarting PHP-FPM service for PHP $PHP_VERSION..."

    if [ "$IS_DEBIAN" = true ]; then
        systemctl restart "php$PHP_VERSION-fpm"
    else
        if systemctl list-unit-files "php${PHP_VERSION//./}-php-fpm.service" >/dev/null 2>&1; then
            systemctl restart "php${PHP_VERSION//./}-php-fpm"
        else
            systemctl restart php-fpm
        fi
    fi
}

restart_php_fpm_socket_unit() {
    local socket_unit="$1"

    if [ -z "$socket_unit" ]; then
        return 1
    fi

    log "Restarting PHP-FPM socket unit $socket_unit"
    systemctl daemon-reload
    systemctl restart "$socket_unit"

    if [ "$IS_DEBIAN" = true ]; then
        systemctl restart "php$PHP_VERSION-fpm"
    else
        if systemctl list-unit-files "php${PHP_VERSION//./}-php-fpm.service" >/dev/null 2>&1; then
            systemctl restart "php${PHP_VERSION//./}-php-fpm"
        else
            systemctl restart php-fpm
        fi
    fi
}

resolve_php_fpm_pool_conf() {
    local version_nodot="${PHP_VERSION//./}"
    local candidates=()
    local candidate

    if [ "$IS_DEBIAN" = true ]; then
        candidates=(
            "/etc/php/${PHP_VERSION}/fpm/pool.d/www.conf"
        )
    else
        candidates=(
            "/etc/php-fpm.d/www.conf"
            "/etc/opt/remi/php${version_nodot}/php-fpm.d/www.conf"
        )
    fi

    for candidate in "${candidates[@]}"; do
        if [ -f "$candidate" ]; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done

    return 1
}

resolve_php_fpm_socket_unit() {
    local version_nodot="${PHP_VERSION//./}"
    local candidates=()
    local candidate

    if [ "$IS_DEBIAN" = true ]; then
        candidates=(
            "php${PHP_VERSION}-fpm.socket"
            "php-fpm.socket"
        )
    else
        candidates=(
            "php${version_nodot}-php-fpm.socket"
            "php-fpm.socket"
        )
    fi

    for candidate in "${candidates[@]}"; do
        if systemctl list-unit-files "$candidate" --no-legend 2>/dev/null | awk 'NF { found=1 } END { exit(found ? 0 : 1) }'; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done

    return 1
}

resolve_php_fpm_socket() {
    local candidates=()
    local version_nodot="${PHP_VERSION//./}"
    local candidate

    if [ "$IS_DEBIAN" = true ]; then
        candidates=(
            "/run/php/php${PHP_VERSION}-fpm.sock"
            "/run/php/php-fpm.sock"
        )
    else
        candidates=(
            "/run/php-fpm/php${version_nodot}-php-fpm.sock"
            "/run/php-fpm/www.sock"
            "/run/php/php${PHP_VERSION}-fpm.sock"
        )
    fi

    for candidate in "${candidates[@]}"; do
        if [ -S "$candidate" ]; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done

    printf '%s\n' "${candidates[0]}"
    return 1
}

nginx_user_can_access_socket() {
    local socket_path="$1"
    local socket_owner socket_group socket_mode owner_perms group_perms other_perms user_groups

    socket_owner=$(stat -c '%U' "$socket_path")
    socket_group=$(stat -c '%G' "$socket_path")
    socket_mode=$(stat -c '%a' "$socket_path")
    owner_perms=${socket_mode: -3:1}
    group_perms=${socket_mode: -2:1}
    other_perms=${socket_mode: -1:1}

    if [ "$NGINX_RUNTIME_USER" = "$socket_owner" ] && [ "$owner_perms" -ge 6 ]; then
        return 0
    fi

    user_groups=$(id -nG "$NGINX_RUNTIME_USER" 2>/dev/null || true)
    if printf '%s\n' "$user_groups" | tr ' ' '\n' | grep -Fxq "$socket_group" && [ "$group_perms" -ge 6 ]; then
        return 0
    fi

    if [ "$other_perms" -ge 6 ]; then
        return 0
    fi

    return 1
}

repair_php_fpm_socket_access() {
    local pool_conf=""
    local socket_unit=""
    local override_dir=""
    local override_conf=""

    pool_conf="$(resolve_php_fpm_pool_conf || true)"
    if [ -n "$pool_conf" ] && [ -f "$pool_conf" ]; then
        log "Attempting to repair PHP-FPM socket access via $pool_conf"
        cp "$pool_conf" "${pool_conf}.bak-wootify" 2>/dev/null || true
        replace_or_append_setting "$pool_conf" "listen\.owner" "listen.owner = ${NGINX_RUNTIME_USER}"
        replace_or_append_setting "$pool_conf" "listen\.group" "listen.group = ${NGINX_RUNTIME_USER}"
        replace_or_append_setting "$pool_conf" "listen\.mode" "listen.mode = 0660"
        restart_php_fpm_service
        sleep 2
        if [ -S "$PHP_FPM_SOCK" ] && nginx_user_can_access_socket "$PHP_FPM_SOCK"; then
            return 0
        fi
    fi

    socket_unit="$(resolve_php_fpm_socket_unit || true)"
    if [ -n "$socket_unit" ]; then
        log "Attempting to repair PHP-FPM socket access via systemd socket unit $socket_unit"
        override_dir="/etc/systemd/system/${socket_unit}.d"
        override_conf="${override_dir}/wootify-socket-permissions.conf"
        mkdir -p "$override_dir"
        cat > "$override_conf" <<EOF
[Socket]
SocketUser=root
SocketGroup=${NGINX_RUNTIME_USER}
SocketMode=0660
EOF
        restart_php_fpm_socket_unit "$socket_unit"
        sleep 2
        if [ -S "$PHP_FPM_SOCK" ] && nginx_user_can_access_socket "$PHP_FPM_SOCK"; then
            return 0
        fi
    fi

    if [ -S "$PHP_FPM_SOCK" ]; then
        log "Pool config not found. Applying temporary socket permissions to $PHP_FPM_SOCK"
        chown root:"$NGINX_RUNTIME_USER" "$PHP_FPM_SOCK" 2>/dev/null || true
        chmod 660 "$PHP_FPM_SOCK" 2>/dev/null || true
        if command -v setfacl >/dev/null 2>&1; then
            setfacl -m "u:${NGINX_RUNTIME_USER}:rw" "$PHP_FPM_SOCK" 2>/dev/null || true
        fi
        return 0
    fi

    return 1
}

ensure_php_fpm_socket_ready() {
    local selected_socket=""
    local socket_owner socket_group socket_mode

    detect_nginx_runtime_user
    log "Detected Nginx runtime user: $NGINX_RUNTIME_USER"

    selected_socket="$(resolve_php_fpm_socket || true)"
    PHP_FPM_SOCK="$selected_socket"

    if [ ! -S "$PHP_FPM_SOCK" ]; then
        log "PHP-FPM socket not found at expected path $PHP_FPM_SOCK"
        restart_php_fpm_service
        sleep 2
        selected_socket="$(resolve_php_fpm_socket || true)"
        PHP_FPM_SOCK="$selected_socket"
    fi

    if [ ! -S "$PHP_FPM_SOCK" ]; then
        fail "PHP-FPM socket for PHP $PHP_VERSION is missing after restart: $PHP_FPM_SOCK"
    fi

    socket_owner=$(stat -c '%U' "$PHP_FPM_SOCK")
    socket_group=$(stat -c '%G' "$PHP_FPM_SOCK")
    socket_mode=$(stat -c '%a' "$PHP_FPM_SOCK")
    log "Selected PHP-FPM socket: $PHP_FPM_SOCK (owner=$socket_owner group=$socket_group mode=$socket_mode)"

    if ! nginx_user_can_access_socket "$PHP_FPM_SOCK"; then
        log "Nginx user $NGINX_RUNTIME_USER cannot access PHP-FPM socket $PHP_FPM_SOCK (owner=$socket_owner group=$socket_group mode=$socket_mode). Attempting repair..."
        repair_php_fpm_socket_access || true
        selected_socket="$(resolve_php_fpm_socket || true)"
        PHP_FPM_SOCK="$selected_socket"

        if [ ! -S "$PHP_FPM_SOCK" ]; then
            fail "PHP-FPM socket for PHP $PHP_VERSION is missing after repair attempt: $PHP_FPM_SOCK"
        fi

        socket_owner=$(stat -c '%U' "$PHP_FPM_SOCK")
        socket_group=$(stat -c '%G' "$PHP_FPM_SOCK")
        socket_mode=$(stat -c '%a' "$PHP_FPM_SOCK")
        log "Rechecked PHP-FPM socket: $PHP_FPM_SOCK (owner=$socket_owner group=$socket_group mode=$socket_mode)"

        if ! nginx_user_can_access_socket "$PHP_FPM_SOCK"; then
            fail "Nginx user $NGINX_RUNTIME_USER cannot access PHP-FPM socket $PHP_FPM_SOCK (owner=$socket_owner group=$socket_group mode=$socket_mode)"
        fi
    fi
}

rollback_on_error() {
    local line_no="$1"

    echo "[ERROR] Site creation failed on line $line_no"
    log "Site creation failed on line $line_no. Starting rollback..."

    if [ "$CREATED_NGINX_CONF" = true ] && [ -f "$NGINX_CONF" ]; then
        rm -f "$NGINX_CONF" || true
        log "Rollback: removed Nginx config $NGINX_CONF"
    fi

    if [ "$CREATED_DB_USER" = true ] && [ -n "$DB_USER" ]; then
        mariadb -e "DROP USER IF EXISTS '${DB_USER}'@'localhost';" >/dev/null 2>&1 || true
        log "Rollback: removed database user $DB_USER"
    fi

    if [ "$CREATED_DB" = true ] && [ -n "$DB_NAME" ]; then
        mariadb -e "DROP DATABASE IF EXISTS \`${DB_NAME}\`;" >/dev/null 2>&1 || true
        log "Rollback: removed database $DB_NAME"
    fi

    if [ "$CREATED_WEB_ROOT" = true ] && [ -d "$WEB_ROOT" ]; then
        rm -rf "$WEB_ROOT" || true
        log "Rollback: removed web root $WEB_ROOT"
    fi

    if [ -n "$BACKUP_NGINX_CONF" ] && [ -f "$BACKUP_NGINX_CONF" ] && [ ! -f "$NGINX_CONF" ]; then
        mv "$BACKUP_NGINX_CONF" "$NGINX_CONF" || true
        log "Rollback: restored Nginx config from backup"
    fi

    if [ -n "$BACKUP_WEB_ROOT" ] && [ -d "$BACKUP_WEB_ROOT" ] && [ ! -d "$WEB_ROOT" ]; then
        mv "$BACKUP_WEB_ROOT" "$WEB_ROOT" || true
        log "Rollback: restored original web root from backup"
    fi

    exit 1
}

trap 'rollback_on_error $LINENO' ERR

log "Starting creation for $DOMAIN (PHP $PHP_VERSION)..."
log "Validating input..."

if [ "$(id -u)" -ne 0 ]; then
    fail "This script must be run as root"
fi

if ! validate_domain; then
    fail "Invalid domain format: $DOMAIN"
fi

if ! validate_wp_user; then
    fail "Invalid admin username. Allowed: 3-32 chars [a-zA-Z0-9._-]"
fi

if ! validate_email; then
    fail "Invalid admin email format: $WP_EMAIL"
fi

if ! validate_php_version; then
    fail "Unsupported PHP version: $PHP_VERSION"
fi

if printf '%s' "$WP_PASS" | grep -q '[[:cntrl:]]'; then
    fail "Admin password contains unsupported control characters"
fi

# 0. Generate Random Database Credentials
DB_SUFFIX=$(tr -dc a-z0-9 </dev/urandom | head -c 6)
DB_NAME="wp_${DB_SUFFIX}"
DB_USER="user_${DB_SUFFIX}"
DB_PASS=$(openssl rand -base64 12)
DB_CHARSET="utf8mb4"
DB_COLLATION="utf8mb4_unicode_ci"

# 1. Install WP-CLI if missing
if ! command -v wp &> /dev/null; then
    log "Installing WP-CLI..."
    curl -O https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar > /dev/null 2>&1
    chmod +x wp-cli.phar
    mv wp-cli.phar /usr/local/bin/wp
fi

prepare_wp_cli_runtime

# 2. Create Web Directory
if [ -d "$WEB_ROOT" ]; then
    BACKUP_WEB_ROOT="${WEB_ROOT}.bak-${BACKUP_SUFFIX}"
    log "Web root already exists. Backing up to $BACKUP_WEB_ROOT..."
    mv "$WEB_ROOT" "$BACKUP_WEB_ROOT"
fi
install -d -m 755 -o "$WEB_USER" -g "$WEB_GROUP" "$WEB_ROOT"
CREATED_WEB_ROOT=true

# 3. Create Database
log "Creating Database $DB_NAME..."
mariadb <<SQL
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\`
    CHARACTER SET ${DB_CHARSET}
    COLLATE ${DB_COLLATION};
CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost';
FLUSH PRIVILEGES;
SQL
CREATED_DB=true
CREATED_DB_USER=true

# 4. Download and Configure WordPress via WP-CLI
log "Installing WordPress Core..."

run_wp_cli core download --path="$WEB_ROOT" --quiet
verify_downloaded_wordpress_core

run_wp_cli config create \
    --dbname="$DB_NAME" \
    --dbuser="$DB_USER" \
    --dbpass="$DB_PASS" \
    --dbcharset="$DB_CHARSET" \
    --dbcollate="$DB_COLLATION" \
    --path="$WEB_ROOT" \
    --quiet

log "Installing WordPress Site..."
run_wp_cli core install --url="$DOMAIN" \
    --title="New WordPress Site" \
    --admin_user="$WP_USER" \
    --admin_password="$WP_PASS" \
    --admin_email="$WP_EMAIL" \
    --path="$WEB_ROOT" --quiet

prepare_wordpress_runtime_baseline

install -d -m 755 -o "$WEB_USER" -g "$WEB_GROUP" "$WEB_ROOT/wp-content/uploads"
normalize_web_root_permissions

log "Restarting PHP-FPM to flush stale OPcache before site activation..."
restart_php_fpm_service

# 5. Nginx Configuration
log "Configuring Nginx..."

if [ -f "$NGINX_CONF" ]; then
    BACKUP_NGINX_CONF="${NGINX_CONF}.bak-${BACKUP_SUFFIX}"
    log "Nginx config already exists. Backing up to $BACKUP_NGINX_CONF..."
    mv "$NGINX_CONF" "$BACKUP_NGINX_CONF"
fi

ensure_php_fpm_socket_ready

cat > "$NGINX_CONF" <<EOF
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;
    root $WEB_ROOT;
    index index.php index.html index.htm;
    client_max_body_size 256M;

    # Security headers
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;

    set \$wootify_https off;

    # Logs
    access_log /var/log/nginx/${DOMAIN}_access.log;
    error_log /var/log/nginx/${DOMAIN}_error.log;

    if (\$scheme = https) {
        set \$wootify_https on;
    }

    if (\$http_x_forwarded_proto = "https") {
        set \$wootify_https on;
    }

    location = /favicon.ico {
        access_log off;
        log_not_found off;
        expires 7d;
        add_header Cache-Control "public, max-age=604800";
        try_files \$uri =204;
    }

    location = /robots.txt {
        access_log off;
        log_not_found off;
        try_files \$uri /index.php?\$args;
    }

    location = /xmlrpc.php {
        deny all;
        access_log off;
        log_not_found off;
    }

    location = /wp-config.php {
        deny all;
        access_log off;
        log_not_found off;
    }

    # Block PHP execution inside uploads (most common WP RCE vector).
    # Catches .php, .php5, .phtml and dual-extension tricks like .php.jpg.
    location ~* /wp-content/uploads/.*\.php(\..*)? {
        deny all;
        access_log off;
        log_not_found off;
    }

    # Block direct HTTP access to wp-includes PHP files.
    # WordPress loads these via PHP include, never via direct HTTP request.
    location ~* /wp-includes/.*\.php {
        deny all;
        access_log off;
        log_not_found off;
    }

    location ~* /(?:readme|license)\.(?:html|txt)$ {
        deny all;
        access_log off;
        log_not_found off;
    }

    location ~ /\.(?!well-known) {
        deny all;
        access_log off;
        log_not_found off;
    }

    location ~* /(composer\.(json|lock)|package(-lock)?\.json|yarn\.lock|\.env) {
        deny all;
        access_log off;
        log_not_found off;
    }

    location ~* \.(?:css|js|jpg|jpeg|gif|png|svg|ico|webp|avif|woff|woff2|ttf|eot)$ {
        expires 30d;
        access_log off;
        log_not_found off;
        add_header Cache-Control "public, max-age=2592000, immutable";
        try_files \$uri =404;
    }

    location / {
        try_files \$uri \$uri/ /index.php?\$args;
    }

    location ~ \.php$ {
        try_files \$uri =404;
        fastcgi_pass unix:$PHP_FPM_SOCK;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_param HTTPS \$wootify_https;
        fastcgi_param HTTP_X_FORWARDED_PROTO \$http_x_forwarded_proto;
        fastcgi_param HTTP_CF_VISITOR \$http_cf_visitor;
        fastcgi_buffer_size 256k;
        fastcgi_buffers 16 256k;
        fastcgi_busy_buffers_size 512k;
        fastcgi_temp_file_write_size 512k;
        fastcgi_read_timeout 300;
        fastcgi_buffering off;
        include fastcgi_params;
    }

    location ~ /\.ht {
        deny all;
    }
}
EOF
CREATED_NGINX_CONF=true


# Re-check PHP-FPM socket after writing Nginx config and before reload
ensure_php_fpm_socket_ready

# Link handled by RHEL conf.d or Debian sites-enabled
# Now using conf.d for all distributions for consistency

# 6. Verify and Reload Nginx
if nginx -t; then
    systemctl reload nginx
    log "Nginx reloaded successfully."
else
    log "Nginx config test failed. Please check logs."
    rm "$NGINX_CONF"
    exit 1
fi

# 7. Final Output (JSON for handler)
echo "{\"db_name\":\"$DB_NAME\", \"db_user\":\"$DB_USER\", \"db_pass\":\"$DB_PASS\"}"
if [ -n "$BACKUP_WEB_ROOT" ]; then
    log "Original web root preserved at $BACKUP_WEB_ROOT"
fi
if [ -n "$BACKUP_NGINX_CONF" ]; then
    log "Original Nginx config preserved at $BACKUP_NGINX_CONF"
fi
log "Site $DOMAIN created successfully!"
