#!/bin/bash
# php_allowlist_audit.sh — which PHP URIs that work today would php-allowlist deny?
#
# Usage: php_allowlist_audit.sh <domain> [access log ...]
#
# Reads the site's Nginx access logs (rotated and .gz included by default) and
# prints "<count> <uri>" for every .php request that succeeded (status < 400)
# but falls outside the allowlist. Add the legitimate ones as extra paths
# before enabling php-allowlist. Scanner noise mostly got 404 already and is
# left out by the status filter.
set -euo pipefail

DOMAIN="${1:-}"
[ -n "$DOMAIN" ] || { echo "Usage: $0 <domain> [access log ...]" >&2; exit 1; }
shift

source "$(dirname "$0")/php_allowlist.sh"
PATHS_FILE="$(cd "$(dirname "$0")/.." && pwd)/storage/php-allowlist/${DOMAIN}/paths"

if [ "$#" -eq 0 ]; then
    shopt -s nullglob
    set -- "/var/log/nginx/${DOMAIN}_access.log"*
    shopt -u nullglob
fi
[ "$#" -gt 0 ] || { echo "No access logs found for ${DOMAIN}" >&2; exit 1; }

regex="$(php_allowlist_regex "$PATHS_FILE")"

for log in "$@"; do
    case "$log" in
        *.gz) zcat -- "$log" ;;
        *) cat -- "$log" ;;
    esac
done |
    # Combined format: ... "GET /uri?query HTTP/1.1" 200 ...
    awk -F'"' 'NF >= 3 { split($2, request, " "); split($3, rest, " "); if (rest[1] + 0 < 400) print request[2] }' |
    cut -d'?' -f1 |
    { grep -iP "$regex" || true; } |
    sort | uniq -c | sort -rn
