#!/bin/bash
set -e

DOMAIN=${1:-}

if [ -z "$DOMAIN" ]; then
    echo "Usage: $0 domain"
    exit 1
fi

WEB_ROOT="/var/www/$DOMAIN"
source "$(dirname "$0")/logging.sh"
source "$(dirname "$0")/permissions.sh"
LOG_FILE="$(resolve_log_file "wootify_sites.log")"

log() {
    echo "[INFO] $1"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [INFO] $1" >> $LOG_FILE
}

require_root "delete_site.sh"

log "Deleting site $DOMAIN..."

CRON_SLUG="$(printf '%s' "$DOMAIN" | tr -c 'a-zA-Z0-9' '_')"
CRON_SLUG="${CRON_SLUG%_}"
[ -n "$CRON_SLUG" ] || CRON_SLUG="wp_site"
WP_CRON_FILE="/etc/cron.d/wootify-wp-${CRON_SLUG}"

find_cert_names_by_domain() {
    certbot certificates 2>/dev/null | awk -v d="$DOMAIN" '
        /Certificate Name:/ {name=$3}
        /Domains:/ {
            for (i=2; i<=NF; i++) {
                if ($i == d || $i == "www." d) {
                    print name
                    break
                }
            }
        }
    ' | sort -u
}

source "$(dirname "$0")/os_detect.sh"

# 1. Get DB Info and Drop Database
if [ -f "$WEB_ROOT/wp-config.php" ]; then
    DB_NAME=$(grep "DB_NAME" "$WEB_ROOT/wp-config.php" | cut -d "'" -f 4)
    DB_USER=$(grep "DB_USER" "$WEB_ROOT/wp-config.php" | cut -d "'" -f 4)
    
    if [ ! -z "$DB_NAME" ]; then
        log "Dropping database $DB_NAME..."
        mariadb -e "DROP DATABASE IF EXISTS \`$DB_NAME\`;" || true
    fi
    if [ ! -z "$DB_USER" ]; then
        log "Dropping user $DB_USER..."
        mariadb -e "DROP USER IF EXISTS '$DB_USER'@'localhost';" || true
    fi
    mariadb -e "FLUSH PRIVILEGES;" || true
else
    log "wp-config.php not found. Skipping database cleanup."
fi

# 2. Remove Nginx Config
NGINX_CONF="$NGINX_CONF_DIR/$DOMAIN.conf"
# Now using conf.d for all distributions for consistency

if [ -f "$NGINX_CONF" ]; then
    log "Removing Nginx configuration at $NGINX_CONF..."
    rm -f "$NGINX_CONF"
    
    if nginx -t; then
        systemctl reload nginx
    else
        log "Nginx config error after deletion. Please check manually."
    fi
fi

# 2.1 Remove Let's Encrypt certificate/renewal data for this domain (if exists)
if command -v certbot &> /dev/null; then
    EXISTING_CERTS=$(find_cert_names_by_domain || true)
    if [ -n "$EXISTING_CERTS" ]; then
        log "Removing Let's Encrypt certificate lineage(s) for $DOMAIN..."
        while IFS= read -r CERT_NAME; do
            [ -z "$CERT_NAME" ] && continue
            certbot delete --cert-name "$CERT_NAME" --non-interactive || true
        done <<< "$EXISTING_CERTS"
    fi
fi

rm -f "/etc/letsencrypt/renewal/${DOMAIN}.conf"
rm -rf "/etc/letsencrypt/live/${DOMAIN}"
rm -rf "/etc/letsencrypt/archive/${DOMAIN}"

# 3. Remove Web Directory
if [ -d "$WEB_ROOT" ]; then
    log "Removing web directory $WEB_ROOT..."
    rm -rf "$WEB_ROOT"
fi

# Remove log files
rm -f "/var/log/nginx/${DOMAIN}_access.log"
rm -f "/var/log/nginx/${DOMAIN}_error.log"

# 4. Remove dedicated WP system cron job
if [ -f "$WP_CRON_FILE" ]; then
    log "Removing system cron file $WP_CRON_FILE..."
    rm -f "$WP_CRON_FILE"
fi

log "Site $DOMAIN deleted successfully."
