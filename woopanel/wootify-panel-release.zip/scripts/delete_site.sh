#!/bin/bash
set -e

DOMAIN=${1:-}

if [ -z "$DOMAIN" ]; then
    echo "Usage: $0 domain"
    exit 1
fi

WEB_ROOT="/var/www/$DOMAIN"
source "$(dirname "$0")/logging.sh"
source "$(dirname "$0")/permissions.sh"
LOG_FILE="$(resolve_log_file "wootify_sites.log")"

log() {
    echo "[INFO] $1"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [INFO] $1" >> $LOG_FILE
}

require_root "delete_site.sh"

log "Deleting site $DOMAIN..."

CRON_SLUG="$(printf '%s' "$DOMAIN" | tr -c 'a-zA-Z0-9' '_')"
CRON_SLUG="${CRON_SLUG%_}"
[ -n "$CRON_SLUG" ] || CRON_SLUG="wp_site"
WP_CRON_FILE="/etc/cron.d/wootify-wp-${CRON_SLUG}"

find_cert_names_by_domain() {
    certbot certificates 2>/dev/null | awk -v d="$DOMAIN" '
        /Certificate Name:/ {name=$3}
        /Domains:/ {
            for (i=2; i<=NF; i++) {
                if ($i == d || $i == "www." d) {
                    print name
                    break
                }
            }
        }
    ' | sort -u
}

source "$(dirname "$0")/os_detect.sh"

# 1. Get DB Info and Drop Database
if [ -f "$WEB_ROOT/wp-config.php" ]; then
    DB_NAME=$(grep "DB_NAME" "$WEB_ROOT/wp-config.php" | cut -d "'" -f 4)
    DB_USER=$(grep "DB_USER" "$WEB_ROOT/wp-config.php" | cut -d "'" -f 4)
    
    if [ ! -z "$DB_NAME" ]; then
        log "Dropping database $DB_NAME..."
        mariadb -e "DROP DATABASE IF EXISTS \`$DB_NAME\`;" || true
    fi
    if [ ! -z "$DB_USER" ]; then
        log "Dropping user $DB_USER..."
        mariadb -e "DROP USER IF EXISTS '$DB_USER'@'localhost';" || true
    fi
    mariadb -e "FLUSH PRIVILEGES;" || true
else
    log "wp-config.php not found. Skipping database cleanup."
fi

# 2. Remove Nginx Config
NGINX_CONF="$NGINX_CONF_DIR/$DOMAIN.conf"
# Now using conf.d for all distributions for consistency

if [ -f "$NGINX_CONF" ]; then
    log "Removing Nginx configuration at $NGINX_CONF..."
    rm -f "$NGINX_CONF"
    
    if nginx -t; then
        systemctl reload nginx
    else
        log "Nginx config error after deletion. Please check manually."
    fi
fi

# 2.1 Remove Let's Encrypt certificate/renewal data for this domain (if exists)
if command -v certbot &> /dev/null; then
    EXISTING_CERTS=$(find_cert_names_by_domain || true)
    if [ -n "$EXISTING_CERTS" ]; then
        log "Removing Let's Encrypt certificate lineage(s) for $DOMAIN..."
        while IFS= read -r CERT_NAME; do
            [ -z "$CERT_NAME" ] && continue
            certbot delete --cert-name "$CERT_NAME" --non-interactive || true
        done <<< "$EXISTING_CERTS"
    fi
fi

rm -f "/etc/letsencrypt/renewal/${DOMAIN}.conf"
rm -rf "/etc/letsencrypt/live/${DOMAIN}"
rm -rf "/etc/letsencrypt/archive/${DOMAIN}"

# 3. Remove Web Directory
if [ -d "$WEB_ROOT" ]; then
    log "Removing web directory $WEB_ROOT..."
    rm -rf "$WEB_ROOT"
fi

# Remove log files
rm -f "/var/log/nginx/${DOMAIN}_access.log"
rm -f "/var/log/nginx/${DOMAIN}_error.log"

# 4. Remove dedicated WP system cron job
if [ -f "$WP_CRON_FILE" ]; then
    log "Removing system cron file $WP_CRON_FILE..."
    rm -f "$WP_CRON_FILE"
fi

# 5. Remove PHP-FPM per-site pool
POOL_CONF_FILE=""
if [ "$IS_DEBIAN" = true ]; then
    # Detect PHP version from common pool paths
    for f in /etc/php/*/fpm/pool.d/${DOMAIN}.conf; do
        [ -f "$f" ] && POOL_CONF_FILE="$f" && break
    done
else
    for f in /etc/php-fpm.d/${DOMAIN}.conf /etc/php-fpm.d/${DOMAIN//./_}.conf; do
        [ -f "$f" ] && POOL_CONF_FILE="$f" && break
    done
fi

if [ -n "$POOL_CONF_FILE" ]; then
    log "Removing PHP-FPM pool config: $POOL_CONF_FILE..."
    rm -f "$POOL_CONF_FILE"

    # Extract the pool user before removing the file
    POOL_USER="$(grep -E '^user\s*=' "$POOL_CONF_FILE" 2>/dev/null | head -n 1 | awk -F'=' '{print $2}' | tr -d ' ')"
fi

# Remove per-site socket file
SOCKET_PATH=""
if [ "$IS_DEBIAN" = true ]; then
    SOCKET_PATH="/run/php/${DOMAIN}.sock"
else
    SOCKET_PATH="/run/php-fpm/${DOMAIN}.sock"
fi
if [ -S "$SOCKET_PATH" ]; then
    log "Removing PHP-FPM socket: $SOCKET_PATH..."
    rm -f "$SOCKET_PATH"
fi

# Remove the per-site system user (if it exists and is not a standard system user)
if [ -n "$POOL_USER" ] && [ "$POOL_USER" != "www-data" ] && [ "$POOL_USER" != "nginx" ] && [ "$POOL_USER" != "nobody" ]; then
    if id "$POOL_USER" >/dev/null 2>&1; then
        log "Removing per-site system user: $POOL_USER..."
        userdel -f "$POOL_USER" 2>/dev/null || true
    fi
fi

# Reload PHP-FPM gracefully (no traffic drop for remaining sites)
if [ -n "$POOL_CONF_FILE" ]; then
    # Detect PHP version from pool path
    PHP_VERSION=""
    if [[ "$POOL_CONF_FILE" =~ /etc/php/([0-9]+\.[0-9]+)/fpm/pool.d/ ]]; then
        PHP_VERSION="${BASH_REMATCH[1]}"
    fi
    FPM_SVC="$(resolve_php_fpm_service_name "$PHP_VERSION" 2>/dev/null || true)"
    [ -z "$FPM_SVC" ] && FPM_SVC="php-fpm"
    if systemctl is-active --quiet "$FPM_SVC" 2>/dev/null; then
        systemctl reload "$FPM_SVC" 2>/dev/null || true
    fi
fi

log "Site $DOMAIN deleted successfully."
