#!/bin/bash
# Sourced by manage_system_module.sh. Restrict site traffic to Cloudflare,
# retaining local health checks and HTTP-01 certificate challenges.

# Downloads Cloudflare's published edge ranges (IPv4 + IPv6) into $1.
fetch_cloudflare_networks() {
    local out="$1" tmp network
    tmp="$(mktemp -d)"
    if ! curl -fsS --connect-timeout 10 --max-time 30 https://www.cloudflare.com/ips-v4 > "$tmp/v4" \
        || ! curl -fsS --connect-timeout 10 --max-time 30 https://www.cloudflare.com/ips-v6 > "$tmp/v6"; then
        rm -rf -- "$tmp"
        echo "Could not download the Cloudflare IP list" >&2
        return 1
    fi
    awk 'NF {print}' "$tmp/v4" "$tmp/v6" > "$out"
    rm -rf -- "$tmp"
    [ -s "$out" ] || { echo "Cloudflare network list is empty" >&2; return 1; }
    while IFS= read -r network; do
        [[ "$network" =~ ^[0-9a-fA-F:.]+/[0-9]+$ ]] || { echo "Invalid Cloudflare network list" >&2; return 1; }
    done < "$out"
}

# Restores the visitor IP (CF-Connecting-IP) for requests that come from a
# Cloudflare edge. Safe for sites not behind Cloudflare: the header is only
# trusted from Cloudflare's ranges. Without it, rate limits count Cloudflare
# edges instead of visitors and throttle many real users at once.
# Usage: install_cloudflare_realip [nginx_root] [refresh_script]
install_cloudflare_realip() (
    set -e
    local nginx_root="${1:-/etc/nginx}" refresh_script="${2:-}" network
    local conf="$nginx_root/conf.d/cloudflare_realip.conf" lockdown="$nginx_root/conf.d/cloudflare.conf"
    local work
    work="$(mktemp -d)"
    trap 'rm -rf -- "$work"' EXIT
    fetch_cloudflare_networks "$work/networks"
    {
        echo "# Managed by WooPanel: real visitor IP behind Cloudflare (refreshed weekly)."
        while IFS= read -r network; do echo "set_real_ip_from $network;"; done < "$work/networks"
        echo "real_ip_header CF-Connecting-IP;"
    } > "$work/realip"
    [ ! -f "$conf" ] || cp -p "$conf" "$work/conf.bak"
    [ ! -f "$lockdown" ] || cp -p "$lockdown" "$work/lockdown.bak"
    cp "$work/realip" "$conf"
    chmod 0644 "$conf"
    # Older lockdown configs carried their own real_ip directives; a second
    # real_ip_header in the http block is a fatal nginx error.
    [ ! -f "$lockdown" ] || sed -i -E '/^[[:space:]]*(set_real_ip_from|real_ip_header)[[:space:]]/d' "$lockdown"
    if ! nginx -t >/dev/null 2>&1; then
        if [ -f "$work/conf.bak" ]; then cp -p "$work/conf.bak" "$conf"; else rm -f "$conf"; fi
        [ ! -f "$work/lockdown.bak" ] || cp -p "$work/lockdown.bak" "$lockdown"
        nginx -t || true
        exit 1
    fi
    systemctl reload nginx
    if [ -n "$refresh_script" ] && [ -d /etc/cron.d ]; then
        printf 'SHELL=/bin/bash\nPATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\n17 4 * * 1 root bash %s refresh cloudflare-ips >/dev/null 2>&1\n' \
            "$refresh_script" > /etc/cron.d/woopanel-cloudflare-ips
        chmod 0644 /etc/cron.d/woopanel-cloudflare-ips
    fi
)
configure_cloudflare_lockdown() (
    set -e
    local action="$1" nginx_root="${2:-/etc/nginx}" file index=0
    local config="$nginx_root/conf.d/cloudflare.conf"
    local gate="$nginx_root/woopanel-cloudflare-gate.conf"
    local work
    work="$(mktemp -d)"
    local -a changed=() existed=()
    backup_cf_file() {
        changed+=("$1")
        if [ -f "$1" ]; then
            existed+=(true)
            cp -p "$1" "$work/backup-${#changed[@]}"
        else
            existed+=(false)
        fi
    }
    cleanup_cf() {
        local status="$?" i
        trap - EXIT
        if [ "$status" -ne 0 ] && [ "${#changed[@]}" -gt 0 ]; then
            for ((i=0; i<${#changed[@]}; i++)); do
                if [ "${existed[i]}" = true ]; then
                    cp -p "$work/backup-$((i+1))" "${changed[i]}"
                else
                    rm -f -- "${changed[i]}"
                fi
            done
            if nginx -t; then systemctl reload nginx || true; fi
        fi
        rm -rf -- "$work"
        exit "$status"
    }
    trap cleanup_cf EXIT
    if [ "$action" = install ]; then
        fetch_cloudflare_networks "$work/networks"
        printf 'geo $realip_remote_addr $woopanel_cf_allowed {\n    default 0;\n    127.0.0.1/32 1;\n    ::1/128 1;\n' > "$work/config"
        while IFS= read -r network; do
            [[ "$network" =~ ^[0-9a-fA-F:.]+/[0-9]+$ ]] || { echo "Invalid Cloudflare network list" >&2; exit 1; }
            printf '    %s 1;\n' "$network" >> "$work/config"
        done < "$work/networks"
        printf '}\n' >> "$work/config"
        cat >> "$work/config" <<'EOF'
map "$woopanel_cf_allowed:$uri" $woopanel_cf_denied {
    default 1;
    ~^1: 0;
    ~^0:/\.well-known/acme-challenge/[A-Za-z0-9_-]+$ 0;
}
EOF
        # Real visitor IPs come from cloudflare_realip.conf (install_cloudflare_realip).
        backup_cf_file "$config"
        backup_cf_file "$gate"
        cp "$work/config" "$config"
        printf 'if ($woopanel_cf_denied) { return 403; }\n' > "$gate"
        chmod 0644 "$config" "$gate"
    elif [ "$action" != uninstall ]; then
        echo "Invalid Cloudflare action" >&2
        exit 1
    fi
    for file in "$nginx_root"/conf.d/*.conf "$nginx_root"/sites-available/*; do
        [ -f "$file" ] || continue
        grep -Eq '^[[:space:]]*server_name[[:space:]]' "$file" || continue
        if [ "$action" = install ]; then
            if ! grep -Fq "include $gate;" "$file"; then
                backup_cf_file "$file"
                sed -i "/^[[:space:]]*server_name[[:space:]]/a \\    include $gate;" "$file"
            fi
        elif grep -Fq "include $gate;" "$file"; then
            backup_cf_file "$file"
            # Remove only the exact include owned by this feature.
            awk -v gate_line="include $gate;" 'index($0,gate_line)==0' "$file" > "$work/site"
            cat "$work/site" > "$file"
        fi
    done
    if [ "$action" = uninstall ]; then
        backup_cf_file "$config"
        backup_cf_file "$gate"
        rm -f "$config" "$gate"
    fi
    nginx -t
    systemctl reload nginx
)
