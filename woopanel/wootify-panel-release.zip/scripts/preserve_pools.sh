#!/bin/bash
# Sourced helpers. Backups are outside package-owned configuration directories.
backup_site_pools() {
    local destination="$1" base="${2:-/etc}" file name
    mkdir -p "$destination"
    chmod 0700 "$destination"
    for file in "$base"/php-fpm.d/*.conf "$base"/php/*/fpm/pool.d/*.conf; do
        [ -f "$file" ] || continue
        name="$(basename "$file")"
        [ "$name" != www.conf ] || continue
        if [ -f "$destination/$name" ]; then
            cmp -s "$file" "$destination/$name" || { echo "Conflicting pool files: $name" >&2; return 1; }
        else
            cp -p "$file" "$destination/$name" || return 1
        fi
    done
    printf 'complete\n' > "$destination/.complete"
}

restore_site_pools() {
    local source="$1" version="$2" base="${3:-/etc}" target file
    [ -f "$source/.complete" ] || { echo "Pool backup is incomplete" >&2; return 1; }
    if [ "$IS_DEBIAN" = true ]; then target="$base/php/$version/fpm/pool.d"; else target="$base/php-fpm.d"; fi
    mkdir -p "$target"
    for file in "$source"/*.conf; do
        [ -f "$file" ] || continue
        cp -p "$file" "$target/$(basename "$file")" || return 1
    done
}

validate_restored_pool_sockets() {
    local source="$1" file socket attempt
    for file in "$source"/*.conf; do
        [ -f "$file" ] || continue
        socket="$(awk -F= '/^[[:space:]]*listen[[:space:]]*=/ {gsub(/[[:space:]]/, "", $2); print $2; exit}' "$file")"
        [[ "$socket" = /* ]] || { echo "Expected per-site socket in $file" >&2; return 1; }
        for ((attempt=0; attempt<15; attempt++)); do
            [ -S "$socket" ] && break
            sleep 1
        done
        [ -S "$socket" ] || { echo "Restored pool socket is missing: $socket" >&2; return 1; }
    done
}
