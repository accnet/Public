#!/bin/bash
# PHP execution allowlist shared by site_security.sh (Nginx include) and
# php_allowlist_audit.sh (what the include would deny).

# Prints "|<escaped prefix>" per line of $1; fails on any line that is not a
# plain URI path, so nothing reaches the Nginx regex unchecked.
php_allowlist_extras() {
    local line
    [ -f "$1" ] || return 0
    while IFS= read -r line || [ -n "$line" ]; do
        [ -n "$line" ] || continue
        if ! [[ "$line" =~ ^/[A-Za-z0-9._/-]+$ ]] || [[ "$line" == *..* ]]; then
            echo "Invalid allowlist path: $line" >&2
            return 1
        fi
        printf '|%s' "${line//./\\.}"
    done < "$1"
}

# PCRE matching the .php URIs the allowlist denies. Usage: php_allowlist_regex <paths file>
php_allowlist_regex() {
    local extras
    extras="$(php_allowlist_extras "$1")" || return 1
    printf '%s' "^(?!/(?:index|wp-login|wp-cron|wp-comments-post|wp-signup|wp-activate|wp-trackback|wp-links-opml|wp-mail)\\.php\$|/wp-admin/|/wp-content/(?:plugins|themes)/${extras}).*\\.php\$"
}

# Usage: render_php_allowlist <paths file> <out file>
render_php_allowlist() {
    local regex
    regex="$(php_allowlist_regex "$1")" || return 1
    printf '%s\n' \
        '# Managed by WooPanel (php-allowlist): PHP outside these paths returns 404.' \
        "location ~* \"${regex}\" { return 404; }" \
        > "$2"
}
