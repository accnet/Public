#!/bin/bash
# stack_update.sh — patch updates for PHP, MariaDB, nginx and Redis that stay
# on the installed branch (8.3.35 -> 8.3.36, never 8.3 -> 8.4).
#
# Usage:
#   stack_update.sh check
#   stack_update.sh apply <php|nginx|mariadb|redis> <branch> [sites file]
#   stack_update.sh rollback <run dir> [sites file]
#
# The sites file holds "domain|php_version" lines; health checks use it.
# Output (one record per line, "|"-separated, like malware_scan.sh):
#   COMPONENT|<id>|<branch>|<installed>|<candidate>|<packages to upgrade>
#   PACKAGE|<id>|<branch>|<name>|<installed version>|<candidate version>
#   STEP|<text>
#   CHECK|<name>|PASS|FAIL|WARN|<detail>
#   RESULT|<updated|rolled_back|rollback_failed|refused|up_to_date|failed>|<run dir>|<detail>
#
# Only each component's own packages are ever upgraded: the transaction is
# dry-run first and refused if it would touch anything else.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
RUNS_DIR="${STACK_UPDATE_RUNS_DIR:-${PROJECT_DIR}/storage/stack-updates}"
COMPONENTS=(php nginx mariadb redis)
# Free space the run needs beyond the package downloads.
MIN_FREE_MB="${STACK_UPDATE_MIN_FREE_MB:-1024}"
KEEP_RUNS=3

emit() { local IFS='|'; printf '%s\n' "$*"; }
step() { emit STEP "$1"; }

# ---------------------------------------------------------------------------
# Installed packages and versions
# ---------------------------------------------------------------------------

# "name|version|arch" for every installed package.
installed_packages() {
    if [ "$IS_DEBIAN" = true ]; then
        dpkg-query -W -f='${Package}|${Version}|${Architecture}|${db:Status-Abbrev}\n' 2>/dev/null \
            | awk -F'|' '$4 ~ /^ii/ { print $1 "|" $2 "|" $3 }'
    else
        rpm -qa --qf '%{NAME}|%{EPOCH}:%{VERSION}-%{RELEASE}|%{ARCH}\n' 2>/dev/null | sed 's/|(none):/|/'
    fi
}

# Regex of the package names that belong to a component branch.
component_regex() {
    local component="$1" branch="${2:-}"
    case "$component" in
        php)
            if [ "$IS_DEBIAN" = true ]; then
                printf '^php%s(-|$)' "${branch//./\\.}"
            else
                printf '^php(-|$)'
            fi
            ;;
        # nginx-filesystem comes from the distro, not nginx.org.
        nginx) printf '^(nginx|nginx-module-.*)$' ;;
        mariadb) printf '^(MariaDB-.*|mariadb-.*|galera-.*)$' ;;
        redis) printf '^(redis|redis-server|redis-tools)$' ;;
        *) return 1 ;;
    esac
}

component_packages() {
    local regex
    regex="$(component_regex "$1" "${2:-}")" || return 1
    installed_packages | awk -F'|' -v re="$regex" '$1 ~ re' | sort
}

# The package whose version names the component.
key_package() {
    local component="$1" branch="${2:-}"
    case "$component" in
        php) [ "$IS_DEBIAN" = true ] && echo "php${branch}-fpm" || echo "php-fpm" ;;
        nginx) echo nginx ;;
        mariadb) [ "$IS_DEBIAN" = true ] && echo mariadb-server || echo MariaDB-server ;;
        redis) [ "$IS_DEBIAN" = true ] && echo redis-server || echo redis ;;
    esac
}

# 2:1.31.8-1.el9.ngx -> 1.31.8; 1:11.8.9+maria~ubu2204 -> 11.8.9
upstream_version() {
    printf '%s\n' "$1" | sed -E 's/^[0-9]+://; s/[-+~].*$//'
}

minor_of() { printf '%s\n' "$1" | cut -d. -f1-2; }

# Branches present for a component, one per line.
component_branches() {
    local component="$1" key version
    if [ "$component" = php ] && [ "$IS_DEBIAN" = true ]; then
        installed_packages | awk -F'|' '$1 ~ /^php[0-9]+\.[0-9]+-fpm$/ { sub(/^php/, "", $1); sub(/-fpm$/, "", $1); print $1 }' | sort -V
        return 0
    fi
    key="$(key_package "$component")"
    version="$(installed_packages | awk -F'|' -v k="$key" '$1 == k { print $2; exit }')"
    [ -n "$version" ] || return 0
    minor_of "$(upstream_version "$version")"
}

# ---------------------------------------------------------------------------
# Candidates: newest version on the same branch
# ---------------------------------------------------------------------------

# "name|candidate version" for packages that have an update on the branch.
# nginx is held to its installed minor (D-3); the repos already hold the other
# components to their branch (module stream, versioned package names, series repo).
candidate_versions() {
    local component="$1" branch="$2" names=() name best
    while IFS='|' read -r name _; do names+=("$name"); done < <(component_packages "$component" "$branch")
    [ "${#names[@]}" -gt 0 ] || return 0

    if [ "$component" = nginx ]; then
        for name in "${names[@]}"; do
            best="$(available_versions "$name" | while read -r v; do
                [ "$(minor_of "$(upstream_version "$v")")" = "$branch" ] && printf '%s %s\n' "$(upstream_version "$v")" "$v"
            done | sort -V -k1,1 | tail -n 1 | cut -d' ' -f2)"
            [ -n "$best" ] && printf '%s|%s\n' "$name" "$best"
        done
        return 0
    fi

    if [ "$IS_DEBIAN" = true ]; then
        for name in "${names[@]}"; do
            apt-cache policy "$name" 2>/dev/null | awk -v n="$name" '/Candidate:/ { if ($2 != "(none)") print n "|" $2; exit }'
        done
    else
        # check-update wraps long lines; join a lone name with the next line.
        dnf -q check-update "${names[@]}" 2>/dev/null \
            | awk 'NF == 1 { held = $1; next } held != "" { $0 = held " " $0; held = "" } NF >= 3 { n = $1; sub(/\.[^.]*$/, "", n); print n "|" $2 }'
    fi
}

# Every version the repos offer for one package, one per line.
available_versions() {
    if [ "$IS_DEBIAN" = true ]; then
        apt-cache madison "$1" 2>/dev/null | awk -F'|' '{ gsub(/ /, "", $2); print $2 }'
    else
        dnf -q list --showduplicates --available "$1" 2>/dev/null | awk 'NF >= 3 && $1 ~ /\./ { print $2 }'
    fi
}

# PACKAGE lines for the packages whose candidate differs from what is installed.
upgrade_plan() {
    local component="$1" branch="$2"
    join -t'|' <(component_packages "$component" "$branch" | cut -d'|' -f1,2 | sort -t'|' -k1,1) \
               <(candidate_versions "$component" "$branch" | sort -t'|' -k1,1) \
        | awk -F'|' -v c="$component" -v b="$branch" '$2 != $3 { print "PACKAGE|" c "|" b "|" $1 "|" $2 "|" $3 }'
}

check_all() {
    local component branch plan key installed candidate count
    if [ "$IS_DEBIAN" = true ]; then apt-get -q update >/dev/null 2>&1 || true; fi
    for component in "${COMPONENTS[@]}"; do
        while read -r branch; do
            [ -n "$branch" ] || continue
            plan="$(upgrade_plan "$component" "$branch")"
            key="$(key_package "$component" "$branch")"
            installed="$(installed_packages | awk -F'|' -v k="$key" '$1 == k { print $2; exit }')"
            candidate="$(printf '%s\n' "$plan" | awk -F'|' -v k="$key" '$4 == k { print $6; exit }')"
            count="$(printf '%s\n' "$plan" | grep -c '^PACKAGE|' || true)"
            emit COMPONENT "$component" "$branch" "$(upstream_version "$installed")" \
                "$(upstream_version "${candidate:-$installed}")" "$count"
            [ -z "$plan" ] || printf '%s\n' "$plan"
        done < <(component_branches "$component")
    done
}

# ---------------------------------------------------------------------------
# Apply: snapshot -> dry run -> upgrade -> restart -> health check -> rollback
# ---------------------------------------------------------------------------

# Root for config and runtime paths; tests point it at a fixture tree.
ROOT="${STACK_UPDATE_ROOT:-}"

config_paths() {
    local component="$1" branch="$2"
    case "$component" in
        php)
            if [ "$IS_DEBIAN" = true ]; then echo "etc/php/${branch}"; else printf '%s\n' etc/php.ini etc/php.d etc/php-fpm.conf etc/php-fpm.d; fi ;;
        nginx) echo etc/nginx ;;
        mariadb) if [ "$IS_DEBIAN" = true ]; then echo etc/mysql; else printf '%s\n' etc/my.cnf etc/my.cnf.d; fi ;;
        redis) printf '%s\n' etc/redis etc/redis.conf ;;
    esac
}

php_binary() { if [ "$IS_DEBIAN" = true ]; then echo "php$1"; else echo php; fi; }

site_socket() {
    if [ "$IS_DEBIAN" = true ]; then echo "${ROOT}/run/php/$1.sock"; else echo "${ROOT}/run/php-fpm/$1.sock"; fi
}

# Domains a component update can affect: PHP only touches sites on its branch.
affected_sites() {
    local component="$1" branch="$2" sites_file="$3" domain version
    [ -f "$sites_file" ] || return 0
    while IFS='|' read -r domain version; do
        [ -n "$domain" ] || continue
        if [ "$component" = php ] && [ "$IS_DEBIAN" = true ] && [ "$version" != "$branch" ]; then continue; fi
        echo "$domain"
    done < "$sites_file"
}

site_status() {
    curl -s -o /dev/null -m 15 -w '%{http_code}' -H "Host: $1" "http://127.0.0.1$2" 2>/dev/null || echo 000
}

# "domain path status" for each affected site.
record_site_status() {
    local domain path
    while read -r domain; do
        for path in / /wp-login.php; do
            printf '%s %s %s\n' "$domain" "$path" "$(site_status "$domain" "$path")"
        done
    done
}

package_spec() {
    local name="$1" version="$2" arch="${3:-}"
    if [ "$IS_DEBIAN" = true ]; then printf '%s=%s\n' "$name" "$version"; else printf '%s-%s%s\n' "$name" "$version" "${arch:+.$arch}"; fi
}

# Names a transaction would install, upgrade or remove, from a dry run.
dry_run_names() {
    if [ "$IS_DEBIAN" = true ]; then
        apt-get -s -y install --only-upgrade "$@" 2>/dev/null | awk '$1 == "Inst" || $1 == "Remv" { print $2 }'
    else
        dnf --assumeno upgrade "$@" 2>&1 | awk '
            /^Transaction Summary/ { body = 0 }
            body && NF >= 5 && $1 !~ /:$/ { print $1 }
            /^ Package +Arch/ { body = 1 }'
    fi
}

upgrade_packages() {
    if [ "$IS_DEBIAN" = true ]; then
        DEBIAN_FRONTEND=noninteractive apt-get -y -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold \
            install --only-upgrade "$@"
    else
        dnf -y upgrade "$@"
    fi
}

# The installed packages being replaced, so a rollback does not depend on the
# repo still carrying them (sury and Remi drop old builds).
download_installed() {
    local dest="$1"; shift
    local spec name version arch
    install -d -m 700 "$dest"
    for spec in "$@"; do
        IFS='|' read -r name version arch <<<"$spec"
        if [ "$IS_DEBIAN" = true ]; then
            (cd "$dest" && apt-get download "${name}=${version}" >/dev/null 2>&1) \
                || cp -- "${ROOT}/var/cache/apt/archives/${name}_${version//:/%3a}_${arch}.deb" "$dest/" 2>/dev/null \
                || return 1
        else
            dnf -q download --destdir "$dest" "$(package_spec "$name" "$version" "$arch")" >/dev/null 2>&1 || return 1
        fi
    done
    [ "$(find "$dest" -maxdepth 1 -type f \( -name '*.rpm' -o -name '*.deb' \) | wc -l)" -eq "$#" ]
}

restore_packages() {
    local dir="$1"
    if [ "$IS_DEBIAN" = true ]; then
        DEBIAN_FRONTEND=noninteractive dpkg -i --force-confold "$dir"/*.deb
    else
        dnf -y downgrade "$dir"/*.rpm
    fi
}

nginx_pid_file() {
    local file
    for file in "${ROOT}/run/nginx.pid" "${ROOT}/var/run/nginx.pid"; do
        [ -f "$file" ] && { echo "$file"; return 0; }
    done
    echo "${ROOT}/run/nginx.pid"
}

# New nginx binary without dropping connections: USR2 starts a new master,
# QUIT drains the old one. nginx.org packages often do this themselves; then
# the running master already uses the new binary and nothing is left to do.
reload_nginx_binary() {
    local pid_file old new i
    pid_file="$(nginx_pid_file)"
    old="$(cat "$pid_file" 2>/dev/null)"
    if [ -z "$old" ] || [[ "$(readlink "${ROOT}/proc/${old}/exe" 2>/dev/null)" != *"(deleted)" ]]; then
        return 0
    fi
    nginx -t >/dev/null 2>&1 || return 1
    kill -USR2 "$old" 2>/dev/null
    for i in 1 2 3 4 5 6 7 8 9 10; do
        new="$(cat "$pid_file" 2>/dev/null)"
        [ -n "$new" ] && [ "$new" != "$old" ] && break
        sleep 0.5
    done
    if [ -n "$new" ] && [ "$new" != "$old" ]; then
        kill -QUIT "$old" 2>/dev/null
        return 0
    fi
    systemctl restart nginx
}

restart_component() {
    local component="$1" branch="$2"
    case "$component" in
        php) restart_php_fpm_for_version "$branch" ;;
        nginx) reload_nginx_binary ;;
        *) return 1 ;;
    esac
}

component_service() {
    case "$1" in
        php) resolve_php_fpm_service_name "$2" ;;
        nginx) echo nginx ;;
        mariadb) echo mariadb ;;
        redis) [ "$IS_DEBIAN" = true ] && echo redis-server || echo redis ;;
    esac
}

check_line() {
    local name="$1" state="$2" detail="${3:-}"
    emit CHECK "$name" "$state" "$detail"
    [ "$state" != FAIL ]
}

# Health after an upgrade or rollback. $3: the key package version expected.
health_check() {
    local component="$1" branch="$2" expected="$3" run="$4" sites_file="$5" failures=0
    local service key installed missing domain path before now new_configs
    service="$(component_service "$component" "$branch")"
    if systemctl is-active --quiet "$service"; then check_line "service ${service}" PASS
    else check_line "service ${service}" FAIL "not active"; failures=$((failures + 1)); fi

    key="$(key_package "$component" "$branch")"
    installed="$(installed_packages | awk -F'|' -v k="$key" '$1 == k { print $2; exit }')"
    if [ "$installed" = "$expected" ]; then check_line "version ${key}" PASS "$installed"
    else check_line "version ${key}" FAIL "installed ${installed:-none}, expected ${expected}"; failures=$((failures + 1)); fi

    if [ "$component" = php ]; then
        missing="$(comm -23 "$run/modules-before.txt" <("$(php_binary "$branch")" -m 2>/dev/null | sort -u) | paste -sd' ' -)"
        if [ -z "$missing" ]; then check_line "php modules" PASS
        else check_line "php modules" FAIL "missing: ${missing}"; failures=$((failures + 1)); fi
        while read -r domain; do
            if [ -S "$(site_socket "$domain")" ]; then check_line "socket ${domain}" PASS
            else check_line "socket ${domain}" FAIL "$(site_socket "$domain") missing"; failures=$((failures + 1)); fi
        done < <(affected_sites "$component" "$branch" "$sites_file")
    fi

    if nginx -t >/dev/null 2>&1; then check_line "nginx -t" PASS
    else check_line "nginx -t" FAIL; failures=$((failures + 1)); fi

    while read -r domain path before; do
        now="$(site_status "$domain" "$path")"
        if [ "${now:0:1}" = "${before:0:1}" ]; then check_line "http ${domain}${path}" PASS "$before -> $now"
        else check_line "http ${domain}${path}" FAIL "$before -> $now"; failures=$((failures + 1)); fi
    done < "$run/sites-before.txt"

    new_configs="$(cd "${ROOT:-/}" && find $(config_paths "$component" "$branch") \( -name '*.rpmnew' -o -name '*.dpkg-dist' \) \
        -newer "$run/manifest.env" 2>/dev/null | paste -sd' ' -)"
    [ -z "$new_configs" ] || check_line "package config" WARN "review new defaults: ${new_configs}"
    return "$failures"
}

manifest_set() {
    local run="$1" key="$2" value="$3"
    { grep -v "^${key}=" "$run/manifest.env" 2>/dev/null; printf '%s=%s\n' "$key" "$value"; } > "$run/manifest.env.tmp"
    mv "$run/manifest.env.tmp" "$run/manifest.env"
    # JSON copy for the panel; values are plain tokens and short sentences.
    awk -F= 'BEGIN { printf "{" } { v = substr($0, length($1) + 2); gsub(/\\/, "\\\\", v); gsub(/"/, "\\\"", v); printf "%s\"%s\": \"%s\"", (NR > 1 ? ", " : ""), $1, v } END { print "}" }' \
        "$run/manifest.env" > "$run/manifest.json"
}

finish() {
    local run="$1" status="$2" detail="$3"
    if [ -n "$run" ]; then
        manifest_set "$run" status "$status"
        manifest_set "$run" detail "$detail"
        manifest_set "$run" finished "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    fi
    emit RESULT "$status" "$run" "$detail"
    case "$status" in updated|up_to_date) return 0 ;; *) return 1 ;; esac
}

prune_runs() {
    local component="$1" branch="$2"
    find "$RUNS_DIR" -mindepth 1 -maxdepth 1 -type d -name "*-${component}-${branch}" 2>/dev/null \
        | sort | head -n "-${KEEP_RUNS}" | while read -r old; do rm -rf -- "$old"; done
}

apply_update() {
    local component="$1" branch="$2" sites_file="${3:-/dev/null}" run plan specs=() snapshot=() allowed foreign
    local key from to name version arch free
    case "$component" in
        php|nginx) ;;
        mariadb|redis) finish "" refused "${component} updates arrive in P002 phase 3"; return ;;
        *) finish "" refused "unknown component ${component}"; return ;;
    esac
    [[ "$branch" =~ ^[0-9]+\.[0-9]+$ ]] || { finish "" refused "invalid branch ${branch}"; return; }
    component_branches "$component" | grep -qxF "$branch" || { finish "" refused "${component} ${branch} is not installed"; return; }

    step "Checking ${component} ${branch} for updates"
    plan="$(upgrade_plan "$component" "$branch")"
    [ -n "$plan" ] || { finish "" up_to_date "${component} ${branch} is up to date"; return; }

    run="${RUNS_DIR}/$(date -u +%Y%m%dT%H%M%SZ)-${component}-${branch}"
    install -d -m 700 "$RUNS_DIR" "$run"
    key="$(key_package "$component" "$branch")"
    from="$(installed_packages | awk -F'|' -v k="$key" '$1 == k { print $2; exit }')"
    to="$(printf '%s\n' "$plan" | awk -F'|' -v k="$key" '$4 == k { print $6; exit }')"
    : > "$run/manifest.env"
    manifest_set "$run" component "$component"
    manifest_set "$run" branch "$branch"
    manifest_set "$run" from "$(upstream_version "$from")"
    manifest_set "$run" to "$(upstream_version "${to:-$from}")"
    manifest_set "$run" key_from "$from"
    manifest_set "$run" key_to "${to:-$from}"
    manifest_set "$run" started "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    manifest_set "$run" status running
    printf '%s\n' "$plan" > "$run/plan.txt"

    free="$(df -Pm "$RUNS_DIR" | awk 'NR == 2 { print $4 }')"
    [ "${free:-0}" -ge "$MIN_FREE_MB" ] || { finish "$run" refused "only ${free} MB free, need ${MIN_FREE_MB} MB"; return; }

    while IFS='|' read -r _ _ _ name version to_version; do
        arch="$(installed_packages | awk -F'|' -v n="$name" '$1 == n { print $3; exit }')"
        snapshot+=("${name}|${version}|${arch}")
        specs+=("$(package_spec "$name" "$to_version")")
    done <<<"$plan"

    step "Saving the installed packages for rollback"
    download_installed "$run/packages" "${snapshot[@]}" \
        || { finish "$run" refused "could not save the installed packages, so a rollback would be impossible"; return; }
    step "Saving configuration"
    (cd "${ROOT:-/}" && tar -czf "$run/config.tgz" $(for p in $(config_paths "$component" "$branch"); do [ -e "$p" ] && echo "$p"; done)) \
        || { finish "$run" refused "could not save configuration"; return; }
    if [ "$component" = php ]; then "$(php_binary "$branch")" -m 2>/dev/null | sort -u > "$run/modules-before.txt"; fi
    affected_sites "$component" "$branch" "$sites_file" | record_site_status > "$run/sites-before.txt"

    step "Dry run"
    allowed="$(component_packages "$component" "$branch" | cut -d'|' -f1)"
    foreign="$(dry_run_names "${specs[@]}" | grep -vxF -f <(printf '%s\n' "$allowed") | sort -u | paste -sd' ' -)"
    [ -z "$foreign" ] || { finish "$run" refused "the transaction would also change: ${foreign}"; return; }

    step "Upgrading ${#specs[@]} package(s)"
    if ! upgrade_packages "${specs[@]}"; then
        rollback_run "$run" "$sites_file" "package upgrade failed"
        return
    fi
    step "Restarting ${component}"
    restart_component "$component" "$branch" || true

    step "Health checks"
    if health_check "$component" "$branch" "${to:-$from}" "$run" "$sites_file"; then
        prune_runs "$component" "$branch"
        finish "$run" updated "${component} ${branch}: $(upstream_version "$from") -> $(upstream_version "${to:-$from}")"
    else
        rollback_run "$run" "$sites_file" "health checks failed"
    fi
}

# Put back the saved packages and configuration, restart, check again.
rollback_run() {
    local run="$1" sites_file="${2:-/dev/null}" reason="${3:-manual rollback}" component branch key_from
    [ -f "$run/manifest.env" ] && [ -d "$run/packages" ] || { finish "" refused "not a stack update run: ${run}"; return; }
    component="$(sed -n 's/^component=//p' "$run/manifest.env")"
    branch="$(sed -n 's/^branch=//p' "$run/manifest.env")"
    key_from="$(sed -n 's/^key_from=//p' "$run/manifest.env")"
    if [ "$reason" = "manual rollback" ]; then
        # Undo only what is still in place: a later update replaced this
        # run's packages and its saved config is out of date.
        local status key_to current
        status="$(sed -n 's/^status=//p' "$run/manifest.env")"
        key_to="$(sed -n 's/^key_to=//p' "$run/manifest.env")"
        current="$(installed_packages | awk -F'|' -v k="$(key_package "$component" "$branch")" '$1 == k { print $2; exit }')"
        if [ "$status" != updated ] || [ "$current" != "$key_to" ]; then
            emit RESULT refused "" "this run (${status}) is not the current state: installed ${current:-none}, run installed ${key_to}"
            return 1
        fi
    fi
    step "Rolling back ${component} ${branch} (${reason})"
    restore_packages "$run/packages" || { finish "$run" rollback_failed "${reason}; reinstalling the saved packages failed"; return; }
    (cd "${ROOT:-/}" && tar -xzf "$run/config.tgz") || { finish "$run" rollback_failed "${reason}; restoring configuration failed"; return; }
    restart_component "$component" "$branch" || true
    if health_check "$component" "$branch" "$key_from" "$run" "$sites_file"; then
        finish "$run" rolled_back "${reason}; back on $(upstream_version "$key_from")"
    else
        finish "$run" rollback_failed "${reason}; checks still fail after the rollback"
    fi
}

# Only run as a command; tests source the functions.
if [ "${BASH_SOURCE[0]}" = "$0" ]; then
    set -uo pipefail
    # Runs hold config copies and packages: keep them root-only.
    umask 077
    source "${SCRIPT_DIR}/logging.sh"
    source "${SCRIPT_DIR}/os_detect.sh"
    source "${SCRIPT_DIR}/permissions.sh"
    case "${1:-}" in
        check) check_all ;;
        apply) require_root "stack_update.sh apply"; apply_update "${2:-}" "${3:-}" "${4:-/dev/null}" ;;
        rollback) require_root "stack_update.sh rollback"; rollback_run "${2:-}" "${3:-/dev/null}" ;;
        *) echo "Usage: $0 check | apply <component> <branch> [sites file] | rollback <run dir> [sites file]" >&2; exit 1 ;;
    esac
fi
