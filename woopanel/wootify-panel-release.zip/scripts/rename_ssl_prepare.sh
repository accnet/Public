#!/bin/bash
# rename_ssl_prepare.sh — step 2 of "change domain": get a working certificate
# for the NEW domain while the site keeps running on the old one.
#
# Usage:
#   rename_ssl_prepare.sh prepare <old-domain> <new-domain> <email> <verify-token>
#   rename_ssl_prepare.sh cleanup <old-domain> <new-domain>
#
# prepare: writes a temporary vhost for <new> (ACME + verify token only),
#          issues (or reuses) a Let's Encrypt certificate with the nginx
#          authenticator, then serves the token over HTTPS so the panel can
#          prove DNS + ports 80/443 + certificate end to end.
# cleanup: removes the temporary vhost, the certificate and the token.
set -Eeuo pipefail

ACTION="${1:-}"
OLD_DOMAIN="${2:-}"
NEW_DOMAIN="${3:-}"
EMAIL="${4:-}"
TOKEN="${5:-}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/logging.sh"
source "${SCRIPT_DIR}/permissions.sh"
source "${SCRIPT_DIR}/os_detect.sh"
LOG_FILE="$(resolve_log_file "wootify_ssl.log")"

log() {
    echo "[INFO] $1"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [RENAME-SSL] $1" >> "$LOG_FILE"
}
fail() {
    log "$1"
    echo "ERROR: $1" >&2
    exit 1
}

require_root "rename_ssl_prepare.sh"
validate_site_domain "$OLD_DOMAIN" && validate_site_domain "$NEW_DOMAIN" || fail "Invalid domain"
[ "$OLD_DOMAIN" != "$NEW_DOMAIN" ] || fail "New domain must differ from the current domain"

TEMP_MARKER="# WOOPANEL-RENAME-TEMP source=${OLD_DOMAIN}"
TEMP_CONF="${NGINX_CONF_DIR}/${NEW_DOMAIN}.conf"
# Under /var/www so the default SELinux context (httpd_sys_content_t) applies;
# a leading dot can never collide with a site directory name.
VERIFY_ROOT="/var/www/.woopanel-rename/${NEW_DOMAIN}"
LIVE_DIR="/etc/letsencrypt/live/${NEW_DOMAIN}"

cert_domains() {
    if printf '%s' "$NEW_DOMAIN" | grep -qi '^www\.'; then
        printf '%s\n' "$NEW_DOMAIN"
    else
        printf '%s\n%s\n' "$NEW_DOMAIN" "www.${NEW_DOMAIN}"
    fi
}

temp_conf_is_ours() {
    [ -f "$TEMP_CONF" ] && head -n 1 "$TEMP_CONF" | grep -qxF "$TEMP_MARKER"
}

reload_nginx_checked() {
    nginx -t >/dev/null 2>&1 || { nginx -t || true; return 1; }
    systemctl reload nginx
}

# Reuse a certificate that already covers every name and is valid > 7 days, so
# repeated attempts do not burn Let's Encrypt's duplicate-certificate limit.
cert_is_reusable() {
    local name
    [ -f "${LIVE_DIR}/cert.pem" ] || return 1
    openssl x509 -checkend $((7 * 86400)) -noout -in "${LIVE_DIR}/cert.pem" >/dev/null 2>&1 || return 1
    while IFS= read -r name; do
        openssl x509 -noout -ext subjectAltName -in "${LIVE_DIR}/cert.pem" 2>/dev/null | grep -qE "DNS:${name//./\\.}(,|$)" || return 1
    done < <(cert_domains)
}

write_temp_vhost() {
    local with_https="$1" names
    names="$(cert_domains | xargs)"
    {
        echo "$TEMP_MARKER"
        cat <<EOF
# Temporary vhost while ${OLD_DOMAIN} is being moved to ${NEW_DOMAIN}.
# Replaced by the real site config when the domain change runs.
server {
    listen 80;
    server_name ${names};
    root ${VERIFY_ROOT};
    location ^~ /.well-known/ {
        default_type text/plain;
        try_files \$uri =404;
    }
    location / {
        return 503;
    }
}
EOF
        if [ "$with_https" = 1 ]; then
            cat <<EOF

server {
    listen 443 ssl;
    server_name ${names};
    ssl_certificate ${LIVE_DIR}/fullchain.pem;
    ssl_certificate_key ${LIVE_DIR}/privkey.pem;
    root ${VERIFY_ROOT};
    location ^~ /.well-known/ {
        default_type text/plain;
        try_files \$uri =404;
    }
    location / {
        return 503;
    }
}
EOF
        fi
    } > "$TEMP_CONF"
}

prepare() {
    [ -n "$EMAIL" ] || fail "Email is required for Let's Encrypt"
    [[ "$TOKEN" =~ ^[A-Za-z0-9]{16,128}$ ]] || fail "Invalid verification token"
    [ -d "/var/www/${OLD_DOMAIN}" ] || fail "Current site root /var/www/${OLD_DOMAIN} not found"
    [ ! -e "/var/www/${NEW_DOMAIN}" ] || fail "/var/www/${NEW_DOMAIN} already exists"
    if [ -e "$TEMP_CONF" ] && ! temp_conf_is_ours; then
        fail "Nginx config ${TEMP_CONF} already exists and is not a WooPanel rename placeholder"
    fi
    command -v certbot >/dev/null 2>&1 || fail "Certbot is not installed. Activate SSL on any site once to install it."

    install -d -m 755 "${VERIFY_ROOT}/.well-known/woopanel-verify"
    printf '%s' "$TOKEN" > "${VERIFY_ROOT}/.well-known/woopanel-verify/${TOKEN}"
    chmod 644 "${VERIFY_ROOT}/.well-known/woopanel-verify/${TOKEN}"
    apply_selinux_web_context "${VERIFY_ROOT}"

    log "Writing temporary vhost for ${NEW_DOMAIN}..."
    write_temp_vhost 0
    reload_nginx_checked || { rm -f "$TEMP_CONF"; fail "Nginx rejected the temporary vhost"; }

    if cert_is_reusable; then
        log "Reusing valid certificate for ${NEW_DOMAIN}."
    else
        log "Requesting Let's Encrypt certificate for $(cert_domains | xargs)..."
        local args=() name output
        while IFS= read -r name; do args+=(-d "$name"); done < <(cert_domains)
        if ! output="$(certbot certonly --nginx --non-interactive --agree-tos --email "$EMAIL" \
                --cert-name "$NEW_DOMAIN" "${args[@]}" 2>&1)"; then
            echo "$output" >> "$LOG_FILE"
            if echo "$output" | grep -qiE "does not resolve|DNS problem|NXDOMAIN"; then
                echo "ERROR: DNS_PROBLEM" >&2
            elif echo "$output" | grep -qi "Challenge failed\|Timeout during connect\|Connection refused"; then
                echo "ERROR: CHALLENGE_FAILED" >&2
            elif echo "$output" | grep -qi "too many certificates\|rate limit"; then
                echo "ERROR: RATE_LIMITED" >&2
            fi
            echo "$output" | tail -n 5 >&2
            exit 1
        fi
    fi

    write_temp_vhost 1
    reload_nginx_checked || { write_temp_vhost 0; reload_nginx_checked || true; fail "Nginx rejected the HTTPS placeholder"; }

    local expiry
    expiry="$(openssl x509 -enddate -noout -in "${LIVE_DIR}/cert.pem" | cut -d= -f2)"
    echo "EXPIRY: $(date -d "$expiry" -u +%Y-%m-%dT%H:%M:%SZ)"
    log "Certificate for ${NEW_DOMAIN} is installed on the temporary vhost."
}

cleanup() {
    if temp_conf_is_ours; then
        rm -f "$TEMP_CONF"
        reload_nginx_checked || log "Warning: nginx reload failed after removing ${TEMP_CONF}"
    fi
    rm -rf -- "$VERIFY_ROOT"
    rmdir /var/www/.woopanel-rename 2>/dev/null || true
    # Only delete the lineage if no live vhost uses it (i.e. the rename never ran).
    if [ -d "$LIVE_DIR" ] && ! grep -rqsF "${LIVE_DIR}/" "$NGINX_CONF_DIR" /etc/nginx/sites-enabled 2>/dev/null; then
        certbot delete --cert-name "$NEW_DOMAIN" --non-interactive >/dev/null 2>&1 || true
    fi
    log "Removed pending rename artifacts for ${NEW_DOMAIN}."
}

case "$ACTION" in
    prepare) prepare ;;
    cleanup) cleanup ;;
    *) fail "Usage: $0 prepare|cleanup <old> <new> [email token]" ;;
esac
